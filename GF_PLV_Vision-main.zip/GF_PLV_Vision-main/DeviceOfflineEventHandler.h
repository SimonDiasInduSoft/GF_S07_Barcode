#pragma once

#include "MinimalWindows.h"
#include "Logger.h"

#include "GalaxyIncludes.h"

class DeviceOfflineEventHandler : public IDeviceOfflineEventHandler
{
    public:
        DeviceOfflineEventHandler(Logger* logger) : loggerCtx(logger) {}

        virtual void DoOnDeviceOfflineEvent(void* pUserParam) override
        {
            if (loggerCtx)
                loggerCtx->camIsHealthy.store(false);
        }

    private:
        Logger* loggerCtx;
};
