#pragma once

extern float mmPerPixelX;
extern float mmPerPixelY;
extern bool isCalibrated;

void setCalibration(float x, float y);
float mmToPixels(float mm);
float pixelsToMM(float pixels);