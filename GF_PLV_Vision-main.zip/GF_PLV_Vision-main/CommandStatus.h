#pragma once

#include <cstdint>

enum class CommandStatus : int16_t {
	Empty = 0,
    SendBarcodeCmd = 50,
	SendParamHistoryCmd = 3,
	ShutDownCmd = 4,
	ResetClientAnswerCmd = 5,
	SendCalibrationPoints = 6,
	ResetTriggerCmd = 7,
	SendImageCmd = 8,
	RecieveTriggerCmd = 10,
	SendTriggerCmd = 11,
	RecieveIsAliveCmd = 100,
	SendIsAliveCmd = 101,
};