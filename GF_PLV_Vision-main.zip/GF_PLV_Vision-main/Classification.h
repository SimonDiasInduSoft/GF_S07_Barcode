#pragma once

#include <string>

struct Classification {
    std::string prediction;
    int classId = 0;
    float confidence = 0.0f;
};
