#pragma once

#include "MySQL.h"

#include <cstdint>

class SessionManager {
    public:
        explicit SessionManager(uint8_t lineNr)
            : currentLineNr(lineNr) {
        }

        void init(MySQL& db) {
            currentSessionId = db.getLastSessieId(currentLineNr);
            currentSequenceId = 1;
        }

        // Nieuwe foto: sessie_id ophogen, vervolgnr resetten
        void newCapture() {
            ++currentSessionId;
            currentSequenceId = 1;
        }

        // Zelfde foto opnieuw: neem het vervolgnr over van de PLC.
        void setTry(int plcVolgnummer) {
            if (plcVolgnummer < 1)   plcVolgnummer = 1;
            if (plcVolgnummer > 255) plcVolgnummer = 255;
            currentSequenceId = static_cast<uint8_t>(plcVolgnummer);
        }

        // Zit deze sessie op of over het toegestane aantal pogingen?
        bool atMaxTries() const { return currentSequenceId >= MAX_VERVOLGNR; }

        int     getSessionId()  const { return currentSessionId; }
        uint8_t getSequenceNr() const { return currentSequenceId; }
        uint8_t getLineNr()    const { return currentLineNr; }

    private:
        static constexpr uint8_t MAX_VERVOLGNR = 3;

        uint8_t currentLineNr;
        int     currentSessionId = 0;
        uint8_t currentSequenceId = 1;
};