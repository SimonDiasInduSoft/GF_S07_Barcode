#include <cmath>
#include <algorithm>
#include <iostream>
#include <mutex>
#include <string>
#include <vector>

#include "Yolo11s.h"
#include "Parameters.h"
#include "ObjectDetection.h"

#include <opencv2/core.hpp>
#include <opencv2/dnn.hpp>
#include <opencv2/imgproc.hpp>

#include <onnxruntime_cxx_api.h>

YoloDetector::YoloDetector(Parameters& paramCtx) : ParametersCtx(paramCtx), env_(ORT_LOGGING_LEVEL_WARNING, "YOLOv8-OBB")
{
    std::string modelPath;
    {
        std::lock_guard<std::mutex> lock(ParametersCtx.paramMutex);
        modelPath = ParametersCtx.ObjectDetectionModelPath;
    }
    std::wstring wideModelPath(modelPath.begin(), modelPath.end());

    sessionOptions_.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_EXTENDED);
    sessionOptions_.SetIntraOpNumThreads(std::thread::hardware_concurrency());
    sessionOptions_.SetExecutionMode(ExecutionMode::ORT_PARALLEL);

    session_ = std::make_unique<Ort::Session>(
        env_,
        wideModelPath.c_str(),
        sessionOptions_);

    std::cout << "[DEBUG] Model loaded successfully\n";
}

void YoloDetector::preprocess(const cv::Mat& frame, cv::Mat& blob)
{
    cv::Mat input;
    if (frame.channels() == 1)
        cv::cvtColor(frame, input, cv::COLOR_GRAY2BGR);
    else
        input = frame.clone();

    cv::resize(input, input, cv::Size(inputWidth_, inputHeight_));
    cv::dnn::blobFromImage(input, blob, 1.0 / 255.0, cv::Size(inputWidth_, inputHeight_), cv::Scalar(), true, false);
}

std::vector<ObjectDetection> YoloDetector::detect(const cv::Mat& frame)
{
    cv::Mat blob;
    preprocess(frame, blob);

    std::array<int64_t, 4> inputShape{ 1, 3, inputHeight_, inputWidth_ };
    Ort::MemoryInfo memoryInfo = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
    Ort::Value inputTensor = Ort::Value::CreateTensor<float>(
        memoryInfo,
        blob.ptr<float>(),
        1 * 3 * inputHeight_ * inputWidth_,
        inputShape.data(),
        inputShape.size());

    const char* inputNames[] = { "images" };
    const char* outputNames[] = { "output0" };

    auto outputTensors = session_->Run(
        Ort::RunOptions{ nullptr },
        inputNames,
        &inputTensor,
        1,
        outputNames,
        1);

    float* outputData = outputTensors[0].GetTensorMutableData<float>();
    auto typeInfo = outputTensors[0].GetTensorTypeAndShapeInfo();
    std::vector<int64_t> outputShape = typeInfo.GetShape();

    // Output format: [1, 7, 8400]
    // 7 = [cx, cy, w, h, angle, confidence, class_score] for single class
    int numAttrs = static_cast<int>(outputShape[1]);
    int numPreds = static_cast<int>(outputShape[2]);

    cv::Mat output(numAttrs, numPreds, CV_32F, outputData);
    return postprocess(frame, output);
}

std::vector<ObjectDetection> YoloDetector::postprocess(const cv::Mat& frame, const cv::Mat& output)
{
    const int numAttrs = output.rows;  // 7
    const int numPreds = output.cols;  // 8400
    const float* data = reinterpret_cast<const float*>(output.data);

    std::vector<ObjectDetection> detections;
    std::vector<cv::Rect> boxes;
    std::vector<float> confidences;
    std::vector<float> angles;
    std::vector<cv::Point2f> centers;

    float xScale = static_cast<float>(frame.cols) / inputWidth_;
    float yScale = static_cast<float>(frame.rows) / inputHeight_;

    auto sigmoid = [](float x) { return 1.0f / (1.0f + std::exp(-x)); };

    for (int i = 0; i < numPreds; ++i)
    {
        float cx = data[0 * numPreds + i];
        float cy = data[1 * numPreds + i];
        float w = data[2 * numPreds + i];
        float h = data[3 * numPreds + i];
        float angle = data[5 * numPreds + i];

        // Only use Pattie class (index 5)
        float conf_pattie_raw = data[4 * numPreds + i];
        float confidence = sigmoid(conf_pattie_raw);

        // Filter by confidence threshold
        if (confidence < ParametersCtx.ObjectDetectionConfThreshold.load()) {
            continue;
        }

        // Scale to original image
        float cx_scaled = cx * xScale;
        float cy_scaled = cy * yScale;
        float w_scaled = w * xScale;
        float h_scaled = h * yScale;

        // Validate dimensions and position
        if (w_scaled < 10 || h_scaled < 10) continue;
        if (w_scaled > frame.cols * 0.8f || h_scaled > frame.rows * 0.8f) continue;
        if (cx_scaled < 0 || cy_scaled < 0 || cx_scaled > frame.cols || cy_scaled > frame.rows) continue;

        int left = std::max(0, static_cast<int>(cx_scaled - 0.5f * w_scaled));
        int top = std::max(0, static_cast<int>(cy_scaled - 0.5f * h_scaled));
        int width = std::min(static_cast<int>(w_scaled), frame.cols - left);
        int height = std::min(static_cast<int>(h_scaled), frame.rows - top);

        if (width < 10 || height < 10) continue;

        boxes.push_back(cv::Rect(left, top, width, height));
        confidences.push_back(confidence);
        angles.push_back(angle);
        centers.push_back(cv::Point2f(cx_scaled, cy_scaled));
    }

    // Apply NMS
    std::vector<int> indices;
    if (!boxes.empty()) {
        cv::dnn::NMSBoxes(boxes, confidences,
            ParametersCtx.ObjectDetectionConfThreshold.load(),
            ParametersCtx.ObjectDetectionNMSThreshold.load(),
            indices);
    }

    for (int idx : indices)
    {
        ObjectDetection det;
        det.classId = 0;  // Always Pattie
        det.confidence = confidences[idx];
        det.box = boxes[idx];
        det.angle = angles[idx];
        det.center = centers[idx];
        detections.push_back(det);
    }

    return detections;
}
void YoloDetector::drawDetections(cv::Mat& frame, const std::vector<ObjectDetection>& detections, const std::vector<std::string>& labels)
{
    if (frame.channels() == 1)
        cv::cvtColor(frame, frame, cv::COLOR_GRAY2BGR);

    cv::Scalar boxColor(255, 0, 0);  // Blue in BGR
    cv::Scalar textColor(255, 255, 255); // White for text

    for (const auto& d : detections)
    {
        if (d.classId < 0 || d.classId >= static_cast<int>(labels.size())) continue;

        // Convert angle to degrees
        float angleDegrees = d.angle * 180.0f / CV_PI;

        // Create RotatedRect
        cv::RotatedRect rotatedRect(d.center, cv::Size2f(d.box.width, d.box.height), angleDegrees);
        cv::Point2f vertices[4];
        rotatedRect.points(vertices);

        // Draw rotated box
        for (int i = 0; i < 4; i++) {
            cv::line(frame, vertices[i], vertices[(i + 1) % 4], boxColor, 2);
        }

        // Draw center
        cv::circle(frame, d.center, 3, cv::Scalar(0, 0, 255), -1);

        // Prepare label with class and confidence
        char confStr[16];
        snprintf(confStr, sizeof(confStr), "%.2f", d.confidence);
        std::string text = labels[d.classId] + " (" + std::string(confStr) + ")";

        // Compute label size & position
        int baseLine = 0;
        cv::Size labelSize = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.5, 1, &baseLine);
        cv::Point labelPos(static_cast<int>(vertices[1].x), static_cast<int>(vertices[1].y - 5));

        // Draw background rectangle for text
        cv::rectangle(frame, labelPos,
            cv::Point(labelPos.x + labelSize.width, labelPos.y + labelSize.height + baseLine),
            boxColor, cv::FILLED);

        // Draw text
        cv::putText(frame, text, cv::Point(labelPos.x, labelPos.y + labelSize.height),
            cv::FONT_HERSHEY_SIMPLEX, 0.5, textColor, 2);
    }
}
