#include "PXMMCalibration.h"

float mmPerPixelX = 0.0f;
float mmPerPixelY = 0.0f;
bool isCalibrated = false;

void setCalibration(float x, float y) {
    mmPerPixelX = x;
    mmPerPixelY = y;
    isCalibrated = true;
}

float mmToPixels(float mm) {
    if (!isCalibrated)
        return mm;

    return mm / ((mmPerPixelX + mmPerPixelY) / 2.0f);
}

float pixelsToMM(float pixels) {
    if (!isCalibrated)
        return pixels;

    return pixels * ((mmPerPixelX + mmPerPixelY) / 2.0f);
}
