﻿#include "ImageRecognition.h"

#include "MinimalWindows.h"

#include "CalibrationContext.h"

#include "Parameters.h"
#include "PlcCamData.h"
#include "ObjectDetection.h"
#include "Yolo11s.h"
#include "Classification.h"
#include "FileManager.h"
#include "Logger.h"
#include "LiveState.h"
#include "SaveCategory.h"
#include "AnalysedImage.h"

#include "TextBlock.h"
#include "StickerCandidate.h"

#include <map>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <set>
#include <algorithm> 
#include <climits>
#include <mutex>
#include <unordered_set>
#include <regex>

#include <opencv2/core.hpp>  
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/photo.hpp>

#include <ZXing/ReadBarcode.h>
#include <ZXing/BarcodeFormat.h>

#include <curl/curl.h>
#include <nlohmann/json.hpp>

using namespace cv;
using namespace std;

// Beste sticker-kandidaat bij één drempel
StickerCandidate ImageRecognition::stickerCandidate(const cv::Mat& gray, double thr, double printThr)
{
    const double A = static_cast<double>(gray.rows) * gray.cols;

    cv::Mat mask;
    cv::threshold(gray, mask, thr, 255, cv::THRESH_BINARY);

    // Tekst/barcodes binnen de sticker dichtmaken en gaten vullen
    cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(15, 15)));
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    mask.setTo(0);
    cv::drawContours(mask, contours, -1, cv::Scalar(255), cv::FILLED);

    // Dunne reflecties van de folie wegknippen
    cv::morphologyEx(mask, mask, cv::MORPH_OPEN, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(25, 25)));
    contours.clear();
    cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    StickerCandidate best;
    for (const auto& c : contours) {
        std::vector<cv::Point> hull;
        cv::convexHull(c, hull);
        double hullArea = cv::contourArea(hull);
        if (hullArea < 0.08 * A || hullArea > 0.70 * A) continue;   // te klein of hele palet

        cv::RotatedRect rr = cv::minAreaRect(c);
        double rrArea = static_cast<double>(rr.size.width) * rr.size.height;
        if (rrArea <= 0) continue;
        double rectangularity = hullArea / rrArea;
        double solidity = cv::contourArea(c) / hullArea;

        cv::Rect r = cv::boundingRect(c);
        double ar = static_cast<double>(r.width) / r.height;
        if (rectangularity < 0.85 || solidity < 0.85 || ar < 0.3 || ar > 4.0) continue;

        // Een sticker bevat print (tekst/barcodes); een blanke blob (metaal, reflectie) niet
        cv::Mat fill = cv::Mat::zeros(r.size(), CV_8U);
        cv::drawContours(fill, std::vector<std::vector<cv::Point>>{c}, -1, cv::Scalar(255), cv::FILLED, cv::LINE_8, cv::noArray(), INT_MAX, -r.tl());
        cv::Mat darkPx;
        cv::threshold(gray(r), darkPx, printThr, 255, cv::THRESH_BINARY_INV);
        const double fillArea = cv::countNonZero(fill);
        cv::bitwise_and(darkPx, fill, darkPx);
        if (fillArea <= 0 || cv::countNonZero(darkPx) < 0.05 * fillArea) continue;

        // Vorm weegt zwaar: een zuivere sticker wint van een grotere, samengesmolten blob
        double q = rectangularity * solidity;
        double score = hullArea * q * q * q * q;
        if (score > best.score) { best.contour = c; best.quality = q; best.score = score; }
    }
    return best;
}

//  Gesplitste analyse: label (boven) vs karton (onder)
cv::Rect ImageRecognition::findWhiteSticker(const cv::Mat& half)
{
    const cv::Rect fallback(0, 0, half.cols, half.rows);
    if (half.empty()) return fallback;

    cv::Mat gray;
    if (half.channels() == 3) cv::cvtColor(half, gray, cv::COLOR_BGR2GRAY);
    else if (half.channels() == 4) cv::cvtColor(half, gray, cv::COLOR_BGRA2GRAY);
    else gray = half.clone();
    cv::GaussianBlur(gray, gray, cv::Size(5, 5), 0);

    // Otsu 1: donker (tekst) vs licht; Otsu 2 op de lichte pixels: karton vs wit
    cv::Mat tmp;
    double t1 = cv::threshold(gray, tmp, 0, 255, cv::THRESH_BINARY | cv::THRESH_OTSU);
    cv::Mat brightPx;
    for (int y = 0; y < gray.rows; ++y) {
        const uchar* p = gray.ptr<uchar>(y);
        for (int x = 0; x < gray.cols; ++x) if (p[x] > t1) brightPx.push_back(p[x]);
    }
    if (brightPx.empty()) return fallback;
    double t2 = cv::threshold(brightPx, tmp, 0, 255, cv::THRESH_BINARY | cv::THRESH_OTSU);

    // Bovengrens: 99.5-percentiel (belichtingsonafhankelijk)
    int hist[256] = {0};
    for (int y = 0; y < gray.rows; ++y) {
        const uchar* p = gray.ptr<uchar>(y);
        for (int x = 0; x < gray.cols; ++x) ++hist[p[x]];
    }
    const double total = static_cast<double>(gray.total());
    double cum = 0; int hi = 255;
    for (int v = 0; v < 256; ++v) { cum += hist[v]; if (cum >= 0.995 * total) { hi = v; break; } }

    // Drempels aftasten; kies de meest sticker-achtige blob over alle drempels
    StickerCandidate best;
    for (double t = t2; t < hi - 2; t += 3.0) {
        StickerCandidate c = stickerCandidate(gray, t, t1);
        if (c.score > best.score) best = c;
    }
    // Onderbelicht beeld: sticker is donkerder dan de karton/wit-grens -> ook lagere drempels proberen
    if (best.contour.empty()) {
        for (double t = t1; t < t2; t += 4.0) {
            StickerCandidate c = stickerCandidate(gray, t, t1);
            if (c.score > best.score) best = c;
        }
    }
    if (best.contour.empty()) return fallback;

    // Rand verfijnen: mild (0.3) bij een zuivere blob, streng (0.6) als sticker en karton samengesmolten zijn
    const double k = best.quality >= 0.90 ? 0.3 : 0.6;
    cv::Mat cm = cv::Mat::zeros(gray.size(), CV_8U);
    cv::drawContours(cm, std::vector<std::vector<cv::Point>>{best.contour}, -1, cv::Scalar(1), cv::FILLED);
    cv::Mat rows, cols;
    cv::reduce(cm, rows, 1, cv::REDUCE_SUM, CV_32S);
    cv::reduce(cm, cols, 0, cv::REDUCE_SUM, CV_32S);
    double rMax, cMax;
    cv::minMaxLoc(rows, nullptr, &rMax);
    cv::minMaxLoc(cols, nullptr, &cMax);
    int y0 = -1, y1 = -1, x0 = -1, x1 = -1;
    for (int y = 0; y < rows.rows; ++y) if (rows.at<int>(y) >= k * rMax) { if (y0 < 0) y0 = y; y1 = y; }
    for (int x = 0; x < cols.cols; ++x) if (cols.at<int>(x) >= k * cMax) { if (x0 < 0) x0 = x; x1 = x; }
    cv::Rect r = (y0 < 0 || x0 < 0) ? cv::boundingRect(best.contour)
                                    : cv::Rect(x0, y0, x1 - x0 + 1, y1 - y0 + 1);

    // Kleine marge (1.5 %) zodat randen van een scheve sticker niet wegvallen
    const int px = static_cast<int>(r.width * 0.015), py = static_cast<int>(r.height * 0.015);
    r = cv::Rect(r.x - px, r.y - py, r.width + 2 * px, r.height + 2 * py) & fallback;
    return r;
}

// Decodeer de barcode in de horizontale strook van een detectie (volle labelbreedte = stille zones blijven behouden).
bool ImageRecognition::decodeStrip(const cv::Mat& gray, const cv::Rect& box, std::string& outText)
{
    const int pad = 10;
    const int y0 = std::max(0, box.y - pad);
    const int y1 = std::min(gray.rows, box.y + box.height + pad);
    if (y1 - y0 < 10) return false;
    const cv::Mat strip = gray.rowRange(y0, y1);
    const double lo = box.y - y0, hi = lo + box.height;

    std::vector<cv::Mat> variants;
    variants.push_back(strip.clone());
    cv::Mat sharp, clahe;
    const cv::Mat kernel = (cv::Mat_<float>(3, 3) << 0, -1, 0, -1, 5, -1, 0, -1, 0);
    cv::filter2D(strip, sharp, -1, kernel);
    variants.push_back(sharp);
    cv::createCLAHE(3.0, cv::Size(8, 8))->apply(strip, clahe);
    variants.push_back(clahe);

    for (double scale : {1.0, 2.0, 3.0}) {
        for (const cv::Mat& v : variants) {
            cv::Mat img;
            if (scale == 1.0) img = v;
            else cv::resize(v, img, cv::Size(), scale, scale, cv::INTER_CUBIC);
            if (!img.isContinuous()) img = img.clone();

            for (ZXing::Binarizer bin : {ZXing::Binarizer::LocalAverage, ZXing::Binarizer::GlobalHistogram}) {
                ZXing::ReaderOptions options;
                options.setTryHarder(true);
                options.setFormats(ZXing::BarcodeFormat::EAN13 | ZXing::BarcodeFormat::Code128);
                options.setBinarizer(bin);
                ZXing::ImageView view(img.data, img.cols * img.rows, img.cols, img.rows, ZXing::ImageFormat::Lum);
                for (const auto& b : ZXing::ReadBarcodes(view, options)) {
                    double sy = 0;
                    for (const auto& pt : b.position()) sy += pt.y;
                    double cy = sy / 4.0 / scale;
                    if (cy >= lo && cy <= hi && !b.text().empty()) { outText = b.text(); return true; }
                }
            }
        }
    }
    return false;
}

// Label: de (02)-barcode van de witte sticker (GTIN van de inhoud = zelfde code als op het karton)
void ImageRecognition::detectBarcode02InLabel(const cv::Mat& roi, cv::Point offset, cv::Mat& annotated, std::string& outBarcode)
{
    if (roi.empty() || !outBarcode.empty()) return;

    auto is02 = [](const std::string& t) { return t.rfind("(02)", 0) == 0; };
    auto push = [&](const std::string& text, const cv::Rect& boxInROI, const cv::Scalar& color) {
        outBarcode = text;
        cv::Rect boxFull(boxInROI.x + offset.x, boxInROI.y + offset.y, boxInROI.width, boxInROI.height);
        cv::rectangle(annotated, boxFull, color, 2);
        cv::putText(annotated, text, cv::Point(boxFull.x, boxFull.y - 5),
            cv::FONT_HERSHEY_SIMPLEX, 0.6, color, 2, cv::LINE_AA);
    };

    cv::Mat img = roi.clone();
    cv::Mat gray;
    if (img.channels() == 3) cv::cvtColor(img, gray, cv::COLOR_BGR2GRAY);
    else if (img.channels() == 4) cv::cvtColor(img, gray, cv::COLOR_BGRA2GRAY);
    else gray = img;
    const cv::Rect roiRect(0, 0, gray.cols, gray.rows);

    // Pad A: elke YOLO-detectie (van boven naar onder) als strook lezen; de eerste (02) wint
    auto detections = Model.detect(img);
    if (!detections.empty() && detections.size() <= static_cast<size_t>(MAX_DETECTIONS)) {
        std::sort(detections.begin(), detections.end(),
            [](const ObjectDetection& a, const ObjectDetection& b) { return a.center.y < b.center.y; });
        for (const auto& d : detections) {
            const cv::Rect box = d.box & roiRect;
            std::string text;
            if (!box.empty() && decodeStrip(gray, box, text) && is02(text)) {
                push(text, box, cv::Scalar(0, 255, 0));
                return;
            }
        }
    }

    // Pad A.2: YOLO miste de barcode -> ZXing op het volledige label
    {
        ZXing::ReaderOptions options;
        options.setTryHarder(true);
        options.setFormats(ZXing::BarcodeFormat::EAN13 | ZXing::BarcodeFormat::Code128);
        cv::Mat g = gray.isContinuous() ? gray : gray.clone();
        ZXing::ImageView view(g.data, g.cols * g.rows, g.cols, g.rows, ZXing::ImageFormat::Lum);
        for (const auto& b : ZXing::ReadBarcodes(view, options)) {
            if (!is02(b.text())) continue;
            std::vector<cv::Point> pts;
            for (const auto& pt : b.position()) pts.emplace_back(pt.x, pt.y);
            push(b.text(), cv::boundingRect(pts) & roiRect, cv::Scalar(0, 255, 0));
            return;
        }
    }

    // Pad B: 1 OCR-call op het label; zoek "(02)" + 14 cijfers in de leesbare tekst onder de barcode
    std::string all;
    for (const auto& block : parseResponse(callVisionAPI(matToBase64(gray))))
        all += block.text + " ";
    static const std::regex re02(R"(\(\s*0\s*2\s*\)\s*((?:\d\s*){14}))");
    std::smatch m;
    if (std::regex_search(all, m, re02)) {
        std::string digits;
        for (char c : m[1].str()) if (std::isdigit(static_cast<unsigned char>(c))) digits += c;
        push("(02)" + digits, roiRect, cv::Scalar(0, 165, 255));
    }
}

void ImageRecognition::detectBarcodeInROI(const cv::Mat& roi, cv::Point offset, cv::Mat& annotated, std::string& outBarcode)
{
    if (roi.empty() || !outBarcode.empty()) return;

    cv::Mat img = roi.clone();
    auto detections = Model.detect(img);

    if (detections.empty() || detections.size() > static_cast<size_t>(MAX_DETECTIONS)) return;

    auto bc = cropBarcodesFromImage(img, detections, 5);

    // ITF: de doosbarcode (ITF-14, bv. 4 84 36621 02135 1) is geen EAN-13/Code128
    ZXing::ReaderOptions options;
    options.setTryHarder(true);
    options.setFormats(ZXing::BarcodeFormat::EAN13 | ZXing::BarcodeFormat::Code128 | ZXing::BarcodeFormat::ITF);

    auto pickCentered = [](const ZXing::Barcodes& bcs, int w, int h) -> std::string {
        const double cx = w / 2.0, cy = h / 2.0;
        double best = std::numeric_limits<double>::max();
        std::string text;
        for (const auto& b : bcs) {
            double sx = 0, sy = 0;
            for (const auto& pt : b.position()) { sx += pt.x; sy += pt.y; }
            double bxc = sx / 4.0, byc = sy / 4.0;
            double d = (bxc - cx) * (bxc - cx) + (byc - cy) * (byc - cy);
            if (d < best) { best = d; text = b.text(); }
        }
        return text;
    };

    // OCR-tekst enkel aanvaarden als het op een barcode lijkt: minstens 8 cijfers, verder enkel ( ) en spaties
    auto looksLikeBarcodeText = [](const std::string& raw) -> bool {
        size_t digits = 0;
        for (char c : raw) {
            if (std::isdigit(static_cast<unsigned char>(c))) ++digits;
            else if (c != '(' && c != ')' && c != ' ') return false;
        }
        return digits >= 8;
    };

    auto push = [&](const std::string& text, const cv::Rect& bboxInROI, const cv::Scalar& color) {
        if (text.empty()) return;
        outBarcode = text;
        cv::Rect bboxFull(bboxInROI.x + offset.x, bboxInROI.y + offset.y,
            bboxInROI.width, bboxInROI.height);
        cv::rectangle(annotated, bboxFull, color, 2);
        cv::putText(annotated, text, cv::Point(bboxFull.x, bboxFull.y - 5),
            cv::FONT_HERSHEY_SIMPLEX, 0.6, color, 2, cv::LINE_AA);
    };

    // Pad A: ZXing op elke YOLO-crop (native, daarna vergroot); eerste leesbare barcode wint
    for (size_t i = 0; i < bc.size() && outBarcode.empty(); i++) {
        for (double scale : {1.0, 2.0, 3.0}) {
            cv::Mat src = bc[i];
            if (scale != 1.0) cv::resize(bc[i], src, cv::Size(), scale, scale, cv::INTER_CUBIC);
            if (!src.isContinuous()) src = src.clone();
            ZXing::ImageView view(src.data, src.cols * src.rows, src.cols, src.rows, ZXing::ImageFormat::Lum);
            auto barcodes = ZXing::ReadBarcodes(view, options);
            if (!barcodes.empty()) {
                push(pickCentered(barcodes, src.cols, src.rows), detections[i].box, cv::Scalar(0, 255, 0));
                break;
            }
        }
    }

    // Pad A.3: YOLO-crop te krap -> ZXing op de volledige ROI
    if (outBarcode.empty()) {
        cv::Mat gray;
        if (img.channels() == 3) cv::cvtColor(img, gray, cv::COLOR_BGR2GRAY);
        else if (img.channels() == 4) cv::cvtColor(img, gray, cv::COLOR_BGRA2GRAY);
        else gray = img.isContinuous() ? img : img.clone();
        ZXing::ImageView view(gray.data, gray.cols * gray.rows, gray.cols, gray.rows, ZXing::ImageFormat::Lum);
        auto barcodes = ZXing::ReadBarcodes(view, options);
        if (!barcodes.empty()) {
            const auto& b = barcodes.front();
            std::vector<cv::Point> pts;
            for (const auto& pt : b.position()) pts.emplace_back(pt.x, pt.y);
            push(b.text(), cv::boundingRect(pts), cv::Scalar(0, 255, 0));
        }
    }

    // Pad B: OCR-fallback met 1 call per beeld: alle crops onder elkaar in 1 afbeelding, tekst per crop terugzoeken
    if (outBarcode.empty() && !bc.empty()) {
        const int gap = 20;
        int mosaicW = 0, mosaicH = 0;
        for (const auto& c : bc) { mosaicW = std::max(mosaicW, c.cols); mosaicH += c.rows + gap; }
        cv::Mat mosaic(mosaicH, mosaicW, bc[0].type(), cv::Scalar::all(255));
        std::vector<int> yStart(bc.size());
        int y = 0;
        for (size_t i = 0; i < bc.size(); i++) {
            yStart[i] = y;
            bc[i].copyTo(mosaic(cv::Rect(0, y, bc[i].cols, bc[i].rows)));
            y += bc[i].rows + gap;
        }

        std::vector<std::string> textPerCrop(bc.size());
        for (const auto& block : parseResponse(callVisionAPI(matToBase64(mosaic)))) {
            if (block.vertices.empty()) continue;
            double cy = 0;
            for (const auto& v : block.vertices) cy += v.y;
            cy /= block.vertices.size();
            for (size_t i = 0; i < bc.size(); i++) {
                if (cy >= yStart[i] && cy < yStart[i] + bc[i].rows) {
                    for (char c : block.text)
                        if (!std::isspace(static_cast<unsigned char>(c))) textPerCrop[i] += c;
                    break;
                }
            }
        }

        for (size_t i = 0; i < bc.size() && outBarcode.empty(); i++)
            if (looksLikeBarcodeText(textPerCrop[i]))
                push(textPerCrop[i], detections[i].box, cv::Scalar(0, 165, 255));
    }
}

void ImageRecognition::detectFRInROI(const cv::Mat& roi, cv::Point offset,
    cv::Mat& annotated, std::string& outFR)
{
    if (roi.empty() || !outFR.empty()) return;

    std::string b64 = matToBase64(roi);
    std::string response = callVisionAPI(b64);
    std::vector<TextBlock> blocks = parseResponse(response);

    std::regex frPattern(R"(FR?[\dOo]{6})");

    for (const auto& block : blocks) {
        if (!outFR.empty()) break;

        std::smatch match;
        if (!std::regex_search(block.text, match, frPattern)) continue;

        std::string matched = match.str();
        size_t pos = match.position();
        size_t end = pos + matched.size();

        bool validStart = (pos == 0) || !std::isalnum(static_cast<unsigned char>(block.text[pos - 1]));
        bool validEnd   = (end == block.text.size()) || !std::isalnum(static_cast<unsigned char>(block.text[end]));
        if (!validStart || !validEnd) continue;

        // O/o → 0 in cijfergedeelte
        size_t digitStart = (matched.size() > 1 &&
            (matched[1] == 'R' || matched[1] == 'r')) ? 2 : 1;
        for (size_t i = digitStart; i < matched.size(); i++)
            if (matched[i] == 'O' || matched[i] == 'o')
                matched[i] = '0';

        outFR = matched;

        if (block.vertices.size() == 4) {
            std::vector<cv::Point> shifted;
            for (const auto& v : block.vertices)
                shifted.emplace_back(v.x + offset.x, v.y + offset.y);
            std::vector<std::vector<cv::Point>> contours = { shifted };
            cv::polylines(annotated, contours, true, cv::Scalar(0, 255, 0), 2);
            cv::putText(annotated, matched, shifted[0],
                cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 255, 0), 2, cv::LINE_AA);
        }
    }
}

AnalysedImage ImageRecognition::analyseImage(cv::Mat& image)
{
    AnalysedImage result;
    result.anotatedImg = image.clone();
    if (result.anotatedImg.channels() == 1)
        cv::cvtColor(result.anotatedImg, result.anotatedImg, cv::COLOR_GRAY2BGR);

    const int h     = image.rows;
    const int w     = image.cols;
    const int halfH = h / 2;

    cv::Mat topHalf    = image(cv::Rect(0, 0,     w, halfH));
    cv::Mat bottomHalf = image(cv::Rect(0, halfH, w, h - halfH));

    // --- Label (bovenste helft) ---
    cv::Rect labelSticker = findWhiteSticker(topHalf);
    cv::Point labelOffset(labelSticker.x, labelSticker.y);
    cv::Mat labelROI = topHalf(labelSticker);

    detectBarcode02InLabel(labelROI, labelOffset, result.anotatedImg, result.barcodeLabel);
    detectFRInROI    (labelROI, labelOffset, result.anotatedImg, result.frCodeImageLabel);

    // Stickerkader blauw tekenen (label)
    cv::rectangle(result.anotatedImg,
        cv::Rect(labelSticker.x, labelSticker.y, labelSticker.width, labelSticker.height),
        cv::Scalar(255, 0, 0), 2);

    // --- Karton (onderste helft) --- geen witte sticker, volledige helft gebruiken
    cv::Point kartonOffset(0, halfH);
    detectBarcodeInROI(bottomHalf, kartonOffset, result.anotatedImg, result.barcodeCardboard);

    // FR karton: volledig beeld (ook bovenste helft) met de sticker weggewit, zodat enkel FR buiten de sticker telt
    cv::Mat frCardboardImg = image.clone();
    cv::rectangle(frCardboardImg, labelSticker, cv::Scalar::all(255), cv::FILLED);
    detectFRInROI    (frCardboardImg, cv::Point(0, 0), result.anotatedImg, result.frCodeImageCardboard);

    // Scheidingslijn oranje halverwege
    cv::line(result.anotatedImg,
        cv::Point(0, halfH), cv::Point(w, halfH),
        cv::Scalar(0, 165, 255), 2);

    // Publiceer naar de UI (Live-tab): laatste geannoteerde beeld + korte status.
    {
        int found = 0;
        std::string status;
        if (!result.barcodeLabel.empty())     { ++found; status += "label: "  + result.barcodeLabel + "  "; }
        if (!result.barcodeCardboard.empty()) { ++found; status += "karton: " + result.barcodeCardboard + "  "; }
        if (!result.frCodeImageLabel.empty())     { ++found; status += "FR-label: "  + result.frCodeImageLabel + "  "; }
        if (!result.frCodeImageCardboard.empty()) { ++found; status += "FR-karton: " + result.frCodeImageCardboard + "  "; }
        Live.publishStatus(status, found);
        Live.publishImage(result.anotatedImg);
    }

    return result;
}

// Google API
size_t ImageRecognition::writeCallback(void* contents, size_t size, size_t nmemb, std::string* out) {
    size_t total = size * nmemb;
    out->append((char*)contents, total);
    return total;
}

std::string ImageRecognition::matToBase64(const cv::Mat& frame) {
    std::vector<uchar> buf;
    cv::imencode(".jpg", frame, buf);

    // base64 encoding
    static const std::string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string result;
    result.reserve(((buf.size() + 2) / 3) * 4);

    for (size_t i = 0; i < buf.size(); i += 3) {
        uint32_t b = (buf[i] << 16);
        if (i + 1 < buf.size()) b |= (buf[i + 1] << 8);
        if (i + 2 < buf.size()) b |= buf[i + 2];

        result += chars[(b >> 18) & 0x3F];
        result += chars[(b >> 12) & 0x3F];
        result += (i + 1 < buf.size()) ? chars[(b >> 6) & 0x3F] : '=';
        result += (i + 2 < buf.size()) ? chars[b & 0x3F] : '=';
    }
    return result;
}

std::string ImageRecognition::callVisionAPI(const std::string& base64Image) {
    // Bouw JSON request op
    nlohmann::json request = {
        {"requests", {{
            {"image", {{"content", base64Image}}},
            {"features", {{{"type", "TEXT_DETECTION"}}}}
        }}}
    };
    std::string requestBody = request.dump();

    // API-key uit Parameters (config.json / UI). Leeg -> niet bellen.
    std::string apiKey;
    { std::lock_guard<std::mutex> lock(ParamCtx.paramMutex); apiKey = ParamCtx.VisionApiKey; }
    if (apiKey.empty()) {
        LoggerCtx.pushMsg("Vision API: geen API-key ingesteld (zie Settings)", LogLevel::Warning);
        return "";
    }
    const std::string url = VISION_BASE_URL + apiKey;

    // libcurl setup
    CURL* curl = curl_easy_init();
    std::string response;

    if (!curl) {
        LoggerCtx.pushMsg("Vision API: curl_easy_init() mislukt");
        return "";
    }

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, requestBody.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 5L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 3L);

    CURLcode res = curl_easy_perform(curl);
    long httpCode = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);

    if (res != CURLE_OK) {
        LoggerCtx.pushMsg(std::string("Vision API curl fout: ") + curl_easy_strerror(res));
        LoggerCtx.googleIsHealthy.store(false);
    }
    else if (httpCode != 200) {
        LoggerCtx.pushMsg("Vision API HTTP fout: " + std::to_string(httpCode));
        LoggerCtx.googleIsHealthy.store(false);
    }
    else {
        LoggerCtx.googleIsHealthy.store(true);
    }

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    return response;
}

std::vector<TextBlock> ImageRecognition::parseResponse(const std::string& jsonStr) {
    std::vector<TextBlock> blocks;

    try {
        nlohmann::json response = nlohmann::json::parse(jsonStr);

        // Controleer op API-fout
        if (response.contains("error")) {
            std::cerr << "API fout: " << response["error"]["message"] << "\n";
            return blocks;
        }

        if (!response.contains("responses") || response["responses"].empty())
            return blocks;

        auto& resp = response["responses"][0];
        if (!resp.contains("textAnnotations"))
            return blocks;

        auto& annotations = resp["textAnnotations"];

        for (size_t i = 1; i < annotations.size(); ++i) {
            TextBlock block;
            block.text = annotations[i]["description"].get<std::string>();

            // Bounding polygon: 4 hoekpunten
            for (auto& vertex : annotations[i]["boundingPoly"]["vertices"]) {
                int x = vertex.value("x", 0);
                int y = vertex.value("y", 0);
                block.vertices.push_back(cv::Point(x, y));
            }
            blocks.push_back(block);
        }
    }
    catch (const nlohmann::json::exception& e) {
        std::cerr << "JSON parse fout: " << e.what() << "\n";
    }

    return blocks;
}

void ImageRecognition::drawAnnotations(cv::Mat& frame, const std::vector<TextBlock>& blocks) {
    for (const auto& block : blocks) {
        if (block.vertices.size() == 4) {
            std::vector<std::vector<cv::Point>> contours = { block.vertices };
            cv::polylines(frame, contours, true, cv::Scalar(0, 255, 0), 2);

            cv::putText(frame, block.text,
                block.vertices[0],
                cv::FONT_HERSHEY_SIMPLEX,
                0.5,
                cv::Scalar(0, 0, 255),
                1, cv::LINE_AA);
        }
    }
}

// Barcodes

vector<Mat> ImageRecognition::cropBarcodesFromImage(Mat& image, const vector<ObjectDetection>& detections, int padding)
{
    std::vector<cv::Mat> crops;

    for (const auto& det : detections) {
        // Convert angle to degrees if it's in radians
        float angleDegrees = det.angle * 180.0f / CV_PI;

        // RotatedRect with center, size, angle
        cv::RotatedRect rotatedRect(det.center, cv::Size2f(det.box.width, det.box.height), angleDegrees);

        // Get bounding rect with padding
        cv::Rect bbox = rotatedRect.boundingRect();

        // Apply padding
        bbox.x = std::max(0, bbox.x - padding);
        bbox.y = std::max(0, bbox.y - padding);
        bbox.width = std::min(image.cols - bbox.x, bbox.width + 2 * padding);
        bbox.height = std::min(image.rows - bbox.y, bbox.height + 2 * padding);

        // Crop and store
        crops.push_back(image(bbox).clone());
        
        if (ParamCtx.SaveImages.load())
            FileManager.enqueueImage(SaveCategory::RawImages, image(bbox).clone(), ".bmp");
    }

    return crops;
}

void ImageRecognition::drawBarcodes(Mat& image, const ZXing::Barcodes& barcodes, cv::Point offset) {
    for (const auto& barcode : barcodes) {
        auto points = barcode.position();
        std::vector<cv::Point> cvPoints;
        for (auto& p : points) {
            // Offset optellen
            cvPoints.emplace_back(static_cast<int>(p.x) + offset.x,
                static_cast<int>(p.y) + offset.y);
        }
        if (cvPoints.size() >= 4) {
            for (size_t i = 0; i < cvPoints.size(); ++i) {
                cv::line(image, cvPoints[i], cvPoints[(i + 1) % cvPoints.size()],
                    cv::Scalar(0, 255, 0), 2);
            }
        }
        cv::putText(image, barcode.text(), cvPoints[0],
            cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 255), 2);
    }
}