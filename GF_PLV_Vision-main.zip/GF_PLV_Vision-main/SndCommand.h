#pragma once

#include <atomic>

#include "PlcCamData.h"
#include "PLCString80.h"
#include "CommandStatus.h"

class SndCommand {
public:
    SndCommand() { iCmdId = nextId.fetch_add(1); }
    SndCommand(CommandStatus status) : iCmd(static_cast<int16_t>(status)) { iCmdId = nextId.fetch_add(1); }
    SndCommand(CommandStatus status, int16_t answId) : iCmd(static_cast<int16_t>(status)), iAnswId(answId) { iCmdId = nextId.fetch_add(1); }

    uint16_t iCmd = 0;
    uint16_t iCmdId = 0;
    uint16_t iAnswId = 0;

    int adArg[10] = {};
    float arArg[10] = {};
    PLCString80 asArg[10] = {};

private:
    inline static std::atomic<uint16_t> nextId{ 1 };
};

