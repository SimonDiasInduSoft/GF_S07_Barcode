#pragma once

#include <atomic>

#include "PLCString80.h"

class RcCommand {
public:
    RcCommand() { iCmdId = nextId.fetch_add(1); }
    RcCommand(int16_t commandId, int16_t answId) : iCmd(commandId), iAnswId(answId) { iCmdId = nextId.fetch_add(1); }

    uint16_t iCmd = 0;
    uint16_t iCmdId = 0;
    uint16_t iAnswId = 0;

    int adArg[10] = {};
    float arArg[10] = {};
    PLCString80 asArg[10] = {};

private:
    inline static std::atomic<uint16_t> nextId{ 1 };
};
