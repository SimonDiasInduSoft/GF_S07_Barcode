#include "ApplicationReconnector.h"

#include "CalibrationContext.h"
#include "logger.h"
#include "VaLinker.h"
#include "PlcContext.h"
#include "ThreadManager.h"
#include "PostgresSQL.h"
#include "CameraContext.h"
#include "MySQL.h"

#include <mutex>
#include <algorithm> 
#include <string>
#include <iostream>
#include <memory>
#include <utility> 
#include <cstddef> 

void ApplicationReconnector::reconnectionProtocol(PlcContext& plcCtx, CameraContext& stalkCamCtx, ThreadManager& dataControl, PostgresSQL& databaseConnection, MySQL& mysqlConnection)
{
    if (logger.systemCheckup()) return;

    if (!logger.plcIsHealthy.load(std::memory_order_relaxed)) {
        tryReconnectPlc(plcCtx);
    }
    if (!logger.camIsHealthy.load(std::memory_order_relaxed)) {
        if(paramCtx.UseCamera.load())
            tryReconnectCamera(stalkCamCtx);
        else
            logger.camIsHealthy.store(true);
    }
    if (!logger.threadMngrIsHealthy.load(std::memory_order_relaxed)) {
        tryReconnectThreadManager(dataControl);
    }
    if (!logger.databaseIsHealthy.load(std::memory_order_relaxed) && paramCtx.UseHistoryDatabase.load()) {
        tryReconnectDatabase(databaseConnection);
	}
    if (!logger.sqlDatabaseIsHealthy.load(std::memory_order_relaxed) && paramCtx.UseDatabase.load()) {
        tryReconnectSQLDatabase(mysqlConnection);
    }
}

bool ApplicationReconnector::allowAttempt(RetryState& state) {
    auto now = std::chrono::steady_clock::now();
    if (state.lastAttempt == std::chrono::steady_clock::time_point::min()) {
        return true;
    }
    if (now - state.lastAttempt >= state.backoffMs) {
        return true;
    }
    return false;
}

void ApplicationReconnector::updateBackoffOnFailure(RetryState& state) {
    state.attemptCount++;
    int ms = BASE_BACKOFF_MS * (1 << (std::min)(state.attemptCount - 1, 6));
    if (ms > MAX_BACKOFF_MS) ms = MAX_BACKOFF_MS;
    state.backoffMs = std::chrono::milliseconds(ms);
    state.lastAttempt = std::chrono::steady_clock::now();
}

void ApplicationReconnector::resetBackoffOnSuccess(RetryState& state) {
    state.attemptCount = 0;
    state.backoffMs = std::chrono::milliseconds(0);
    state.lastAttempt = std::chrono::steady_clock::time_point::min();
}

void ApplicationReconnector::tryReconnectPlc(PlcContext& plcCtx) {
    if (!allowAttempt(plcState)) return;

    plcState.lastAttempt = std::chrono::steady_clock::now();

    uint16_t enc;
    bool success = true;

    if (!plcCtx.read(encoderPickVarName, enc)) {
        if (plcCtx.isConnected()) {
            logger.pushMsg("PLC read failed but connection is active.");
            success = false;
        }
        else {
            logger.pushMsg("PLC connection lost, attempting to reconnect...");
            plcCtx.close();
            if (plcCtx.open()) {
                logger.pushMsg("PLC successfully reconnected.");
                success = true;
            }
            else {
                logger.pushMsg("Failed to reconnect PLC using ADS");
                success = false;
            }
        }
    }

    if (success) {
        logger.plcIsHealthy.store(true);
        resetBackoffOnSuccess(plcState);
    }
    else {
        logger.plcIsHealthy.store(false);
        updateBackoffOnFailure(plcState);
    }
}

void ApplicationReconnector::tryReconnectCamera(CameraContext& camCtx) {
    if (!allowAttempt(stalkCamState)) return;
    stalkCamState.lastAttempt = std::chrono::steady_clock::now();

    bool success = false;
    CloseCamera(camCtx);
    if (OpenCamera(camCtx, paramCtx, logger)) {
        logger.pushMsg("Camera successfully reopened.");
        success = true;
    }
    else {
        logger.pushMsg("Failed to reopen camera.");
        success = false;
    }

    if (success) {
        logger.camIsHealthy.store(true);
        resetBackoffOnSuccess(stalkCamState);
    }
    else {
        logger.camIsHealthy.store(false);
        updateBackoffOnFailure(stalkCamState);
    }
    
}

void ApplicationReconnector::tryReconnectThreadManager(ThreadManager& dataControl) {
    if (!allowAttempt(threadState)) return;
    threadState.lastAttempt = std::chrono::steady_clock::now();

    bool success = false;
    if (dataControl.start()) { // assume start() restarts threads if needed
        logger.pushMsg("Controller threads started/restarted successfully.");
        success = true;
    }
    else {
        logger.pushMsg("Failed to start controller threads.");
        success = false;
    }

    if (success) {
        logger.threadMngrIsHealthy.store(true);
        resetBackoffOnSuccess(threadState);
    }
    else {
        logger.threadMngrIsHealthy.store(false);
        updateBackoffOnFailure(threadState);
    }
}

void ApplicationReconnector::tryReconnectDatabase(PostgresSQL& databaseConnection) {
    if (!allowAttempt(dbState)) return;

    dbState.lastAttempt = std::chrono::steady_clock::now();
    bool success = false;

    databaseConnection.close();

    try {
        databaseConnection.open();
        logger.pushMsg("Database connection successfully reopened.");
        success = true;
    }
    catch (const std::exception& e) {
        logger.pushMsg(std::string("Failed to reopen database connection: ") + e.what());
        success = false;
    }
    if (success) {
        logger.databaseIsHealthy.store(true);
        resetBackoffOnSuccess(dbState);
    }
    else {
        logger.databaseIsHealthy.store(false);
        updateBackoffOnFailure(dbState);
    }
}
void ApplicationReconnector::tryReconnectSQLDatabase(MySQL& databaseConnection) {
    if (!allowAttempt(sqlDbState)) return;

    sqlDbState.lastAttempt = std::chrono::steady_clock::now();
    bool success = false;

    databaseConnection.close();

    try {
        success = databaseConnection.open();   // retourneert false als de server onbereikbaar is
        if (success) logger.pushMsg("MySQL connection successfully reopened.");
    }
    catch (const std::exception& e) {
        logger.pushMsg(std::string("Failed to reopen MySQL connection: ") + e.what());
        success = false;
    }
    if (success) {
        logger.sqlDatabaseIsHealthy.store(true);
        resetBackoffOnSuccess(sqlDbState);
    }
    else {
        logger.sqlDatabaseIsHealthy.store(false);
        updateBackoffOnFailure(sqlDbState);
    }
}