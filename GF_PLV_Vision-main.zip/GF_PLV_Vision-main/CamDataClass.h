#pragma once

enum CamDataClass : int {
    Empty = 0,
    Valid = 1,
    Reprocess = 2,
    Recheck = 3,
    InValid = 4
};