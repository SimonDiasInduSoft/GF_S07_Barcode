#pragma once

#include <thread>
#include <atomic>
#include <vector>
#include <iostream>
#include <memory>
#include <utility>
#include <cstddef>
#include <string>
#include <mutex>

//forward declarations
class CameraContext;
class CommandHandler;
class PlcContext;
class Logger;
class PostgresSQL;
class YoloDetector;
class Parameters;
class ImageRecognition;
class Calibration;
class FileManager;
class MySQL;
class SessionManager;

// Conveyer controller class
class ThreadManager {
    public:
        ThreadManager(CommandHandler& buf, CameraContext& stalkCamCtx, PlcContext& plcCtx, Logger& loggerCtx, PostgresSQL& dbConnection, YoloDetector& detect, Parameters& paramCtx, ImageRecognition& analysis, FileManager& fileManager, MySQL& mySQL, SessionManager& sessionManager):
            cmdHandler(buf), stalkCamCtx(stalkCamCtx), 
            plcContext(plcCtx), loggerCtx(loggerCtx), dbConnection(dbConnection),
            detectionModel(detect), paramCtx(paramCtx),
            analysisAPI(analysis), fileManager(fileManager), mySQL(mySQL), sessionManager(sessionManager) {
        }
        ~ThreadManager() {
            stop();
        };

        bool init();
        void shutdown();
        bool start();
        bool stop();
        void joinAllThreads();

        std::atomic<bool> running{ false };
        std::atomic<bool> initialized{ false };

    private:
        ImageRecognition& analysisAPI;

        CommandHandler& cmdHandler;
        YoloDetector& detectionModel;
        PlcContext& plcContext;
        Logger& loggerCtx;
        PostgresSQL& dbConnection;
        CameraContext& stalkCamCtx;
        Parameters& paramCtx;
		FileManager& fileManager;
		MySQL& mySQL;
		SessionManager& sessionManager;

        //Threads
        std::thread imageProcessingThread;

        std::thread CameraThread;
        std::thread stalkEncoderThread;

        std::thread handleRcCommandThread;
        std::thread handleSndCommandThread;

        std::thread databaseThread;
        std::thread sqlDatabaseThread;
        std::thread checkPlcHealthThread;

        std::thread simulationHandleSndCommandThread;

		std::thread fileHandlingThread;

        // Data ontvangen van PLC via cmd 10
        struct PlcTriggerData {
            std::string frCodePlc;
            int         sequenceNumber = 0;
        };
        PlcTriggerData lastTriggerData;
        std::mutex     triggerDataMutex;

		//Parameters
		std::string receiveCommandVarName;
		std::string sendCommandVarName;
		std::string camHealthCommandVarName;
		std::string rawImagePath;

        void CameraLoop();
        void CameraTriggerLoop();
        void cameraAcquisitionLoop();

        void imageProcessingLoop();

        void handleRcCommandLoop();
        void handleSndCommandLoop();
        void checkPlcHealthLoop();

        void databaseLoop();
        void sqlDatabaseLoop();

        void simulationHandleSndCommandLoop();
        void simulationCameraTriggerLoop();
        
		void fileHandlingLoop();
};

