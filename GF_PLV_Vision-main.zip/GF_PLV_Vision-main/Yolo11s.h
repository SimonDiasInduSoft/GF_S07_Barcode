#pragma once

#include <vector>
#include <string>
#include <memory>

#include "ObjectDetection.h"

#include <opencv2/core.hpp>

#include <onnxruntime_cxx_api.h>

// Forward declaration
class Parameters;

class YoloDetector {
public:
    YoloDetector(Parameters& paramCtx);

    std::vector<ObjectDetection> detect(const cv::Mat& frame);
    void drawDetections(cv::Mat& frame,
        const std::vector<ObjectDetection>& detections,
        const std::vector<std::string>& labels);

private:
    void preprocess(const cv::Mat& frame, cv::Mat& blob);
    std::vector<ObjectDetection> postprocess(const cv::Mat& frame, const cv::Mat& output);

    Parameters& ParametersCtx;

    Ort::Env env_;
    Ort::SessionOptions sessionOptions_;
    std::unique_ptr<Ort::Session> session_;

    int inputWidth_ = 640;
    int inputHeight_ = 640;
};
