#pragma once

#include <string>
#include <unordered_map>

class Parameters;
class PostgresSQL;
class Logger;

class SettingsHistory {
public:
    SettingsHistory(Parameters& paramCtx, PostgresSQL& db, Logger& loggerCtx)
        : ParametersCtx(paramCtx), Db(db), LoggerContext(loggerCtx) {}

    void initBaseline();
    int poll();

private:
    std::unordered_map<std::string, std::string> snapshot() const;

    Parameters&  ParametersCtx;
    PostgresSQL& Db;
    Logger&      LoggerContext;

    std::unordered_map<std::string, std::string> last_;

    std::unordered_map<std::string, std::string> type_;
    bool hasBaseline_ = false;
};
