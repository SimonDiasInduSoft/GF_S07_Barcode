﻿#include <iostream>
#include <atomic>
#include <csignal>
#include <thread>
#include <chrono>
#include <string>
#include <vector>
#include <memory>
#include <mutex>

#include "ImageRecognition.h"
#include "PlcContext.h"
#include "VaLinker.h"
#include "Parameters.h"
#include "CameraContext.h"
#include "CalibrationContext.h"
#include "CommandHandler.h"
#include "PXMMCalibration.h"
#include "Yolo11s.h"
#include "ThreadManager.h"
#include "Logger.h"
#include "ApplicationReconnector.h"
#include "PostgresSQL.h"
#include "FileManager.h"
#include "PostgresCommand.h"
#include "CommandStatus.h"
#include "MySQL.h"
#include "SessionManager.h"
#include "ConfigFile.h"
#include "LiveState.h"
#include "AppUI.h"
#include "SettingsHistory.h"
#include "ErrorHandler.h"

#include <opencv2/core/utils/logger.hpp>

using namespace cv;
using namespace std;

std::atomic<bool> g_running(true);

void signalHandler(int signum)
{
    g_running = false;
}

int main(int argc, char** argv)
{
    signal(SIGINT, signalHandler);   // CTRL+C
    signal(SIGTERM, signalHandler);  // Termination request
    signal(SIGABRT, signalHandler);  // Abort signal

    cv::utils::logging::setLogLevel(cv::utils::logging::LOG_LEVEL_ERROR);

    // Initiate parameters and setup mapper
    Parameters parameterContext;
    parameterContext.initMaps();

    // Create logger & reconnector
    Logger loggerContext;
    ApplicationReconnector reconnector(loggerContext, parameterContext);
    std::cout << "=== System Starting ===" << std::endl;

    // Settings: alles uit config.json
    ConfigFile config(parameterContext, loggerContext);
    const std::string configPath = "config.json";
    if (!config.load(configPath)) {
        std::cout << "config.json niet gevonden/ongeldig - defaults wegschrijven\n";
        config.save(configPath);
    }

    // Applicatie start ALTIJD in run (analyse aan), ongeacht wat in config.json staat.
    parameterContext.StartAnalysis.store(true);

    // UI
    LiveState liveState;
    AppUI appUI(parameterContext, loggerContext, liveState, configPath);
    appUI.start();

	// Database connections
    PostgresSQL dbConnection(parameterContext, loggerContext);
    SettingsHistory settingsHistory(parameterContext, dbConnection, loggerContext);
    MySQL mysqlConnection(parameterContext, loggerContext);
    SessionManager session(parameterContext.LineNr.load());

    if (parameterContext.UseHistoryDatabase.load()) {
        dbConnection.open();
        std::cout << "Settings-history database verbonden\n";
    }

    if (parameterContext.UseDatabase.load()) {
        if (!mysqlConnection.open())
            loggerContext.sqlDatabaseIsHealthy = false;
        else {
            session.init(mysqlConnection);
            std::cout << "MySQL results database connected successfully\n";
        }
    }

    settingsHistory.initBaseline();

    // Initiate filemanager
    std::cout << "Loading file save states\n";
    FileManager fileManager(parameterContext, loggerContext);

    // PLC context
    PlcContext plc(loggerContext, parameterContext);

    if (parameterContext.UsePlc.load()) {
        if (!plc.open()) {
            loggerContext.pushMsg("FATAL: Failed to connect to PLC\n");
            loggerContext.plcIsHealthy = false;
        }
        else std::cout << "PLC connected successfully\n";
    }

    // Load errorHandler
    ErrorHandler errorHandler(loggerContext, parameterContext, plc);

    // Load object detection model
    YoloDetector detector(parameterContext);

    // Eén camera (geen lijst). Context wordt altijd aangemaakt; enkel bij
    // UseCamera wordt het fysieke toestel geopend.
    std::shared_ptr<CameraContext> cameraPtr = createCameraContext(parameterContext);
    CameraContext* cameraCtx = cameraPtr.get();

    if (parameterContext.UseCamera.load()) {
        if (!OpenCamera(*cameraCtx, parameterContext, loggerContext)) {
            loggerContext.pushMsg("FATAL: Failed to open " + cameraCtx->name + " camera");
            loggerContext.camIsHealthy = false;
        }
        else {
            std::cout << cameraCtx->name + " camera opened successfully\n";
        }
    }

    // Create buffer manager
    CommandHandler cmdHandler(*cameraCtx, loggerContext, parameterContext, mysqlConnection, session);
    // Create ImageRecognition API (publiceert het live-beeld naar de UI)
    ImageRecognition analysisAPI(*cameraCtx->calibCtx, parameterContext, detector, fileManager, loggerContext, liveState);
    // Create controller
    ThreadManager dataController(cmdHandler, *cameraCtx,
        plc, loggerContext, dbConnection,
        detector, parameterContext, analysisAPI,
        fileManager, mysqlConnection, session);

    if (!dataController.init()) {
        loggerContext.pushMsg("FATAL: Failed to Threadmanager.\n");
        loggerContext.threadMngrIsHealthy = false;
    }

    std::cout << "\n=== System Running ===" << std::endl;
    std::cout << "Press CTRL+C to shutdown safely" << std::endl;

    // Main monitoring loop
    while (g_running) {
        if (parameterContext.ShutDownAnalysis.load() == true)
            g_running = false;

        // Start/Stop wordt rechtstreeks door StartAnalysis gestuurd (UI-knoppen).
        if (parameterContext.StartAnalysis.load() == true && dataController.running == false)
            dataController.start();
        if (parameterContext.StartAnalysis.load() == false && dataController.running == true)
            dataController.stop();

        // Debug-logs volgen de DebugMode-toggle.
        loggerContext.verbose.store(parameterContext.DebugMode.load());

        // Settings-history
        if (parameterContext.UseHistoryDatabase.load())
            settingsHistory.poll();

        // Fouten vasthouden, herstellen en daarna foutstatus naar PLC sturen
        errorHandler.sample();
        reconnector.reconnectionProtocol(plc, *cameraCtx, dataController, dbConnection, mysqlConnection);
        errorHandler.update();
        // Console = enkel logs (health/uptime worden live in de UI getoond).
        loggerContext.drainLogsToConsole();

        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    // Shutdown
    std::cout << "\n=== Beginning Shutdown Sequence ===" << std::endl;

    std::cout << "Stopping controller threads..." << std::endl;
    dataController.shutdown();

    // Stop UI
    std::cout << "Closing UI..." << std::endl;
    appUI.stop();

    if (parameterContext.UsePlc.load()) {
        std::cout << "Closing ADS connection..." << std::endl;
        plc.close();
    }

    if (parameterContext.UseHistoryDatabase.load()) {
        std::cout << "Stopping history database..." << std::endl;
        dbConnection.close();
    }
    if (parameterContext.UseDatabase.load()) {
        std::cout << "Stopping results database..." << std::endl;
        mysqlConnection.close();
    }

    if (parameterContext.UseCamera.load() && cameraCtx) {
        std::cout << "Closing camera's..." << std::endl;
        CloseCamera(*cameraCtx);
    }

    std::cout << "=== Shutdown Complete ===" << std::endl;

    return EXIT_SUCCESS;
}
