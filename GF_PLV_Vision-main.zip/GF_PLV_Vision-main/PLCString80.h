#pragma once

struct PLCString80 {
	char data[81] = {};
};