#pragma once

#include <string>
#include <cstdint>

#include <opencv2/core.hpp>

enum class OkCode {
	Init = 0,
	NOK = 1,
	CardboardAndLabel = 2,
	LabelOnly = 3,
	CardboardOnly = 4,
	NoCheck = 5,
	OMAOverride = 6, // alleen in HMI gebruikt
    CamDisabled = 7
};

struct AnalysedImage {
    // Sessie info
    int         sessieId = 0;
    uint8_t     sequenceNr = 1;
    uint8_t     lineNr = 0;

    // Paden & codes
    std::string filePath;
    std::string frCodePlc;

    // Finaal na validatie
    std::string frCodeImageCardboard;
    std::string frCodeImageLabel;
    std::string barcodeCardboard;
    std::string barcodeLabel;

    // Resultaat
	uint32_t     resultaat = 0; // 1 Niet Goed - 2 Goed met doos + label - 3 Goed met label - 4 Goed met doos - 5 Goed met geen doos en geen label
    std::string noReason;

    // Manuele override door operator
    std::string omaName;
    std::string omaReason;

    // Beeld
    cv::Mat anotatedImg;

    // useLabel: FR label vs PLC, useCardboard: FR karton vs PLC, beide: alle drie gelijk.
    void finalize(bool useLabel, bool useCardboard) {
        if (!useLabel && !useCardboard) {
            resultaat = static_cast<uint32_t>(OkCode::NoCheck);
            return;
        }

        bool frCodeOk = !frCodePlc.empty();
        if (useLabel)
            frCodeOk = frCodeOk && !frCodeImageLabel.empty() && frCodeImageLabel == frCodePlc;
        if (useCardboard)
            frCodeOk = frCodeOk && !frCodeImageCardboard.empty() && frCodeImageCardboard == frCodePlc;

        resultaat = frCodeOk ? static_cast<uint32_t>(OkCode::Init) : static_cast<uint32_t>(OkCode::NOK);

        if (resultaat == static_cast<uint32_t>(OkCode::Init)) {
            if (useCardboard && useLabel) {
                resultaat = static_cast<uint32_t>(OkCode::CardboardAndLabel);
            }
            else if (!useCardboard && useLabel) {
                resultaat = static_cast<uint32_t>(OkCode::LabelOnly);
            }
            else if (useCardboard && !useLabel) {
				resultaat = static_cast<uint32_t>(OkCode::CardboardOnly);
            }
        }
    }
};