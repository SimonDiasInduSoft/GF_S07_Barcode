#pragma once

#include <string>

struct Parameter {
	std::string Name;
	std::string Type;
	std::string Value;
	std::string PreviousValue;
	std::string ChangedBy;
};