#pragma once

#ifndef WINDOWS_MINIMAL_H
#define WINDOWS_MINIMAL_H

// Define these BEFORE any Windows header is included anywhere
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN

// Exclude rarely-used stuff from Windows headers
#define NOGDICAPMASKS
#define NOVIRTUALKEYCODES
#define NOWINMESSAGES
#define NOWINSTYLES
#define NOSYSMETRICS
#define NOMENUS
#define NOICONS
#define NOKEYSTATES
#define NOSYSCOMMANDS
#define NORASTEROPS
#define NOSHOWWINDOW
#define OEMRESOURCE
#define NOATOM
#define NOCLIPBOARD
#define NOCOLOR
#define NOCTLMGR
#define NODRAWTEXT
#define NOGDI
#define NOKERNEL
#define NOMB
#define NOMEMMGR
#define NOMETAFILE
#define NOOPENFILE
#define NOSCROLL
#define NOSERVICE
#define NOSOUND
#define NOTEXTMETRIC
#define NOWH
#define NOWINOFFSETS
#define NOCOMM
#define NOKANJI
#define NOHELP
#define NOPROFILER
#define NODEFERWINDOWPOS
#define NOMCX

#include <Windows.h>

// Clean up the damage
#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

// If you need specific Windows functions, include their headers here
// For example:
// #include <winreg.h>  // Only if you actually use registry functions

#endif // WINDOWS_MINIMAL_H
