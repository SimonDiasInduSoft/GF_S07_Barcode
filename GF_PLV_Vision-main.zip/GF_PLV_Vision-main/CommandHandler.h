#pragma once

#include <vector>
#include <mutex>
#include <queue>
#include <string>
#include <string_view>
#include <iostream>
#include <memory>
#include <utility>
#include <cstddef>
#include <cstdint>
#include <optional>

#include "CommandStatus.h"
#include "SndCommand.h"
#include "RcCommand.h"
#include "PlcCamData.h"
#include "AnalysedImage.h"
#include "PLCString80.h"

//Forward declaration
class CameraContext;
class Logger;
class Parameters;
class MySQL;
class SessionManager;
struct PostgresCommand;

class CommandHandler {
public:
    CommandHandler(CameraContext& stalkCam, Logger& loggerCtx, Parameters& paramCtx, MySQL& mySQL, SessionManager& sessionManager):
        StalkCameraCtx(stalkCam), LoggerCtx(loggerCtx), ParametersCtx(paramCtx), MySQLCtx(mySQL), SessionMngr(sessionManager) {
    }

    bool peekCommand(SndCommand& out);
    void pushCommand(const SndCommand& cmd);
    void popCommand();
    size_t commandQueueSize();

    // cmdCode: configureerbare trigger-code (Parameters::SendTriggerCmdCode), i.p.v. hardcoded CommandStatus.
    SndCommand analysedImageToSndCommand(const AnalysedImage& analysedImage, uint16_t cmdCode);
    PLCString80 toPlcString80(const std::string& str);

    // Camera disabled: geen analyse, direct resultaat CamDisabled (7) naar PLC + DB
    void pushCamDisabledResult(const std::string& frCodePlc, int volgnummer);

    // public props
    CameraContext& StalkCameraCtx;
    Logger& LoggerCtx;

private:
    const size_t MAX_LOG_MESSAGES = 1000;

	std::queue<SndCommand> CommandQueue;
    std::mutex CommandQueueMutex;

	Parameters& ParametersCtx;
	MySQL& MySQLCtx;
	SessionManager& SessionMngr;
};
