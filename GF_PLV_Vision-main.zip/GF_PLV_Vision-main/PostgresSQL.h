#pragma once

#include <deque>
#include <mutex>

#include <string>
#include <string_view>
#include <vector>
#include <iostream>
#include <memory>
#include <utility> 
#include <cstddef> 
#include <condition_variable>

#include <pqxx/pqxx>

#include "PostgresCommand.h"
#include "Parameters.h"

//Forward declaration
struct PlcCamData;

class Logger;

class PostgresSQL {
	public:
		PostgresSQL(Parameters& paramCtx, Logger& loggerContext) :  
			LoggerContext(loggerContext), ParametersCtx(paramCtx) {}

		void open();
		void close();

		bool addCommand(const PostgresCommand& pgCmd);

		bool pushToQueue(PostgresCommand pgCmd);
		bool processNextCommand();

		bool isQueueEmpty();

		void resetClientAnswer();

		// Connection
		std::unique_ptr<pqxx::connection> Connection;

		// Beschermt de connectie zelf: worker-thread (addCommand) en reconnect
		// (open/close) mogen ze nooit tegelijk aanraken.
		std::mutex ConnMutex;

		std::deque<PostgresCommand> DbQueue;
		std::mutex DbQueueMutex;
		std::condition_variable DbQueueCV;
	private:
		Logger& LoggerContext;

		const size_t MAX_LOG_MESSAGES = 1000;

		Parameters& ParametersCtx;
};