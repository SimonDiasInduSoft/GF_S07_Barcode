#include "CommandHandler.h"

#include <vector>
#include <mutex>
#include <algorithm>
#include <chrono>
#include <atomic>
#include <queue>
#include <string>
#include <iostream>
#include <memory>
#include <utility>
#include <cstddef>
#include <optional>

#include "PlcCamData.h"
#include "SndCommand.h"
#include "RcCommand.h"
#include "CalibrationContext.h"
#include "CameraContext.h"
#include "CommandStatus.h"
#include "Logger.h"
#include "PostgresSQL.h"
#include "PostgresCommand.h"
#include "CamDataClass.h"
#include "Parameters.h"
#include "Parameter.h"
#include "AnalysedImage.h"
#include "PLCString80.h"
#include "MySQL.h"
#include "SessionManager.h"


SndCommand CommandHandler::analysedImageToSndCommand(const AnalysedImage& analysedImage, uint16_t cmdCode) {
    SndCommand cmd;
    cmd.iCmd = cmdCode;

    // FR codes naar PLC sturen
    cmd.asArg[0] = toPlcString80(analysedImage.frCodeImageCardboard);
    cmd.asArg[1] = toPlcString80(analysedImage.frCodeImageLabel);

    // Barcodes naar PLC sturen
    cmd.asArg[2] = toPlcString80(analysedImage.barcodeCardboard);
    cmd.asArg[3] = toPlcString80(analysedImage.barcodeLabel);

    // Resultaat
    cmd.adArg[0] = analysedImage.resultaat;

    // NOK reden (leeg bij OK)
    cmd.asArg[4] = toPlcString80(analysedImage.noReason);

    return cmd;
}

void CommandHandler::pushCamDisabledResult(const std::string& frCodePlc, int volgnummer) {
    // volgnummer == 1 → nieuwe sessie, anders retry binnen zelfde sessie.
    if (volgnummer <= 1)
        SessionMngr.newCapture();
    else
        SessionMngr.setTry(volgnummer);

    // Geen finalize(): die zou CamDisabled overschrijven
    AnalysedImage result;
    result.frCodePlc  = frCodePlc;
    result.sessieId   = SessionMngr.getSessionId();
    result.sequenceNr = SessionMngr.getSequenceNr();
    result.lineNr     = SessionMngr.getLineNr();
    result.resultaat  = static_cast<uint32_t>(OkCode::CamDisabled);
    result.noReason   = "Camera disabled";

    // MySQL: ook disabled-runs wegschrijven
    if (ParametersCtx.UseDatabase.load()) {
        PostgresCommand pgCmd;
        pgCmd.analysedImage = result;
        pgCmd.CmdStatus = CommandStatus::SendBarcodeCmd;
        if (!MySQLCtx.pushToQueue(pgCmd))
            LoggerCtx.pushMsg("Failed to insert command to MySQL queue", LogLevel::Error);
    }

    // Resultaat terug naar PLC
    pushCommand(analysedImageToSndCommand(result, static_cast<uint16_t>(ParametersCtx.SendTriggerCmdCode.load())));

    LoggerCtx.commandsCreated.fetch_add(1);
}

PLCString80 CommandHandler::toPlcString80(const std::string& str) {
    PLCString80 result = {};
    size_t len = std::min(str.size(), size_t(81));
    std::memcpy(result.data, str.c_str(), len);
    result.data[len] = '\0';
    return result;
}

bool CommandHandler::peekCommand(SndCommand& out) {
    std::lock_guard<std::mutex> lock(CommandQueueMutex);

    if (!CommandQueue.empty()) {
        out = CommandQueue.front();
        return true;
    }
    else return false;
}

void CommandHandler::pushCommand(const SndCommand& cmd)
{
    std::lock_guard<std::mutex> lock(CommandQueueMutex);

    if (CommandQueue.size() >= MAX_LOG_MESSAGES) {
        LoggerCtx.pushMsg("Buffer vol. Er is een probleem met de communicatie PLC - Analyse");
        CommandQueue.pop();
    }
    CommandQueue.push(cmd);
}

void CommandHandler::popCommand()
{
    std::lock_guard<std::mutex> lock(CommandQueueMutex);
    if (!CommandQueue.empty()) CommandQueue.pop();
}

size_t CommandHandler::commandQueueSize()
{
    std::lock_guard<std::mutex> lock(CommandQueueMutex);
    return CommandQueue.size();
}