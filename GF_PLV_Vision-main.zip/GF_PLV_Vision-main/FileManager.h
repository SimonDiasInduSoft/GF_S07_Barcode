#pragma once

#include "SaveState.h"

#include <string>
#include <vector>
#include <utility>
#include <unordered_map>
#include <filesystem>
#include <optional>
#include <queue>
#include <mutex>
#include <condition_variable>

#include "FileJob.h"

#include <opencv2/core.hpp>  

namespace fs = std::filesystem;

//Forward declaration
class Parameters;
class Logger;

enum class SaveCategory;

// FileManager
class FileManager {
	public:
        FileManager(Parameters& paramCtx, Logger& logger) : ParamCtx(paramCtx), logger(logger) {
			snapshotPaths();
            initSaveStates();
        };

		void snapshotPaths();

		void initSaveStates();
        void initSaveState(SaveState& state);
        void addSaveState(SaveCategory cat, const std::string& path);

        std::pair<int, int> getCurrentFolderAndFileIndex(const fs::path& baseFolder);

        bool saveImage(const cv::Mat& image, const fs::path fullPath, int jpegQuality = 85);

        std::string enqueueImage(SaveCategory cat, const cv::Mat& image, const std::string& fileType, bool doResize = false);
        // Volledige resolutie naast basePath opslaan als <stem>_HD<ext> (geen nieuwe index)
        std::string enqueueHdImage(SaveCategory cat, const cv::Mat& image, const std::string& basePath);

        std::unordered_map<SaveCategory, std::unique_ptr<SaveState>> saveStates;

        std::string AnalysedImagesPath;
        std::string RawImagePath;

        // Threading
        std::mutex fileManagerMutex;
		std::condition_variable fileManagerCV;

        std::queue<FileJob> fileQueue;
        static constexpr size_t FILE_MAX_QUEUE_SIZE = 20;
	private:
        std::optional<std::pair<fs::path, std::string>> getPaths(SaveCategory cat, const std::string& fileType);

		Parameters& ParamCtx;
        Logger& logger;
};
