#pragma once

struct PlcConfig {
    int handshakeTimeoutMs = 5000;
    int pollIntervalMs = 5;
    size_t maxStringLength = 256;
};