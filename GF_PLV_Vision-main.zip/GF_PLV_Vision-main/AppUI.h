#pragma once

#include <atomic>
#include <string>
#include <thread>
#include <mutex>

#include <opencv2/core.hpp>

class Parameters;
class Logger;
struct LiveState;

class AppUI {
public:
    AppUI(Parameters& params, Logger& logger, LiveState& live, std::string configPath = "config.json");
    ~AppUI();

    void start();
    void stop();

    bool isRunning() const { return running_.load(); }

private:
    void runLoop();
    void applyTheme();
    void renderFrame();

public:
    enum ToastType { ToastInfo = 0, ToastSuccess = 1, ToastError = 2 };
    void showToast(const std::string& msg, ToastType type = ToastInfo);
private:
    void renderToast();

    void pageLive();
    void pageSettings();

    void sectionConnections();
    void sectionCamera();
    void sectionParameters();
    void sectionRecipe();
    void liveControls();
    void renderHealth();

    void uploadLiveTexture();

    int  page_ = 0;

    // Toast state
    std::string toastMsg_;
    double      toastTime_ = -1000.0;
    int         toastType_ = 0;
    unsigned long long lastErrorSeen_ = 0;

    Parameters& params_;
    Logger&     logger_;
    LiveState&  live_;
    std::string configPath_;

    std::thread       thread_;
    std::atomic<bool> running_{ false };

    void* window_ = nullptr;
    unsigned int liveTexture_ = 0;
    unsigned long long lastFrameVersion_ = 0;
    std::string status_;
};
