#include <string>
#include <memory>

#include "MinimalWindows.h"

#include "VaLinker.h"
#include "ImageRecognition.h"
#include "CameraContext.h"
#include "Logger.h"
#include "Parameters.h"

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/calib3d.hpp>

#include <nlohmann/json.hpp>
using json = nlohmann::json;

void CheckCamParameters(std::vector<CGXDevicePointer>& vectorDevPtr, std::vector<CGXFeatureControlPointer>& vectorRemoteControl)
{
    std::cout << "check is all device support ActionCommand and PTP" << std::endl;

    bool bIsAllDevSupport = true;
    for (int i = 0; i < (int)vectorRemoteControl.size(); i++)
    {
        gxstring_vector vecEnumValue = vectorRemoteControl[i]->GetEnumFeature("GevSupportedOptionSelector")->GetEnumEntryList();

        bool bActionItemExist = false;
        bool bScheduledActionItemExist = false;
        bool bPtpItemExist = false;

        bool bActionSupport = false;
        bool bScheduledActionSupport = false;
        bool bPtpSupport = false;

        for (int j = 0; j < vecEnumValue.size(); j++)
        {
            if (strcmp(vecEnumValue[j].c_str(), "Action") == 0)
            {
                bActionItemExist = true;
            }

            if (strcmp(vecEnumValue[j].c_str(), "ScheduledAction") == 0)
            {
                bScheduledActionItemExist = true;
            }

            if (strcmp(vecEnumValue[j].c_str(), "Ptp") == 0)
            {
                bPtpItemExist = true;
            }
        }

        if (bActionItemExist && bScheduledActionItemExist && bPtpItemExist)
        {
            vectorRemoteControl[i]->GetEnumFeature("GevSupportedOptionSelector")->SetValue("Action");

            bActionSupport = vectorRemoteControl[i]->GetBoolFeature("GevSupportedOption")->GetValue();

            vectorRemoteControl[i]->GetEnumFeature("GevSupportedOptionSelector")->SetValue("ScheduledAction");

            bScheduledActionSupport = vectorRemoteControl[i]->GetBoolFeature("GevSupportedOption")->GetValue();

            vectorRemoteControl[i]->GetEnumFeature("GevSupportedOptionSelector")->SetValue("Ptp");

            bPtpSupport = vectorRemoteControl[i]->GetBoolFeature("GevSupportedOption")->GetValue();

            if (bActionSupport && bScheduledActionSupport && bPtpSupport)
            {
                // current cam support Action ScheduledAction Ptp
            }
            else
            {
                gxstring strSN = vectorDevPtr[i]->GetDeviceInfo().GetSN();
                std::cout << "SN:" << strSN.c_str() << " don't support ActionCommand or PTP" << std::endl;
                bIsAllDevSupport = false;
            }
        }
        else
        {
            gxstring strSN = vectorDevPtr[i]->GetDeviceInfo().GetSN();
            std::cout << "SN:" << strSN.c_str() << " don't support ActionCommand or PTP" << std::endl;
            bIsAllDevSupport = false;
        }
    }

    if (!bIsAllDevSupport)
    {
        throw CGalaxyException(GX_STATUS_ERROR, "not all cam support ActionCommand and PTP");
    }
    else
    {
        std::cout << "successful check, all device support ActionCommand and PTP" << std::endl;
    }
}

void SetCamParametersAndStartAcquisition(std::vector<CGXDevicePointer>& vectorDevPtr
    , std::vector<CGXFeatureControlPointer>& vectorRemoteControl
    , std::vector<CGXStreamPointer>& vectorStream)
{
    std::cout << "setting cam ActionCommand parameters" << std::endl;

    for (int i = 0; i < (int)vectorRemoteControl.size(); i++)
    {
        // Load default parameter group
        vectorRemoteControl[i]->GetEnumFeature("UserSetSelector")->SetValue("Default");

        vectorRemoteControl[i]->GetCommandFeature("UserSetLoad")->Execute();

        // Trigger Mode On
        vectorRemoteControl[i]->GetEnumFeature("TriggerMode")->SetValue("On");

        // Trigger source set to Action0
        vectorRemoteControl[i]->GetEnumFeature("TriggerSource")->SetValue("Action0");

        // Setting cam ActionCommand parameters
        vectorRemoteControl[i]->GetIntFeature("ActionDeviceKey")->SetValue(1);

        vectorRemoteControl[i]->GetIntFeature("ActionGroupKey")->SetValue(1);

        vectorRemoteControl[i]->GetIntFeature("ActionGroupMask")->SetValue(0xFFFFFFFF);

        // Start Acquisition
        vectorStream[i]->StartGrab();

        vectorRemoteControl[i]->GetCommandFeature("AcquisitionStart")->Execute();
    }

    std::cout << "setting success" << std::endl;
}

cv::Mat ShowActionCommand(std::vector<CGXDevicePointer>& vectorDevPtr,
    std::vector<CGXStreamPointer>& vectorStream,
    GX_GIGE_ACTION_COMMAND_RESULT** pResultBuffer)
{
    std::cout << "Demonstrating ActionCommand function..." << std::endl;

    uint32_t ui32DeviceKey = 1;
    uint32_t ui32GroupKey = 1;
    uint32_t ui32GroupMask = 0xFFFFFFFF;
    gxstring strSpecialIP = "";
    uint32_t ui32NumResult = (uint32_t)vectorDevPtr.size();
    *pResultBuffer = new GX_GIGE_ACTION_COMMAND_RESULT[ui32NumResult];

    // Broadcast to all cameras
    gxstring strIP = "255.255.255.255";

    IGXFactory::GetInstance().GigEIssueActionCommand(
        ui32DeviceKey, ui32GroupKey, ui32GroupMask,
        strIP, strSpecialIP, 500, &ui32NumResult, *pResultBuffer);

    // Print acknowledgments
    for (uint32_t i = 0; i < ui32NumResult; i++)
    {
        std::cout << "Ack Return IP: " << (*pResultBuffer)[i].DeviceAddress
            << " Status: " << (*pResultBuffer)[i].nStatus << std::endl;
    }

    cv::Mat outputImage;

    // Retrieve the image from the stream
    for (int i = 0; i < (int)vectorDevPtr.size(); i++)
    {
        CImageDataPointer objImagePtr = vectorStream[i]->DQBuf(1000);
        if (objImagePtr.IsNull())
        {
            std::cerr << "Failed to dequeue image buffer!" << std::endl;
            continue;
        }

        if (objImagePtr->GetStatus() != GX_FRAME_STATUS_SUCCESS)
        {
            std::cerr << "Incomplete frame received!" << std::endl;
            vectorStream[i]->QBuf(objImagePtr);
            continue;
        }

        uint8_t* buffer = (uint8_t*)objImagePtr->GetBuffer();
        int width = objImagePtr->GetWidth();
        int height = objImagePtr->GetHeight();

        // Convert Daheng image to OpenCV cv::Mat (8-bit grayscale)
        outputImage = cv::Mat(height, width, CV_8UC1, buffer).clone();

        // Return buffer to camera stream
        vectorStream[i]->QBuf(objImagePtr);

        std::cout << "Grabbed " << width << "x" << height << " mono image successfully.\n";
    }

    return outputImage;
}

void StopAcquisitionAndCloseCam(std::vector<CGXDevicePointer>& vectorDevPtr
    , std::vector<CGXFeatureControlPointer>& vectorRemoteControl
    , std::vector<CGXStreamPointer>& vectorStream)
{
    for (int i = 0; i < (int)vectorRemoteControl.size(); i++)
    {
        try
        {
            vectorRemoteControl[i]->GetCommandFeature("AcquisitionStop")->Execute();
        }
        catch (...)
        {
            std::cout << "cam idx:" << i << " stop acquisition fail!" << std::endl;
            continue;
        }
    }

    for (int i = 0; i < (int)vectorStream.size(); i++)
    {
        try
        {
            vectorStream[i]->Close();
        }
        catch (...)
        {
            std::cout << "cam idx:" << i << " close stream fail!" << std::endl;
            continue;
        }
    }

    for (int i = 0; i < (int)vectorDevPtr.size(); i++)
    {
        try
        {
            vectorDevPtr[i]->Close();
        }
        catch (...)
        {
            std::cout << "cam idx:" << i << " close device fail!" << std::endl;
            continue;
        }
    }
}

cv::Mat GenerateImageFromCamera() {
    CGXDevicePointer pDevice;
    CGXFeatureControlPointer pRemoteControl;
    CGXStreamPointer pStream;
    cv::Mat img;

    try {
        IGXFactory::GetInstance().Init();

        // U3V = usb3
        GxIAPICPP::gxdeviceinfo_vector vectorDeviceInfo;
        IGXFactory::GetInstance().UpdateAllDeviceListEx(GX_TL_TYPE_U3V, 1000, vectorDeviceInfo);

        if (vectorDeviceInfo.empty()) {
            throw CGalaxyException(GX_STATUS_ERROR, "No GigE device found!");
        }

        std::cout << "Opening device..." << std::endl;
        pDevice = IGXFactory::GetInstance().OpenDeviceBySN(vectorDeviceInfo[0].GetSN(), GX_ACCESS_EXCLUSIVE);
        pRemoteControl = pDevice->GetRemoteFeatureControl();

        if (pDevice->GetStreamCount() == 0) {
            throw CGalaxyException(GX_STATUS_ERROR, "No stream found!");
        }

        pStream = pDevice->OpenStream(0);

        // Load default user set
        pRemoteControl->GetEnumFeature("UserSetSelector")->SetValue("UserSet0");
        pRemoteControl->GetCommandFeature("UserSetLoad")->Execute();

        // Set trigger mode and parameters
        pRemoteControl->GetEnumFeature("TriggerMode")->SetValue("On");
        pRemoteControl->GetEnumFeature("TriggerSource")->SetValue("Software");

        pRemoteControl->GetFloatFeature("Gain")->SetValue(1.0);

        // Start stream and acquisition
        pStream->StartGrab();
        pRemoteControl->GetCommandFeature("AcquisitionStart")->Execute();

        // Trigger software action (single frame)
        pRemoteControl->GetCommandFeature("TriggerSoftware")->Execute();

        // Get image
        CImageDataPointer objImagePtr = pStream->DQBuf(1000);
        if (!objImagePtr.IsNull() && objImagePtr->GetStatus() == GX_FRAME_STATUS_SUCCESS) {
            int width = objImagePtr->GetWidth();
            int height = objImagePtr->GetHeight();
            uint8_t* buffer = (uint8_t*)objImagePtr->GetBuffer();
            img = cv::Mat(height, width, CV_8UC1, buffer).clone();
            std::cout << "Captured image: " << width << "x" << height << std::endl;
        }
        else {
            std::cerr << "Failed to capture image." << std::endl;
        }

        // Return buffer to stream and stop acquisition
        pStream->QBuf(objImagePtr);
        pRemoteControl->GetCommandFeature("AcquisitionStop")->Execute();
        pStream->Close();
        pDevice->Close();

        IGXFactory::GetInstance().Uninit();
    }
    catch (CGalaxyException& e) {
        std::cout << "<Galaxy Exception:" << e.GetErrorCode() << "> " << e.what() << std::endl;
        IGXFactory::GetInstance().Uninit();
    }
    catch (std::exception& e) {
        std::cout << "<Unknown Error:" << e.what() << ">" << std::endl;
        IGXFactory::GetInstance().Uninit();
    }

    std::cout << "App exit!" << std::endl;
    return img;
}

// Eén camera per applicatie-instantie (vlakke config, geen lijst). Er wordt
// altijd één CameraContext aangemaakt; of het fysieke toestel geopend wordt
// hangt af van UseCamera (zie entrypoint).
std::shared_ptr<CameraContext> createCameraContext(Parameters& paramCtx) {
    std::string name, sn, userSet, triggerMode, triggerSource;
    {
        std::lock_guard<std::mutex> lock(paramCtx.paramMutex);
        name          = paramCtx.CameraName;
        sn            = paramCtx.CameraSerial;
        userSet       = paramCtx.CameraUserSet;
        triggerMode   = paramCtx.CameraTriggerMode;
        triggerSource = paramCtx.CameraTriggerSource;
    }

    return std::make_shared<CameraContext>(
        name, sn, userSet, triggerMode, triggerSource,
        paramCtx.CameraWidth.load(), paramCtx.CameraHeight.load(),
        paramCtx.CameraOffsetX.load(), paramCtx.CameraOffsetY.load(),
        paramCtx.CameraGain.load(), paramCtx.CameraExposure.load()
    );
}

bool OpenCamera(CameraContext& ctx, Parameters& paramCtx, Logger& logger) {
    try {
        // params
        gxstring sn;
        gxstring userSet;
        gxstring triggerMode;
        gxstring triggerSource;

        {
            //lock
            std::lock_guard<std::mutex> lock(ctx.camMutex);

            sn = ctx.sn.c_str();
            userSet = ctx.userSet.c_str();
            triggerMode = ctx.triggerMode.c_str();
            triggerSource = ctx.triggerSource.c_str();
        }

        IGXFactory::GetInstance().Init();

        GxIAPICPP::gxdeviceinfo_vector devices;
        IGXFactory::GetInstance().UpdateAllDeviceListEx(GX_TL_TYPE_U3V | GX_TL_TYPE_GEV, 5000, devices);

        bool found = false;
        if (!devices.empty()) {
            for (const auto& info : devices)
            {
                if (info.GetSN() == sn)
                {
                    ctx.pDevice = IGXFactory::GetInstance().OpenDeviceBySN(info.GetSN(), GX_ACCESS_EXCLUSIVE);
                    found = true;
                    break;
                }
            }
        }

        if (!found) return false;

        std::cout << "Opening device..." << std::endl;
        ctx.pRemoteControl = ctx.pDevice->GetRemoteFeatureControl();

        if (ctx.pDevice->GetStreamCount() == 0) {
            throw CGalaxyException(GX_STATUS_ERROR, "No stream found!");
        }

        ctx.pStream = ctx.pDevice->OpenStream(0);

        // Add device handlers
        ctx.offlineHandler = std::make_unique<DeviceOfflineEventHandler>(&logger);
        ctx.disconnectHandler = std::make_unique<DeviceDisconnectEventHandler>(&logger);

        ctx.pDevice->RegisterDeviceOfflineCallback(ctx.offlineHandler.get(), nullptr);
        ctx.pDevice->RegisterDeviceDisconnectCallback(ctx.disconnectHandler.get(), nullptr);

        // Load default settings
        ctx.pRemoteControl->GetEnumFeature("UserSetSelector")->SetValue(userSet);
        ctx.pRemoteControl->GetCommandFeature("UserSetLoad")->Execute();

        // Set trigger and gain
        ctx.pRemoteControl->GetEnumFeature("TriggerMode")->SetValue(triggerMode);
        ctx.pRemoteControl->GetEnumFeature("TriggerSource")->SetValue(triggerSource);
        ctx.pRemoteControl->GetFloatFeature("Gain")->SetValue(ctx.gain.load());
        ctx.pRemoteControl->GetFloatFeature("ExposureTime")->SetValue(ctx.exposure.load());

        // 2. Then set the smaller width/height
        ctx.pRemoteControl->GetIntFeature("Width")->SetValue(ctx.width.load());
        ctx.pRemoteControl->GetIntFeature("Height")->SetValue(ctx.height.load());

        // Size to context
        {
            //lock
            std::lock_guard<std::mutex> lock(ctx.camMutex);

            ctx.imageSize.width = ctx.pRemoteControl->GetIntFeature("Width")->GetValue();
            ctx.imageSize.height = ctx.pRemoteControl->GetIntFeature("Height")->GetValue();
        }

        // 3. Finally set the offsets to center it
        ctx.pRemoteControl->GetIntFeature("OffsetX")->SetValue(ctx.offsetX.load());
        ctx.pRemoteControl->GetIntFeature("OffsetY")->SetValue(ctx.offsetY.load());

        // Start acquisition
        ctx.pStream->StartGrab();
        ctx.pRemoteControl->GetCommandFeature("AcquisitionStart")->Execute();

        std::cout << "Camera: " << sn <<" opened successfully." << std::endl;
        return true;
    }
    catch (const CGalaxyException& e) {
        std::cerr << "<Galaxy Exception:" << "> " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "<Error: " << e.what() << ">" << std::endl;
    }

    return false;
}

void UpdateCameraSettings(CameraContext& ctx) {
    std::lock_guard<std::mutex> lock(ctx.camMutex);

    ctx.pRemoteControl->GetFloatFeature("Gain")->SetValue(ctx.gain.load());
    ctx.pRemoteControl->GetFloatFeature("ExposureTime")->SetValue(ctx.exposure.load());
    ctx.pRemoteControl->GetIntFeature("Width")->SetValue(ctx.width.load());
    ctx.pRemoteControl->GetIntFeature("Height")->SetValue(ctx.height.load());
    ctx.pRemoteControl->GetIntFeature("OffsetX")->SetValue(ctx.offsetX.load());
    ctx.pRemoteControl->GetIntFeature("OffsetY")->SetValue(ctx.offsetY.load());

    // Update cv::Size
    ctx.imageSize.width = ctx.width.load();
    ctx.imageSize.height = ctx.height.load();
}

// Capture a single frame
cv::Mat CaptureImage(CameraContext& ctx, Logger& logger) {
    cv::Mat img;

    try {
		std::lock_guard<std::mutex> lock(ctx.camMutex);

        ctx.pRemoteControl->GetCommandFeature("TriggerSoftware")->Execute();

        CImageDataPointer objImagePtr = ctx.pStream->DQBuf(1000);
        if (!objImagePtr.IsNull() && objImagePtr->GetStatus() == GX_FRAME_STATUS_SUCCESS) {
            int width = objImagePtr->GetWidth();
            int height = objImagePtr->GetHeight();
            uint8_t* buffer = (uint8_t*)objImagePtr->GetBuffer();

            img = cv::Mat(height, width, CV_8UC1, buffer).clone();
            std::cout << "Captured image: " << width << "x" << height << std::endl;
        }
        else {
            std::cerr << "Failed to capture image." << std::endl;
        }

        ctx.pStream->QBuf(objImagePtr);
    }
    catch (const CGalaxyException& e) {
		logger.pushMsg("<Galaxy Exception>");
		logger.camIsHealthy.store(false);
    }

    return img;
}

// Capture a single frame and save it
bool CaptureAndSaveImage(CameraContext& ctx, const std::string& path) {
    try {
        // Trigger the camera
        ctx.pRemoteControl->GetCommandFeature("TriggerSoftware")->Execute();

        // Grab image buffer
        CImageDataPointer objImagePtr = ctx.pStream->DQBuf(1000);
        if (!objImagePtr.IsNull() && objImagePtr->GetStatus() == GX_FRAME_STATUS_SUCCESS) {
            int width = objImagePtr->GetWidth();
            int height = objImagePtr->GetHeight();
            uint8_t* buffer = (uint8_t*)objImagePtr->GetBuffer();

            cv::Mat img(height, width, CV_8UC1, buffer);

            // Save image to file
            if (!cv::imwrite(path, img)) {
                std::cerr << "Failed to save image to path: " << path << std::endl;
                ctx.pStream->QBuf(objImagePtr);
                return false;
            }

            // Release buffer back to stream
            ctx.pStream->QBuf(objImagePtr);
            return true;
        }
        else {
            std::cerr << "Failed to capture image." << std::endl;
            return false;
        }
    }
    catch (const CGalaxyException& e) {
        std::cerr << "<Galaxy Exception:> " << e.what() << std::endl;
        return false;
    }
}

// Stop acquisition and close resources
void CloseCamera(CameraContext& ctx) {
    try {
        //ctx.pRemoteControl->GetCommandFeature("AcquisitionStop")->Execute();
        ctx.pStream->Close();
        ctx.pDevice->Close();
        IGXFactory::GetInstance().Uninit();

        std::cout << "Camera closed and resources released." << std::endl;
    }
    catch (const CGalaxyException& e) {
        std::cerr << "<Galaxy Exception:" << "> " << e.what() << std::endl;
    }
}

