#include "ConfigFile.h"

#include <fstream>
#include <mutex>

#include <nlohmann/json.hpp>

#include "Parameters.h"
#include "Logger.h"

using json = nlohmann::json;

bool ConfigFile::load(const std::string& path) {
    std::ifstream in(path);
    if (!in) {
        LoggerContext.pushMsg("Config: file not found: " + path);
        return false;
    }

    json j;
    try {
        in >> j;
    } catch (const std::exception& e) {
        LoggerContext.pushMsg(std::string("Config: parse error: ") + e.what());
        return false;
    }
    if (!j.is_object()) {
        LoggerContext.pushMsg("Config: root is not a JSON object");
        return false;
    }

    int applied = 0, unknown = 0;
    for (auto it = j.begin(); it != j.end(); ++it) {
        const std::string& key = it.key();
        const json& val = it.value();
        try {
            if (ParametersCtx.boolMap.count(key)) {
                ParametersCtx.boolMap[key]->store(val.get<bool>());
            } else if (ParametersCtx.intMap.count(key)) {
                ParametersCtx.intMap[key]->store(val.get<int>());
            } else if (ParametersCtx.floatMap.count(key)) {
                ParametersCtx.floatMap[key]->store(val.get<float>());
            } else if (ParametersCtx.stringMap.count(key)) {
                std::lock_guard<std::mutex> lock(ParametersCtx.paramMutex);
                *ParametersCtx.stringMap[key] = val.get<std::string>();
            } else {
                ++unknown;
                continue;
            }
            ++applied;
        } catch (const std::exception& e) {
            LoggerContext.pushMsg("Config: bad value for '" + key + "': " + e.what());
        }
    }

    LoggerContext.pushMsg("Config: loaded " + std::to_string(applied) +
                          " setting(s) from " + path +
                          (unknown ? (" (" + std::to_string(unknown) + " unknown ignored)") : ""));
    return true;
}

bool ConfigFile::save(const std::string& path) const {
    json j;
    for (const auto& [k, v] : ParametersCtx.boolMap)  j[k] = v->load();
    for (const auto& [k, v] : ParametersCtx.intMap)   j[k] = v->load();
    for (const auto& [k, v] : ParametersCtx.floatMap) j[k] = v->load();
    {
        std::lock_guard<std::mutex> lock(ParametersCtx.paramMutex);
        for (const auto& [k, v] : ParametersCtx.stringMap) j[k] = *v;
    }

    std::ofstream out(path);
    if (!out) {
        LoggerContext.pushMsg("Config: cannot write: " + path);
        return false;
    }
    out << j.dump(2) << '\n';
    LoggerContext.pushMsg("Config: saved to " + path);
    return true;
}
