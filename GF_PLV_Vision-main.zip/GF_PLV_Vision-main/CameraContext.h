#pragma once

#include "Parameters.h"
#include "DeviceOfflineEventHandler.h"
#include "DeviceDisconnectEventHandler.h"

#include "MinimalWindows.h"
#include "CalibrationContext.h"

#include <GalaxyIncludes.h>
#include <opencv2/core.hpp>

#include <mutex>
#include <string>
#include <memory>
#include <condition_variable>
#include <queue>
#include <utility>

class CameraContext
{
    public:
        CameraContext(const std::string& name, const std::string& sn, const std::string& userSet,
            const std::string& triggerMode, const std::string& triggerSource, int width, int height, int offsetX, int offsetY, float gain, float exposure)
            : name(name), sn(sn), userSet(userSet), triggerMode(triggerMode), triggerSource(triggerSource), imageSize(width, height) {
            this->width.store(width);
            this->height.store(height);
            this->offsetX.store(offsetX);
            this->offsetY.store(offsetY);
            this->gain.store(gain);
            this->exposure.store(exposure);

            calibCtx = std::make_shared<CalibrationContext>();
        }

        std::mutex camMutex;
        std::condition_variable camCV;
        std::queue<cv::Mat> imageQueue;
        const int MAX_QUEUE_SIZE = 10;

        // Trigger loop
        std::mutex triggerMutex;
        std::condition_variable triggerCV;
        bool triggerPending = false;

        CGXDevicePointer pDevice;
        CGXFeatureControlPointer pRemoteControl;
        CGXStreamPointer pStream;

        cv::Size imageSize;

        // Identity
        std::string name;
        std::string sn;

        // Settings
        std::string userSet;
        std::string triggerMode;
        std::string triggerSource;

        // Callbacks
        std::unique_ptr<DeviceOfflineEventHandler> offlineHandler;
        std::unique_ptr<DeviceDisconnectEventHandler> disconnectHandler;

        std::atomic<int> width{ 1392 };
        std::atomic<int> height{ 1690 };
        std::atomic<int> offsetX{ 792 };
        std::atomic<int> offsetY{ 20 };
        std::atomic<float> gain{ 2.0f };
        std::atomic<float> exposure{ 25000.0f };

        std::shared_ptr<CalibrationContext> calibCtx;
};
