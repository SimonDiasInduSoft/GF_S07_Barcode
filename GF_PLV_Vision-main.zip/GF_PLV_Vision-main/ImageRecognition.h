#pragma once

#include <string>
#include <vector>
#include <utility>

#include "PlcCamData.h"
#include "Classification.h"
#include "Parameters.h"

#include <opencv2/core.hpp>
#include <ZXing/ReadBarcode.h>
#include <ZXing/BarcodeFormat.h>

//forward declarations
struct ObjectDetection;
struct CalibrationContext;
struct TextBlock;
struct StickerCandidate;
struct AnalysedImage;
struct LiveState;

class FileManager;
class ClassificationModel;
class YoloDetector;
class Logger;

//image recon
class ImageRecognition {
public:
	ImageRecognition(CalibrationContext& calibCtx, Parameters& paramCtx, YoloDetector& yoloDetector, FileManager& fileMan, Logger& logger, LiveState& live) :
		CalibCtx(calibCtx), ParamCtx(paramCtx), FileManager(fileMan), Model(yoloDetector), LoggerCtx(logger), Live(live) {};

	AnalysedImage analyseImage(cv::Mat& image);

private:
	CalibrationContext& CalibCtx;
	Parameters& ParamCtx;
	FileManager& FileManager;
	YoloDetector& Model;
	Logger& LoggerCtx;
	LiveState& Live;

	// API-key komt nu uit Parameters (config.json / UI), niet meer hardcoded.
	const std::string VISION_BASE_URL = "https://vision.googleapis.com/v1/images:annotate?key=";
	const int MAX_DETECTIONS = 5;

	static size_t writeCallback(void* contents, size_t size, size_t nmemb, std::string* out);
	std::string matToBase64(const cv::Mat& frame);
	std::string callVisionAPI(const std::string& base64Image);
	std::vector<TextBlock> parseResponse(const std::string& jsonStr);
	void drawAnnotations(cv::Mat& frame, const std::vector<TextBlock>& blocks);

	void drawBarcodes(cv::Mat& images, const ZXing::Barcodes& barcodes, cv::Point offset);
	std::vector<cv::Mat> cropBarcodesFromImage(cv::Mat& image, const std::vector<ObjectDetection>& detections, int padding);

	// Gesplitste analyse helpers
	cv::Rect findWhiteSticker(const cv::Mat& half);
	StickerCandidate stickerCandidate(const cv::Mat& gray, double thr, double printThr);
	void detectBarcodeInROI(const cv::Mat& roi, cv::Point offset, cv::Mat& annotated, std::string& outBarcode);
	bool decodeStrip(const cv::Mat& gray, const cv::Rect& box, std::string& outText);
	void detectBarcode02InLabel(const cv::Mat& roi, cv::Point offset, cv::Mat& annotated, std::string& outBarcode);
	void detectFRInROI(const cv::Mat& roi, cv::Point offset, cv::Mat& annotated, std::string& outFR);
};