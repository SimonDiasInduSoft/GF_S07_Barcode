#pragma once

#include "Logger.h"
#include "Parameters.h"
#include "PlcContext.h"

#include <array>
#include <atomic>
#include <chrono>
#include <mutex>
#include <string>

// Stuurt de foutstatus van PC-componenten centraal naar de PLC (TRUE = fout).
// Enkel oproepen vanuit de main loop: sample() voor en update() na reconnectionProtocol.
class ErrorHandler {
    public:
        ErrorHandler(Logger& logger, Parameters& params, PlcContext& plc)
            : loggerCtx(logger), paramCtx(params), plcCtx(plc),
              channels{ {
                  { &logger.camIsHealthy,         &params.UseCamera,          &params.CamErrorCommand },
                  { &logger.sqlDatabaseIsHealthy, &params.UseDatabase,        &params.DbErrorCommand },
                  { &logger.storageIsHealthy,     nullptr,                    &params.StorageErrorCommand },
                  { &logger.googleIsHealthy,      nullptr,                    &params.GoogleErrorCommand },
              } } {}

        // Fouten vasthouden voordat de reconnector ze kan herstellen (korte uitval niet missen)
        void sample() {
            for (auto& ch : channels)
                if (isError(ch)) ch.latched = true;
        }

        void update() {
            if (!paramCtx.UsePlc.load()) return;
            if (!loggerCtx.plcIsHealthy.load()) { forceSync = true; return; }

            const auto now = std::chrono::steady_clock::now();
            if (now - lastSync >= RESYNC_INTERVAL) forceSync = true;  // PLC-herstart / online change opvangen

            for (auto& ch : channels) {
                std::string varName;
                { std::lock_guard<std::mutex> lock(paramCtx.paramMutex); varName = *ch.plcVar; }

                const bool error = ch.latched || isError(ch);
                const bool nameChanged = (varName != ch.sentVar);  // symbool aangepast via UI
                if (!forceSync && !nameChanged && error == ch.sentError) {
                    ch.latched = false;
                    continue;
                }

                if (varName.empty()) { ch.sentVar.clear(); ch.latched = false; continue; }  // geen PLC-variabele ingesteld

                if (!plcCtx.write(varName, error)) {
                    forceSync = true;  // volgende cyclus alles opnieuw sturen
                    return;
                }
                ch.sentError = error;
                ch.sentVar = varName;
                ch.latched = false;
            }

            if (forceSync) lastSync = now;
            forceSync = false;
        }

    private:
        struct Channel {
            std::atomic<bool>* healthy;
            std::atomic<bool>* enabled;  // nullptr = altijd actief
            std::string* plcVar;
            std::string sentVar;  // naam waarnaar laatst succesvol geschreven is
            bool sentError{ false };
            bool latched{ false };
        };

        static bool isError(const Channel& ch) {
            if (ch.enabled && !ch.enabled->load()) return false;
            return !ch.healthy->load();
        }

        static constexpr std::chrono::seconds RESYNC_INTERVAL{ 30 };

        Logger& loggerCtx;
        Parameters& paramCtx;
        PlcContext& plcCtx;
        std::array<Channel, 4> channels;

        bool forceSync{ true };  // bij start altijd volledige toestand sturen
        std::chrono::steady_clock::time_point lastSync{};
};
