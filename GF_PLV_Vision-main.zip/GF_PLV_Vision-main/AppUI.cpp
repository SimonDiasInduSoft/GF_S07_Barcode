#include "AppUI.h"

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#endif

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_opengl3.h>

#include <cstring>
#include <fstream>
#include <cmath>
#include <chrono>
#include <algorithm>

#include <opencv2/imgproc.hpp>

#ifdef _WIN32
#include <windows.h>
#include <commdlg.h>
#include <shlobj.h>
#pragma comment(lib, "comdlg32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "ole32.lib")
#endif

#include "Parameters.h"
#include "Logger.h"
#include "LiveState.h"
#include "ConfigFile.h"

namespace {

// ---- atomic <-> ImGui binding helpers ----
void AtomicCheckbox(const char* label, std::atomic<bool>& v) {
    bool b = v.load();
    if (ImGui::Checkbox(label, &b)) v.store(b);
}
void AtomicInputInt(const char* label, std::atomic<int>& v) {
    int x = v.load();
    if (ImGui::InputInt(label, &x)) v.store(x);
}
void AtomicInputFloat(const char* label, std::atomic<float>& v, const char* fmt = "%.4f") {
    float x = v.load();
    if (ImGui::InputFloat(label, &x, 0.0f, 0.0f, fmt)) v.store(x);
}
// std::string-members worden beschermd door Parameters::paramMutex.
void StringField(const char* label, std::string& s, std::mutex& m) {
    char buf[512];
    {
        std::lock_guard<std::mutex> lock(m);
        strncpy_s(buf, sizeof(buf), s.c_str(), _TRUNCATE);
    }
    if (ImGui::InputText(label, buf, sizeof(buf))) {
        std::lock_guard<std::mutex> lock(m);
        s = buf;
    }
}

// ---- native Windows file/folder pickers ----
#ifdef _WIN32
std::string Win32OpenFile(const char* filter) {
    char file[1024] = "";
    OPENFILENAMEA ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner   = GetActiveWindow();
    ofn.lpstrFilter = filter;          // dubbel-null geterminateerd
    ofn.lpstrFile   = file;
    ofn.nMaxFile    = sizeof(file);
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    if (GetOpenFileNameA(&ofn)) return std::string(file);
    return std::string();
}
std::string Win32PickFolder() {
    std::string result;
    BROWSEINFOA bi{};
    bi.hwndOwner = GetActiveWindow();
    bi.lpszTitle = "Select folder";
    bi.ulFlags   = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    LPITEMIDLIST pidl = SHBrowseForFolderA(&bi);
    if (pidl) {
        char path[MAX_PATH];
        if (SHGetPathFromIDListA(pidl, path)) result = path;
        CoTaskMemFree(pidl);
    }
    CoUninitialize();
    return result;
}
#else
std::string Win32OpenFile(const char*) { return {}; }
std::string Win32PickFolder()          { return {}; }
#endif

// InputText + een "..."-knop die een native picker opent.
void PathField(const char* label, std::string& s, std::mutex& m,
               bool isFolder, const char* filter = nullptr) {
    char buf[1024];
    { std::lock_guard<std::mutex> lock(m); strncpy_s(buf, sizeof(buf), s.c_str(), _TRUNCATE); }
    ImGui::SetNextItemWidth(360);
    bool changed = ImGui::InputText(label, buf, sizeof(buf));
    ImGui::SameLine();
    const std::string btn = std::string("...##") + label;
    if (ImGui::Button(btn.c_str())) {
        std::string picked = isFolder ? Win32PickFolder()
                                      : Win32OpenFile(filter ? filter : "All files\0*.*\0");
        if (!picked.empty()) { strncpy_s(buf, sizeof(buf), picked.c_str(), _TRUNCATE); changed = true; }
    }
    if (changed) { std::lock_guard<std::mutex> lock(m); s = buf; }
}

}  // namespace

AppUI::AppUI(Parameters& params, Logger& logger, LiveState& live, std::string configPath)
    : params_(params), logger_(logger), live_(live), configPath_(std::move(configPath)) {}

AppUI::~AppUI() { stop(); }

void AppUI::start() {
    if (running_.exchange(true)) return;
    thread_ = std::thread(&AppUI::runLoop, this);
}

void AppUI::stop() {
    running_ = false;
    if (thread_.joinable()) thread_.join();
}

void AppUI::runLoop() {
    if (!glfwInit()) { running_ = false; return; }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* win = glfwCreateWindow(1100, 760, "Barcode - Control", nullptr, nullptr);
    if (!win) { glfwTerminate(); running_ = false; return; }
    window_ = win;
    glfwMakeContextCurrent(win);
    glfwSwapInterval(1);
    glewExperimental = GL_TRUE;
    glewInit();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();
    ImGui_ImplGlfw_InitForOpenGL(win, true);
    ImGui_ImplOpenGL3_Init("#version 330");
    applyTheme();

    glGenTextures(1, &liveTexture_);

    while (running_ && !glfwWindowShouldClose(win)) {
        glfwPollEvents();
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        renderFrame();

        ImGui::Render();
        int w, h; glfwGetFramebufferSize(win, &w, &h);
        glViewport(0, 0, w, h);
        glClearColor(0.09f, 0.10f, 0.12f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(win);
    }

    // Als de gebruiker het venster sluit, vraag de app ook om af te sluiten.
    params_.ShutDownAnalysis.store(true);

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(win);
    glfwTerminate();
    window_ = nullptr;
    running_ = false;
}

void AppUI::showToast(const std::string& msg, ToastType type) {
    toastMsg_  = msg;
    toastType_ = type;
    toastTime_ = ImGui::GetTime();
    status_    = msg;
}

void AppUI::renderToast() {
    const double kDuration = 3.0;
    const double kFade     = 0.6;
    if (toastMsg_.empty()) return;
    const double age = ImGui::GetTime() - toastTime_;
    if (age > kDuration) return;

    float alpha = 1.0f;
    if (age > kDuration - kFade) alpha = (float)((kDuration - age) / kFade);

    const ImVec4 accent =
        (toastType_ == ToastError)   ? ImVec4(0.88f, 0.28f, 0.28f, 1.0f) :
        (toastType_ == ToastSuccess) ? ImVec4(0.27f, 0.75f, 0.45f, 1.0f) :
                                       ImVec4(0.20f, 0.60f, 0.86f, 1.0f);
    const char* icon =
        (toastType_ == ToastError) ? "(x)" : (toastType_ == ToastSuccess) ? "(v)" : "(i)";

    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImVec2 pos(vp->WorkPos.x + vp->WorkSize.x - 24.0f,
               vp->WorkPos.y + vp->WorkSize.y - 24.0f);
    ImGui::SetNextWindowPos(pos, ImGuiCond_Always, ImVec2(1.0f, 1.0f));
    ImGui::SetNextWindowBgAlpha(0.92f * alpha);

    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(accent.x, accent.y, accent.z, alpha));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(16, 12));
    ImGuiWindowFlags f = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoInputs |
        ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoFocusOnAppearing |
        ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoSavedSettings;
    ImGui::Begin("##toast", nullptr, f);
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(accent.x, accent.y, accent.z, alpha));
    ImGui::TextUnformatted(icon);
    ImGui::PopStyleColor();
    ImGui::SameLine();
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.94f, 0.96f, alpha));
    ImGui::TextUnformatted(toastMsg_.c_str());
    ImGui::PopStyleColor();
    ImGui::End();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor();
}

void AppUI::applyTheme() {
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 8.0f;  s.ChildRounding = 8.0f;  s.FrameRounding = 6.0f;
    s.PopupRounding = 6.0f;   s.GrabRounding = 6.0f;   s.TabRounding = 6.0f;
    s.ScrollbarRounding = 8.0f;
    s.WindowPadding = ImVec2(18, 16);
    s.FramePadding  = ImVec2(12, 8);
    s.ItemSpacing   = ImVec2(12, 10);
    s.ItemInnerSpacing = ImVec2(8, 6);
    s.ScrollbarSize = 14.0f; s.GrabMinSize = 12.0f;
    s.WindowBorderSize = 0.0f; s.FrameBorderSize = 0.0f;

    ImVec4* c = s.Colors;
    const ImVec4 bg     = ImVec4(0.11f, 0.12f, 0.14f, 1.0f);
    const ImVec4 panel  = ImVec4(0.15f, 0.16f, 0.19f, 1.0f);
    const ImVec4 panel2 = ImVec4(0.18f, 0.20f, 0.23f, 1.0f);
    const ImVec4 accent = ImVec4(0.20f, 0.60f, 0.86f, 1.0f);
    const ImVec4 accentH= ImVec4(0.26f, 0.68f, 0.95f, 1.0f);
    c[ImGuiCol_Text]            = ImVec4(0.90f, 0.92f, 0.94f, 1.0f);
    c[ImGuiCol_TextDisabled]    = ImVec4(0.50f, 0.53f, 0.57f, 1.0f);
    c[ImGuiCol_WindowBg]        = bg;
    c[ImGuiCol_ChildBg]         = panel;
    c[ImGuiCol_PopupBg]         = panel;
    c[ImGuiCol_FrameBg]         = panel2;
    c[ImGuiCol_FrameBgHovered]  = ImVec4(0.22f, 0.24f, 0.28f, 1.0f);
    c[ImGuiCol_FrameBgActive]   = ImVec4(0.24f, 0.27f, 0.31f, 1.0f);
    c[ImGuiCol_TitleBg]         = bg;  c[ImGuiCol_TitleBgActive] = bg;
    c[ImGuiCol_Button]          = panel2;
    c[ImGuiCol_ButtonHovered]   = accent;
    c[ImGuiCol_ButtonActive]    = accentH;
    c[ImGuiCol_Header]          = panel2;
    c[ImGuiCol_HeaderHovered]   = ImVec4(0.22f, 0.24f, 0.28f, 1.0f);
    c[ImGuiCol_HeaderActive]    = accent;
    c[ImGuiCol_CheckMark]       = accent;
    c[ImGuiCol_SliderGrab]      = accent;
    c[ImGuiCol_SliderGrabActive]= accentH;
    c[ImGuiCol_Separator]       = ImVec4(0.26f, 0.28f, 0.32f, 1.0f);
    c[ImGuiCol_Tab]             = panel;
    c[ImGuiCol_TabHovered]      = accent;
    c[ImGuiCol_TabActive]       = panel2;
    c[ImGuiCol_Border]          = ImVec4(0, 0, 0, 0);

    ImGuiIO& io = ImGui::GetIO();
    const char* fontPath = "Inter_28pt-Regular.ttf";
    bool haveFont = false;
    { std::ifstream f(fontPath, std::ios::binary); haveFont = f.good(); }
    if (haveFont) {
        io.Fonts->Clear();
        io.Fonts->AddFontFromFileTTF(fontPath, 19.0f);
        io.FontGlobalScale = 1.0f;
    } else {
        io.FontGlobalScale = 1.25f;
    }
}

void AppUI::renderFrame() {
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(vp->WorkPos);
    ImGui::SetNextWindowSize(vp->WorkSize);
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
        ImGuiWindowFlags_NoBringToFrontOnFocus;
    ImGui::Begin("##main", nullptr, flags);

    // ---- top nav + status ----
    auto navBtn = [&](const char* label, int idx) {
        const bool active = (page_ == idx);
        if (active) ImGui::PushStyleColor(ImGuiCol_Button,
                        ImGui::GetStyle().Colors[ImGuiCol_ButtonHovered]);
        if (ImGui::Button(label)) page_ = idx;
        if (active) ImGui::PopStyleColor();
    };
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(22, 10));
    navBtn("  Live  ", 0);
    ImGui::SameLine();
    navBtn("  Settings  ", 1);
    ImGui::PopStyleVar();

    const bool running = params_.StartAnalysis.load();
    const bool sysOk = logger_.plcIsHealthy && logger_.camIsHealthy
                     && logger_.threadMngrIsHealthy && logger_.parametersIshealthy
                     && logger_.databaseIsHealthy && logger_.sqlDatabaseIsHealthy;
    const auto el = std::chrono::steady_clock::now() - logger_.startApplication;
    const auto uh = std::chrono::duration_cast<std::chrono::hours>(el);
    const auto um = std::chrono::duration_cast<std::chrono::minutes>(el - uh);
    const auto us = std::chrono::duration_cast<std::chrono::seconds>(el - uh - um);

    ImGui::SameLine(ImGui::GetWindowWidth() - 480);
    ImGui::TextColored(running ? ImVec4(0.4f, 0.85f, 0.5f, 1) : ImVec4(1, 0.7f, 0.2f, 1),
                       running ? "RUNNING" : "STOPPED");
    ImGui::SameLine();
    ImGui::Text("|  Analysis %s  |", running ? "ON" : "OFF");
    ImGui::SameLine();
    ImGui::TextColored(sysOk ? ImVec4(0.4f, 0.85f, 0.5f, 1) : ImVec4(0.95f, 0.4f, 0.4f, 1),
                       sysOk ? "HEALTHY" : "FAULT");
    ImGui::SameLine();
    ImGui::TextDisabled("| up %lldh %lldm %llds",
                        (long long)uh.count(), (long long)um.count(), (long long)us.count());

    // Pipeline-fouten van worker-threads als toast tonen.
    {
        std::string err; unsigned long long ver;
        { std::lock_guard<std::mutex> lock(live_.mutex); err = live_.lastError; ver = live_.errorVersion; }
        if (ver != lastErrorSeen_) { lastErrorSeen_ = ver; showToast(err, ToastError); }
    }

    // System-health badges op één lijn, net onder de topbar.
    renderHealth();
    ImGui::Separator();

    if (page_ == 0) pageLive();
    else            pageSettings();

    if (!status_.empty()) {
        ImGui::Separator();
        ImGui::TextDisabled("%s", status_.c_str());
    }
    ImGui::End();

    renderToast();
}

void AppUI::liveControls() {
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(18, 12));
    if (ImGui::Button("Start")) { params_.StartAnalysis.store(true);  showToast("Analysis started", ToastSuccess); }
    ImGui::SameLine();
    if (ImGui::Button("Stop"))  { params_.StartAnalysis.store(false); showToast("Analysis stopped", ToastInfo); }
    // Trigger-knop enkel zinvol (en zichtbaar) bij manuele trigger.
    if (params_.UseManualTrigger.load()) {
        ImGui::SameLine();
        if (ImGui::Button("Trigger image")) { params_.SendTrigger.store(true); showToast("Trigger sent", ToastInfo); }
    }
    ImGui::PopStyleVar();
}

void AppUI::renderHealth() {
    auto badge = [&](const char* label, bool ok) {
        ImGui::TextColored(ok ? ImVec4(0.40f, 0.85f, 0.50f, 1.0f)
                              : ImVec4(0.95f, 0.40f, 0.40f, 1.0f),
                           "%s %s", label, ok ? "OK" : "FAULT");
        ImGui::SameLine();
    };
    badge("PLC", logger_.plcIsHealthy);
    badge("Camera", logger_.camIsHealthy);
    badge("History DB", logger_.databaseIsHealthy);
    badge("Results DB", logger_.sqlDatabaseIsHealthy);
    badge("Threads", logger_.threadMngrIsHealthy);
    badge("Params", logger_.parametersIshealthy);
    ImGui::NewLine();
}

void AppUI::pageLive() {
    liveControls();
    ImGui::Spacing();

    uploadLiveTexture();
    std::string statusLine;
    int count = 0, imgW = 0, imgH = 0;
    {
        std::lock_guard<std::mutex> lock(live_.mutex);
        statusLine = live_.statusLine;
        count = live_.detectionCount;
        imgW = live_.displayImage.cols;
        imgH = live_.displayImage.rows;
    }

    ImGui::Text("Codes gevonden: %d", count);
    if (!statusLine.empty()) ImGui::TextWrapped("%s", statusLine.c_str());
    ImGui::Spacing();

    if (imgW > 0 && imgH > 0) {
        float avail = ImGui::GetContentRegionAvail().x;
        float scale = (avail > 0) ? avail / imgW : 1.0f;
        if (scale > 1.0f) scale = 1.0f;
        ImGui::Image((ImTextureID)(intptr_t)liveTexture_, ImVec2(imgW * scale, imgH * scale));
    } else {
        ImGui::TextDisabled("(nog geen beeld - start analyse of trigger een opname)");
    }
}

void AppUI::pageSettings() {
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(16, 8));
    if (ImGui::Button("Save config")) {
        ConfigFile cf(params_, logger_);
        if (cf.save(configPath_)) showToast("Saved config.json", ToastSuccess);
        else                      showToast("Save failed", ToastError);
    }
    ImGui::SameLine();
    if (ImGui::Button("Reload config")) {
        ConfigFile cf(params_, logger_);
        if (cf.load(configPath_)) showToast("Reloaded config.json", ToastSuccess);
        else                      showToast("Reload failed", ToastError);
    }
    ImGui::PopStyleVar();
    ImGui::SameLine();
    ImGui::TextDisabled("(%s)", configPath_.c_str());
    ImGui::Separator();

    if (ImGui::CollapsingHeader("Connections", ImGuiTreeNodeFlags_DefaultOpen)) sectionConnections();
    if (ImGui::CollapsingHeader("Camera"))                                      sectionCamera();
    if (ImGui::CollapsingHeader("Parameters"))                                  sectionParameters();
    if (ImGui::CollapsingHeader("Config"))                                      sectionRecipe();
}

void AppUI::sectionConnections() {
    ImGui::SeparatorText("PLC (Beckhoff ADS)");
    AtomicCheckbox("Use PLC", params_.UsePlc);
    if (params_.UsePlc.load()) {
        StringField("AMS Net Id", params_.AmsNetId, params_.paramMutex);
        AtomicInputInt("PLC Port", params_.PortNr);
        StringField("Recieve command", params_.RecieveCommand, params_.paramMutex);
        StringField("Send command", params_.SendCommand, params_.paramMutex);
        StringField("Cam health command", params_.CamHealthCommand, params_.paramMutex);
        StringField("Cam error var", params_.CamErrorCommand, params_.paramMutex);
        StringField("DB error var", params_.DbErrorCommand, params_.paramMutex);
        StringField("Storage error var", params_.StorageErrorCommand, params_.paramMutex);
        StringField("Google error var", params_.GoogleErrorCommand, params_.paramMutex);
        AtomicInputInt("Recieve trigger cmd code", params_.RecieveTriggerCmdCode);
        AtomicInputInt("Send trigger cmd code", params_.SendTriggerCmdCode);
    }

    ImGui::SeparatorText("History database (Postgres - settings history)");
    AtomicCheckbox("Use history database", params_.UseHistoryDatabase);
    if (params_.UseHistoryDatabase.load()) {
        StringField("PG Host", params_.DbHostIp, params_.paramMutex);
        StringField("PG Name", params_.DbName, params_.paramMutex);
        StringField("PG User", params_.DbUserName, params_.paramMutex);
        StringField("PG Password", params_.DbPassword, params_.paramMutex);
        AtomicInputInt("PG Port", params_.DbPort);
        ImGui::TextDisabled("Elke setting-wijziging wordt hier gelogd in \"ParametersHistory\".");
    }

    ImGui::SeparatorText("Results database (MySQL - results)");
    AtomicCheckbox("Use database (results)", params_.UseDatabase);
    if (params_.UseDatabase.load()) {
        StringField("SQL Host", params_.SQLHostIp, params_.paramMutex);
        StringField("SQL Name", params_.SQLDbName, params_.paramMutex);
        StringField("SQL User", params_.SQLUserName, params_.paramMutex);
        StringField("SQL Password", params_.SQLPassword, params_.paramMutex);
        AtomicInputInt("SQL Port", params_.SQLPort);
        AtomicInputInt("Line nr", params_.LineNr);
    }
    ImGui::TextDisabled("Connection-wijzigingen worden actief bij de volgende app-start.");
}

void AppUI::sectionCamera() {
    ImGui::SeparatorText("Camera backend");
    AtomicCheckbox("Use camera (Galaxy)", params_.UseCamera);
    AtomicCheckbox("Image flip", params_.UseImageFlip);

    ImGui::SeparatorText("Identity / device");
    StringField("Name", params_.CameraName, params_.paramMutex);
    StringField("Serial", params_.CameraSerial, params_.paramMutex);
    StringField("User set", params_.CameraUserSet, params_.paramMutex);
    StringField("Trigger mode", params_.CameraTriggerMode, params_.paramMutex);
    StringField("Trigger source", params_.CameraTriggerSource, params_.paramMutex);

    ImGui::SeparatorText("Sensor settings");
    AtomicInputInt("Width", params_.CameraWidth);
    AtomicInputInt("Height", params_.CameraHeight);
    AtomicInputInt("Offset X", params_.CameraOffsetX);
    AtomicInputInt("Offset Y", params_.CameraOffsetY);
    AtomicInputFloat("Gain", params_.CameraGain);
    AtomicInputFloat("Exposure", params_.CameraExposure);
    ImGui::TextDisabled("Camera-wijzigingen worden actief bij de volgende app-start.");
}

void AppUI::sectionParameters() {
    ImGui::SeparatorText("Object detectie (YOLO)");
    AtomicCheckbox("Use detection model", params_.UseModelDetection);
    AtomicCheckbox("Use detection model (training)", params_.UseModelDetectionTraining);
    PathField("Model path", params_.ObjectDetectionModelPath, params_.paramMutex,
              false, "ONNX model\0*.onnx\0All files\0*.*\0");
    AtomicInputFloat("Confidence threshold", params_.ObjectDetectionConfThreshold, "%.2f");
    AtomicInputFloat("NMS threshold", params_.ObjectDetectionNMSThreshold, "%.2f");

    ImGui::SeparatorText("Vision OCR (Google)");
    StringField("API key", params_.VisionApiKey, params_.paramMutex);
    ImGui::TextDisabled("Leeg = geen Vision-calls. Wijziging werkt direct; Save config om te bewaren.");

    ImGui::SeparatorText("Analyse");
    AtomicCheckbox("Use pallet label", params_.UsePalletLabel);
    AtomicCheckbox("Use pallet cardbox", params_.UsePalletCardbox);
    AtomicCheckbox("Save HD", params_.SaveHD);
    ImGui::TextDisabled("Worden bij elke trigger overschreven door de PLC (adArg 2/3/4).");
    {
        const bool l = params_.UsePalletLabel.load(), c = params_.UsePalletCardbox.load();
        if (l && c)      ImGui::TextDisabled("Label, karton en PLC moeten alle drie gelijk zijn.");
        else if (l)      ImGui::TextDisabled("Enkel FR label en FR PLC moeten gelijk zijn.");
        else if (c)      ImGui::TextDisabled("Enkel FR karton en FR PLC moeten gelijk zijn.");
        else             ImGui::TextDisabled("Geen vergelijking actief: resultaat altijd OK.");
    }

    ImGui::SeparatorText("Triggering");
    AtomicCheckbox("Hardware trigger", params_.UseHardwareTrigger);
    AtomicCheckbox("Manual trigger (enter)", params_.UseManualTrigger);

    ImGui::SeparatorText("Saving / file handling");
    AtomicCheckbox("Save images", params_.SaveImages);
    AtomicCheckbox("Save analysed images", params_.SaveAnalysedImages);
    AtomicCheckbox("Auto delete old images", params_.AutoDeleteOn);
    PathField("Analysed folder", params_.AnalysedImagesPath, params_.paramMutex, true);
    PathField("Raw folder", params_.RawImagePath, params_.paramMutex, true);
    ImGui::Spacing();
    AtomicInputInt("Images per folder", params_.ImageFolderLimit);
    AtomicInputInt("Image sub-folders", params_.FolderLimit);
    AtomicInputInt("Analysed sub-folders", params_.AnalysedFolderLimit);
    AtomicInputInt("Analysed images limit", params_.AnalysedImagesLimit);
    ImGui::Spacing();
    AtomicInputInt("Default width", params_.DefaultWidth);
    AtomicInputInt("Default height", params_.DefaultHeight);
}

void AppUI::sectionRecipe() {
    AtomicCheckbox("Debug mode (console logs)", params_.DebugMode);
}

void AppUI::uploadLiveTexture() {
    cv::Mat bgr;
    uint64_t version;
    {
        std::lock_guard<std::mutex> lock(live_.mutex);
        version = live_.frameVersion;
        if (live_.displayImage.empty()) return;
        if (version == lastFrameVersion_) return;   // ongewijzigd
        live_.displayImage.copyTo(bgr);
    }
    lastFrameVersion_ = version;

    cv::Mat rgb;
    cv::cvtColor(bgr, rgb, cv::COLOR_BGR2RGB);
    if (!rgb.isContinuous()) rgb = rgb.clone();

    glBindTexture(GL_TEXTURE_2D, liveTexture_);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, rgb.cols, rgb.rows, 0, GL_RGB,
                 GL_UNSIGNED_BYTE, rgb.data);
}
