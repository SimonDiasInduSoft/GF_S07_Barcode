#include "Parameters.h"
#include "Parameter.h"

#include <string>

void Parameters::updateParam(Parameter& parameter) {
    std::string initValue = "";
    if (parameter.Type == "bool" && boolMap.count(parameter.Name)) {
        initValue = boolMap[parameter.Name]->load() ? "true" : "false";
        boolMap[parameter.Name]->store(parameter.Value == "true");
    }
    else if (parameter.Type == "int" && intMap.count(parameter.Name)) {
        initValue = std::to_string(intMap[parameter.Name]->load());
        intMap[parameter.Name]->store(std::stoi(parameter.Value));
    }
    else if (parameter.Type == "float" && floatMap.count(parameter.Name)) {
        initValue = std::to_string(floatMap[parameter.Name]->load());
        floatMap[parameter.Name]->store(std::stof(parameter.Value));
    }
    else if (parameter.Type == "string" && stringMap.count(parameter.Name)) {
        std::lock_guard<std::mutex> lock(paramMutex);
        initValue = *stringMap[parameter.Name];
        *stringMap[parameter.Name] = parameter.Value;
    }

    parameter.PreviousValue = initValue;
}

void Parameters::initMaps() {
    // ---------- BOOL ----------
    boolMap["UseCamera"] = &UseCamera;
    boolMap["UseDatabase"] = &UseDatabase;
    boolMap["UsePlc"] = &UsePlc;
    boolMap["DebugMode"] = &DebugMode;
    boolMap["SaveImages"] = &SaveImages;
    boolMap["UseModelDetection"] = &UseModelDetection;
    boolMap["UseModelDetectionTraining"] = &UseModelDetectionTraining;
    boolMap["SaveAnalysedImages"] = &SaveAnalysedImages;
    boolMap["AutoDeleteOn"] = &AutoDeleteOn;
    boolMap["StartAnalysis"] = &StartAnalysis;
    boolMap["ShutDownAnalysis"] = &ShutDownAnalysis;
    boolMap["ConfigurationMode"] = &ConfigurationMode;
    boolMap["UseManualTrigger"] = &UseManualTrigger;
    boolMap["UseHardwareTrigger"] = &UseHardwareTrigger;
    boolMap["SendTrigger"] = &SendTrigger;
    boolMap["UseImageFlip"] = &UseImageFlip;
    boolMap["UseHistoryDatabase"] = &UseHistoryDatabase;
    boolMap["CompareCardbox"] = &CompareCardbox;
    boolMap["DisableCam"] = &DisableCam;

    // ---------- INT ----------
    intMap["DbPort"] = &DbPort;
    intMap["SQLPort"] = &SQLPort;
    intMap["PortNr"] = &PortNr;
    intMap["LineNr"] = &LineNr;
    intMap["DefaultWidth"] = &DefaultWidth;
    intMap["DefaultHeight"] = &DefaultHeight;
    intMap["ImageFolderLimit"] = &ImageFolderLimit;
    intMap["FolderLimit"] = &FolderLimit;
    intMap["AnalysedFolderLimit"] = &AnalysedFolderLimit;
    intMap["AnalysedImagesLimit"] = &AnalysedImagesLimit;
    intMap["CameraWidth"] = &CameraWidth;
    intMap["CameraHeight"] = &CameraHeight;
    intMap["CameraOffsetX"] = &CameraOffsetX;
    intMap["CameraOffsetY"] = &CameraOffsetY;
    intMap["RecieveTriggerCmdCode"] = &RecieveTriggerCmdCode;
    intMap["SendTriggerCmdCode"] = &SendTriggerCmdCode;

    // ---------- FLOAT ----------
    floatMap["ObjectDetectionConfThreshold"] = &ObjectDetectionConfThreshold;
    floatMap["ObjectDetectionNMSThreshold"] = &ObjectDetectionNMSThreshold;
    floatMap["CameraGain"] = &CameraGain;
    floatMap["CameraExposure"] = &CameraExposure;

    // ---------- STRING ----------
    stringMap["ObjectDetectionModelPath"] = &ObjectDetectionModelPath;
    stringMap["VisionApiKey"] = &VisionApiKey;
    stringMap["DbUserName"] = &DbUserName;
    stringMap["DbPassword"] = &DbPassword;
    stringMap["DbHostIp"] = &DbHostIp;
    stringMap["DbName"] = &DbName;
    stringMap["SQLUserName"] = &SQLUserName;
    stringMap["SQLPassword"] = &SQLPassword;
    stringMap["SQLHostIp"] = &SQLHostIp;
    stringMap["SQLDbName"] = &SQLDbName;
    stringMap["AmsNetId"] = &AmsNetId;
    stringMap["RecieveCommand"] = &RecieveCommand;
    stringMap["SendCommand"] = &SendCommand;
    stringMap["CamHealthCommand"] = &CamHealthCommand;
    stringMap["CamErrorCommand"] = &CamErrorCommand;
    stringMap["DbErrorCommand"] = &DbErrorCommand;
    stringMap["StorageErrorCommand"] = &StorageErrorCommand;
    stringMap["GoogleErrorCommand"] = &GoogleErrorCommand;
    stringMap["AnalysedImagesPath"] = &AnalysedImagesPath;
    stringMap["RawImagePath"] = &RawImagePath;
    stringMap["ClientAnswer"] = &ClientAnswer;

    // ---------- camera identity (flat, single camera) ----------
    stringMap["CameraName"] = &CameraName;
    stringMap["CameraSerial"] = &CameraSerial;
    stringMap["CameraUserSet"] = &CameraUserSet;
    stringMap["CameraTriggerMode"] = &CameraTriggerMode;
    stringMap["CameraTriggerSource"] = &CameraTriggerSource;
}
