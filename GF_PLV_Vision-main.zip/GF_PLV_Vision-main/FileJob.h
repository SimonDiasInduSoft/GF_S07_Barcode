#pragma once

#include <vector>
#include <string>
#include <filesystem>

#include <opencv2/core.hpp>

enum class SaveCategory;

struct FileJob {
	bool isImage = true;
	bool isColorPly = false;
	int jpegQuality = 85;

	cv::Mat image;

	SaveCategory category;
	std::string type;

	fs::path fullPath;
	std::string pathString;
};