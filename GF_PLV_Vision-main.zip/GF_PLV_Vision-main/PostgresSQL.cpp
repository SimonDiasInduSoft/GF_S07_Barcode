#include "PostgresSQL.h"
#include "Logger.h"
#include "Parameters.h"
#include "PlcCamData.h"
#include "CommandStatus.h"
#include "PostgresCommand.h"
#include "Parameter.h"

#include <string>
#include <string_view>
#include <vector>
#include <iostream>
#include <memory>
#include <utility>
#include <cstddef> 

#include <pqxx/pqxx>

void PostgresSQL::open() {
	std::lock_guard<std::mutex> connLock(ConnMutex);
	std::lock_guard<std::mutex> lock(ParametersCtx.paramMutex);

	std::string connectionStr = "user=" + ParametersCtx.DbUserName +
		" password=" + ParametersCtx.DbPassword +
		" host=" + ParametersCtx.DbHostIp +
		" port=" + std::to_string(ParametersCtx.DbPort.load()) +
		" dbname=" + ParametersCtx.DbName;

	try {
		auto conn = std::make_unique<pqxx::connection>(connectionStr);
		if (conn->is_open()) {
			std::cout << "Opened database successfully on: " << ParametersCtx.DbUserName << std::endl;

			Connection = std::move(conn);
		}
		else {
			std::string msg = "Opened database failed on: " + ParametersCtx.DbUserName;
			LoggerContext.pushMsg(msg);
		}
	}
	catch (const std::exception& e) {
		std::string msg = "FATAL: opening database caused crash";
		LoggerContext.pushMsg(msg);
	}
}

void PostgresSQL::close() {
	std::lock_guard<std::mutex> connLock(ConnMutex);
	if (Connection && Connection->is_open()) {
		Connection->close();
	}
}

bool PostgresSQL::addCommand(const PostgresCommand& pgCmd) {
	std::lock_guard<std::mutex> connLock(ConnMutex);
	if (!Connection || !Connection->is_open()) return false;   // niet verbonden -> requeue
	try {
		pqxx::work worker(*Connection);

		if (pgCmd.CmdStatus == CommandStatus::SendParamHistoryCmd) {
			const Parameter& p = pgCmd.Param;
			worker.exec(
				"INSERT INTO public.\"ParametersHistory\" "
				"(\"Param_Name\", \"Param_Type\", \"Param_Value\", \"Changed_By\", \"Changed_At\", \"Param_ValueOld\") "
				"VALUES ($1, $2, $3, $4, NOW(), $5)",
				pqxx::params{ p.Name, p.Type, p.Value, p.ChangedBy, p.PreviousValue });
		}

		// commit
		worker.commit();
		return true;
	}
	catch (const std::exception& e) {
		std::string msg = "Error writing settings history: ";
		msg += e.what();
		LoggerContext.pushMsg(msg);
		return false;
	}
}

void PostgresSQL::resetClientAnswer() {
	PostgresCommand resetCalib;
	resetCalib.CmdStatus = CommandStatus::ResetClientAnswerCmd;
	pushToQueue(resetCalib);
}

// Push a batch into the queue (move for efficiency)
bool PostgresSQL::pushToQueue(PostgresCommand pgCmd) {
	std::lock_guard<std::mutex> lock(DbQueueMutex);

	if (DbQueue.size() >= MAX_LOG_MESSAGES)
		DbQueue.pop_front();

	DbQueue.push_back(pgCmd); // move batch into queue
	DbQueueCV.notify_one();
	return true;
}

// Process next batch (move out, insert, retry if fails)
bool PostgresSQL::processNextCommand() {
	PostgresCommand command;

	// Pop batch from queue
	{
		std::lock_guard<std::mutex> lock(DbQueueMutex);
		if (DbQueue.empty()) return false;

		command = std::move(DbQueue.front());
		DbQueue.pop_front();
	} // mutex released

	// Attempt DB insert
	if (!addCommand(command)) {
		// Requeue on failure
		std::lock_guard<std::mutex> lock(DbQueueMutex);
		DbQueue.push_front(std::move(command));
		return false;
	}

	return true;
}

bool PostgresSQL::isQueueEmpty() {
	std::lock_guard<std::mutex> lock(DbQueueMutex);

	if (DbQueue.empty())
		return true;
	else return false;
}


