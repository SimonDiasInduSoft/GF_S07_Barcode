#pragma once

#include "MinimalWindows.h"
#include "Logger.h"

#include "GalaxyIncludes.h"

class DeviceDisconnectEventHandler : public IDeviceDisconnectEventHandler
{
    public:
        DeviceDisconnectEventHandler(Logger* logger) : loggerCtx(logger) {}

        virtual void DoOnDeviceDisconnectEvent(void* pUserParam) override
        {
            if (loggerCtx)
                loggerCtx->camIsHealthy.store(false);

        }

    private:
        Logger* loggerCtx;
};
