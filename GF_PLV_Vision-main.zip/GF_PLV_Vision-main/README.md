Main -> Active code
Add-minor-improvements -> active dev branch
solo-app & solo-app-patties -> test branches op release zonder camera of ads
hard ware trigger -> actieve branch met hardware trigger code

