#pragma once

#include "RetryState.h"
#include "Parameters.h"

#include <mutex>
#include <string>
#include <vector>

// Forward declaration
struct CalibrationContext;

class CameraContext;
class Logger;
class PlcContext;
class ThreadManager;
class PostgresSQL;
class MySQL;

// Reconnector
class ApplicationReconnector {
    public:
        ApplicationReconnector(Logger& loggerCtx, Parameters& parameterContext) : logger(loggerCtx), paramCtx(parameterContext) {};
        void reconnectionProtocol(PlcContext& plcCtx, CameraContext& stalkCamCtx, ThreadManager& dataControl, PostgresSQL& databaseConnection, MySQL& mysqlConnection);

    private:
		Logger& logger;
        Parameters& paramCtx;

        std::string encoderPickVarName;

        static constexpr int MAX_BACKOFF_MS = 30'000;
        static constexpr int BASE_BACKOFF_MS = 500;

        RetryState plcState, stalkCamState, cherryCamState, calibState, threadState, dbState, sqlDbState;

        bool allowAttempt(RetryState& state);
        void updateBackoffOnFailure(RetryState& state);
        void resetBackoffOnSuccess(RetryState& state);
        void tryReconnectPlc(PlcContext& plcCtx);
        void tryReconnectCamera(CameraContext& camCtx);
        void tryReconnectThreadManager(ThreadManager& dataControl);
		void tryReconnectDatabase(PostgresSQL& databaseConnection);
		void tryReconnectSQLDatabase(MySQL& databaseConnection);
};