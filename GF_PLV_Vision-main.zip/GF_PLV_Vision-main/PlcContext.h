#pragma once

#include <string>
#include <mutex>
#include <cstdint> 
#include <condition_variable>
#include <unordered_map>

#include "Logger.h"
#include "PlcConfig.h"

#include "TcAdsDef.h"
#include "TcAdsApi.h"

//Forward declarations
class Parameters;

class PlcContext {
public:
    PlcContext(Logger& loggerCtx, Parameters& paramCtx, PlcConfig cfg = {})
        : logger(loggerCtx), ParametersContext(paramCtx), config(cfg) {}

    ~PlcContext() { close(); }

    PlcContext(const PlcContext&) = delete;
    PlcContext& operator=(const PlcContext&) = delete;
    PlcContext(PlcContext&&) = delete;
    PlcContext& operator=(PlcContext&&) = delete;

    bool open();
    void close();
    bool isConnected() const;
    bool sendAndRecievePlcAliveRequest();

    // Templates -> stays in the header
    template<typename T>
    bool read(const std::string& variable, T& value) {
        return read(variable, &value, 1);
    }

    template<typename T>
    bool read(const std::string& variable, T* buffer, size_t count) {
        if (count == 0) {
            logger.pushMsg("Read error: count cannot be zero");
            return false;
        }

        std::lock_guard<std::mutex> lock(adsMutex);
        if (!ensureConnected()) return false;

        long handle;
        if (!getHandle(variable, handle)) return false;

        long nErr = AdsSyncReadReq(&remoteAddr, ADSIGRP_SYM_VALBYHND, handle,
            static_cast<unsigned long>(sizeof(T) * count), buffer);

        if (nErr) {
            logger.pushMsg("Read error for " + variable + ": " + std::to_string(nErr));
            return false;
        }
        return true;
    }

    template<typename T>
    bool write(const std::string& variable, const T& value) {
        return write(variable, &value, 1);
    }

    template<typename T>
    bool write(const std::string& variable, const T* buffer, size_t count) {
        if (count == 0) {
            logger.pushMsg("Write error: count cannot be zero");
            return false;
        }

        std::lock_guard<std::mutex> lock(adsMutex);
        if (!ensureConnected()) return false;

        long handle;
        if (!getHandle(variable, handle)) return false;

        long nErr = AdsSyncWriteReq(&remoteAddr, ADSIGRP_SYM_VALBYHND, handle,
            static_cast<unsigned long>(sizeof(T) * count),
            const_cast<T*>(buffer));

        if (nErr) {
            logger.pushMsg("Write error for " + variable + ": " + std::to_string(nErr));
            return false;
        }
        return true;
    }

    bool readString(const std::string& variable, std::string& value, size_t maxLen = 0);
    bool writeString(const std::string& variable, const std::string& value);

    std::mutex healthMutex;
    std::condition_variable plcCV;
private:
    mutable std::mutex adsMutex;

    Parameters& ParametersContext;
    Logger& logger;

    std::unordered_map<std::string, long> handleCache;

    long adsPort{ 0 };
    AmsAddr localAddr{};
    AmsAddr remoteAddr{};
    PlcConfig config;

    bool ensureConnected();
    bool openInternal();
    bool getHandle(const std::string& variable, long& handle);
    bool parseAmsNetId(const std::string& netId, uint8_t* bytes); // used BYTE*
};
