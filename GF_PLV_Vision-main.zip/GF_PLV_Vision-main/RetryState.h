#pragma once

#include <chrono>

struct RetryState {
    int attemptCount = 0;
    std::chrono::steady_clock::time_point lastAttempt = std::chrono::steady_clock::time_point::min();
    std::chrono::milliseconds backoffMs{ 0 };
};