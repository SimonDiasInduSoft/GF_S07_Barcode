#pragma once

#include <atomic>
#include <cstdint>

struct PlcCamData {
    float rX = 0.0f;
    float rY = 0.0f;
    float rZ = 0.0f;
    float rRz = 0.0f;
    float rCx = 0.0f;
    float rCy = 0.0f;
    float rLength = 0.0f; // Lengte van steeltje boven langste lijn
    float rStrLength = 0.0f; // lengte van langste lijn
    uint32_t iEncLatchVal = 0;

    int16_t iObjClass = 0;
    int16_t iObjType = 0;
    uint16_t iId = 0;

    PlcCamData(bool isEmpty = false) {
        if (!isEmpty) {
            static std::atomic<uint16_t> nextId{ 1 };
            iId = nextId.fetch_add(1);
        }
    }
};
