#pragma once

#include <string>

class Parameters;
class Logger;

class ConfigFile {
    public:
        ConfigFile(Parameters& paramCtx, Logger& loggerCtx)
            : ParametersCtx(paramCtx), LoggerContext(loggerCtx) {}

        bool load(const std::string& path);
        bool save(const std::string& path) const;

    private:
        Parameters& ParametersCtx;
        Logger&     LoggerContext;
};
