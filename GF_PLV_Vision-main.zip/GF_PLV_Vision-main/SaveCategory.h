#pragma once

enum class SaveCategory {
	AnalysedImages,
	RawImages,
    BerxelPng,
    BerxelCloud
};
