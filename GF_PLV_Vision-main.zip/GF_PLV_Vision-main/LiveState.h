#pragma once
//
// LiveState.h
// Thread-safe snapshot van wat de UI live toont. De analyse-pipeline
// (ImageRecognition) publiceert hierin het laatste geannoteerde beeld + status;
// de UI-thread (AppUI) leest het uit. De console blijft voor de logs.
//
#include <mutex>
#include <string>
#include <cstdint>

#include <opencv2/core.hpp>

struct LiveState {
    std::mutex mutex;

    // Laatste geannoteerde beeld (BGR), zoals ImageRecognition het produceert.
    cv::Mat displayImage;
    // Verhoogd bij elke wijziging, zodat de UI enkel her-uploadt bij verandering.
    uint64_t frameVersion = 0;

    // Mensvriendelijke samenvatting voor het Live-paneel.
    std::string statusLine;        // bv. "barcode: 1234  fr: AB12"
    int detectionCount = 0;        // aantal gevonden codes

    // Foutkanaal: de UI pollt errorVersion en toont lastError als toast.
    std::string lastError;
    uint64_t    errorVersion = 0;

    // ---- producer helpers ----
    void publishImage(const cv::Mat& annotated) {
        std::lock_guard<std::mutex> lock(mutex);
        annotated.copyTo(displayImage);
        ++frameVersion;
    }
    void publishStatus(const std::string& s, int count) {
        std::lock_guard<std::mutex> lock(mutex);
        statusLine = s;
        detectionCount = count;
    }
    void publishError(const std::string& e) {
        std::lock_guard<std::mutex> lock(mutex);
        lastError = e;
        ++errorVersion;
    }
};
