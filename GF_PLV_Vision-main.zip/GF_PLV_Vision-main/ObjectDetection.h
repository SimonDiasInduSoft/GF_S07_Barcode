#pragma once

#include <opencv2/core.hpp>

struct ObjectDetection {
    int classId;
    float confidence;
    cv::Rect box;
    float angle;
    cv::Point2f center;
};