#include "SettingsHistory.h"

#include <mutex>

#include "Parameters.h"
#include "Parameter.h"
#include "PostgresSQL.h"
#include "PostgresCommand.h"
#include "CommandStatus.h"
#include "Logger.h"

// Bouw een momentopname 
std::unordered_map<std::string, std::string> SettingsHistory::snapshot() const {
    std::unordered_map<std::string, std::string> snap;

    for (const auto& [k, v] : ParametersCtx.boolMap)
        snap[k] = v->load() ? "true" : "false";
    for (const auto& [k, v] : ParametersCtx.intMap)
        snap[k] = std::to_string(v->load());
    for (const auto& [k, v] : ParametersCtx.floatMap)
        snap[k] = std::to_string(v->load());
    {
        std::lock_guard<std::mutex> lock(ParametersCtx.paramMutex);
        for (const auto& [k, v] : ParametersCtx.stringMap)
            snap[k] = *v;
    }
    return snap;
}

void SettingsHistory::initBaseline() {
    type_.clear();
    for (const auto& [k, v] : ParametersCtx.boolMap)   type_[k] = "bool";
    for (const auto& [k, v] : ParametersCtx.intMap)    type_[k] = "int";
    for (const auto& [k, v] : ParametersCtx.floatMap)  type_[k] = "float";
    for (const auto& [k, v] : ParametersCtx.stringMap) type_[k] = "string";

    last_ = snapshot();
    hasBaseline_ = true;
}

int SettingsHistory::poll() {
    if (!hasBaseline_) { initBaseline(); return 0; }

    auto current = snapshot();
    int changes = 0;

    std::string changedBy;
    { std::lock_guard<std::mutex> lock(ParametersCtx.paramMutex); changedBy = ParametersCtx.ChangedBy; }

    for (const auto& [key, newVal] : current) {
        auto it = last_.find(key);
        if (it != last_.end() && it->second == newVal) continue;  // ongewijzigd

        Parameter p;
        p.Name          = key;
        p.Type          = type_.count(key) ? type_[key] : "string";
        p.PreviousValue = (it != last_.end()) ? it->second : "";
        p.Value         = newVal;
        p.ChangedBy     = changedBy;

        PostgresCommand cmd;
        cmd.Param     = p;
        cmd.CmdStatus = CommandStatus::SendParamHistoryCmd;

        if (!Db.pushToQueue(cmd))
            LoggerContext.pushMsg("SettingsHistory: kon wijziging niet in queue plaatsen: " + key);

        ++changes;
    }

    last_ = std::move(current);
    return changes;
}
