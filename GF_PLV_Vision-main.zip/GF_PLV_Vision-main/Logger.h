#pragma once

#include <chrono>
#include <atomic>
#include <queue>
#include <mutex>
#include <string>
#include <sstream>
#include <iostream>

// Log-niveaus
enum class LogLevel { Info, Debug, Warning, Error };

class Logger {
    public:
        Logger() {
            startApplication = std::chrono::high_resolution_clock::now();
        }

        std::chrono::steady_clock::time_point startApplication;

        std::atomic<bool> plcIsHealthy{ true };
        std::atomic<bool> camIsHealthy{ true };
        std::atomic<bool> calibrationIsHealthy{ true };
        std::atomic<bool> threadMngrIsHealthy{ true };
        std::atomic<bool> databaseIsHealthy{ true };
        std::atomic<bool> sqlDatabaseIsHealthy{ true };
        std::atomic<bool> parametersIshealthy{ true };
        std::atomic<bool> storageIsHealthy{ true };
        std::atomic<bool> googleIsHealthy{ true };

        std::atomic<size_t> commandsCreated{ 0 };

        std::atomic<size_t> frCodesProcessed{ 0 };
        std::atomic<size_t> barcodesProcessed{ 0 };

        // Aan/uit voor Debug-logs
        std::atomic<bool> verbose{ false };

        bool peekMsg(std::string& out) {
            std::lock_guard<std::mutex> lock(logMutex);
            if (!logMessages.empty()) {
                out = logMessages.front();
                return true;
            }
            return false;
        }

        void pushMsg(const std::string& msg, LogLevel level = LogLevel::Info) {
            if (level == LogLevel::Debug && !verbose.load(std::memory_order_relaxed))
                return;

            std::lock_guard<std::mutex> lock(logMutex);

            const auto now = std::chrono::steady_clock::now();
            if (msg == lastMsg_ && (now - lastMsgTime_) < LOG_THROTTLE)
                return;
            lastMsg_ = msg;
            lastMsgTime_ = now;

            if (logMessages.size() >= MAX_LOG_MESSAGES)
                logMessages.pop();
            logMessages.push(msg);
        }

        void popMsg() {
            std::lock_guard<std::mutex> lock(logMutex);
            if (!logMessages.empty())
                logMessages.pop();
        }

        void drainLogsToConsole() {
            std::lock_guard<std::mutex> lock(logMutex);
            while (!logMessages.empty()) {
                std::cout << logMessages.front() << std::endl;
                logMessages.pop();
            }
        }

        bool systemCheckup() const {
            return (plcIsHealthy && camIsHealthy && calibrationIsHealthy && threadMngrIsHealthy && databaseIsHealthy && parametersIshealthy && sqlDatabaseIsHealthy);
        }

    private:
        const size_t MAX_LOG_MESSAGES = 1000;
        std::queue<std::string> logMessages;
        std::mutex logMutex;

        // Anti-flood state (beschermd door logMutex).
        std::string lastMsg_;
        std::chrono::steady_clock::time_point lastMsgTime_{};
        static constexpr std::chrono::milliseconds LOG_THROTTLE{ 1000 };
};
