#pragma once

#include "opencv2/imgcodecs.hpp"

struct StalkKeyPoint {
    cv::Point pt;
    int contourIdx;
};
