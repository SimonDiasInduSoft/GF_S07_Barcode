#pragma once

#include <string>
#include <opencv2/core.hpp>

struct TextBlock {
	std::string text;
	std::vector<cv::Point> vertices;
};
