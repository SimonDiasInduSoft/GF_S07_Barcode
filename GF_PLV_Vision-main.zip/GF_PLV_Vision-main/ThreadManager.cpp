#pragma once

#include "ThreadManager.h"

#include <thread>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>
#include <iostream>
#include <memory>
#include <utility>
#include <cstddef>
#include <chrono>
#include <optional>
#include <random>

#include "CommandHandler.h"
#include "ImageRecognition.h"
#include "VaLinker.h"
#include "PlcContext.h"
#include "SndCommand.h"
#include "CommandStatus.h"
#include "PostgresSQL.h"
#include "PostgresCommand.h"
#include "CameraContext.h"
#include "PlcCamData.h"
#include "Parameters.h"
#include "Parameter.h"
#include "RcCommand.h"
#include "Logger.h"
#include "Yolo11s.h"
#include "AnalysedImage.h"
#include "FileManager.h"
#include "FileJob.h"
#include "SaveCategory.h"
#include "SessionManager.h"
#include "MySQL.h"

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>

#include <nlohmann/json.hpp>

cv::Mat loadRandomImage(const std::string& folderPath);

bool ThreadManager::start() {
    running = true;

    // Load parameters
    {
        std::lock_guard<std::mutex> lock(paramCtx.paramMutex);

		rawImagePath = paramCtx.RawImagePath;

        receiveCommandVarName = paramCtx.RecieveCommand;
        sendCommandVarName = paramCtx.SendCommand;
		camHealthCommandVarName = paramCtx.CamHealthCommand;
    }


    imageProcessingThread = std::thread(&ThreadManager::imageProcessingLoop, this);

    // start image aquisition loop
    if (paramCtx.UseCamera.load()) {
        if (paramCtx.UseHardwareTrigger.load())
            CameraThread = std::thread(&ThreadManager::cameraAcquisitionLoop, this);
        else {
            if (paramCtx.UseManualTrigger)
                CameraThread = std::thread(&ThreadManager::CameraTriggerLoop, this);
            else
                CameraThread = std::thread(&ThreadManager::CameraLoop, this);
        }
    }
    else {
        if (paramCtx.UseManualTrigger.load())
            CameraThread = std::thread(&ThreadManager::simulationCameraTriggerLoop, this);
    }
    

    // Start PLC loops or simulation PLC loops
    if (paramCtx.UsePlc.load()) {
        handleRcCommandThread = std::thread(&ThreadManager::handleRcCommandLoop, this);
        handleSndCommandThread = std::thread(&ThreadManager::handleSndCommandLoop, this);
        checkPlcHealthThread = std::thread(&ThreadManager::checkPlcHealthLoop, this);
    }
    else {
        simulationHandleSndCommandThread = std::thread(&ThreadManager::simulationHandleSndCommandLoop, this);
    }

    // File handling
    if (paramCtx.SaveImages.load() || paramCtx.SaveAnalysedImages.load())
		fileHandlingThread = std::thread(&ThreadManager::fileHandlingLoop, this);

    loggerCtx.pushMsg("Threads opgestart");

    return running;
}

void ThreadManager::joinAllThreads() {
    stalkCamCtx.camCV.notify_all();
    stalkCamCtx.triggerCV.notify_all();
    plcContext.plcCV.notify_all();

    if (paramCtx.SaveImages.load() || paramCtx.SaveAnalysedImages.load())
		fileManager.fileManagerCV.notify_all();

	if (fileHandlingThread.joinable()) fileHandlingThread.join();
    if (imageProcessingThread.joinable()) imageProcessingThread.join();
    if (CameraThread.joinable()) CameraThread.join();
    if (stalkEncoderThread.joinable()) stalkEncoderThread.join();
    if (handleRcCommandThread.joinable()) handleRcCommandThread.join();
    if (handleSndCommandThread.joinable()) handleSndCommandThread.join();
    if (simulationHandleSndCommandThread.joinable()) simulationHandleSndCommandThread.join();
    if (checkPlcHealthThread.joinable()) checkPlcHealthThread.join();
}

bool ThreadManager::stop() {
    running = false;

    joinAllThreads();

    loggerCtx.pushMsg("Threads gestopt");

    return running;
}

bool ThreadManager::init() {
    initialized = true;

    // Postgres = enkel settings-history
    if (paramCtx.UseHistoryDatabase.load()) {
        try
        {
            databaseThread = std::thread(&ThreadManager::databaseLoop, this);
        }
        catch (const std::exception&)
        {
            initialized = false;
        }

        loggerCtx.pushMsg("PostgresSQL connectie gestart");
    }

    // MySQL = results
    if (paramCtx.UseDatabase.load()) {
        try
        {
            sqlDatabaseThread = std::thread(&ThreadManager::sqlDatabaseLoop, this);
        }
        catch (const std::exception&)
        {
            initialized = false;
        }

        loggerCtx.pushMsg("SQL connectie gestart");
    }

    return initialized;
}

void ThreadManager::shutdown() {
    running = false;

    joinAllThreads();

    // Flush PostgreSQL queue (resterende settings-history rijen wegschrijven).
    auto startPostgres = std::chrono::steady_clock::now();
    while (!dbConnection.isQueueEmpty()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        if (std::chrono::steady_clock::now() - startPostgres > std::chrono::seconds(5)) break;
    }

    // Flush MySQL queue
    auto startMySQL = std::chrono::steady_clock::now();
    while (!mySQL.isQueueEmpty()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        if (std::chrono::steady_clock::now() - startMySQL > std::chrono::seconds(5)) break;
    }

    initialized = false;

    dbConnection.DbQueueCV.notify_all();
    mySQL.DbQueueCV.notify_all();

    if (databaseThread.joinable()) databaseThread.join();
    if (sqlDatabaseThread.joinable()) sqlDatabaseThread.join();
}

// Camera loops

void ThreadManager::CameraLoop() {
    while (running) {
        if (!loggerCtx.camIsHealthy) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }
        try {
            // Capture - wacht op trigger
            {
                std::unique_lock<std::mutex> lock(stalkCamCtx.triggerMutex);
                stalkCamCtx.triggerCV.wait(lock, [this] {
                    return stalkCamCtx.triggerPending || !running;
                    });

                if (!running)
                    break;

                stalkCamCtx.triggerPending = false;
            }

            cv::Mat src = CaptureImage(stalkCamCtx, loggerCtx);

            // Validate image
            if (src.empty()) {
                loggerCtx.pushMsg("Failed to capture", LogLevel::Error);
                continue;
            }

            // Plaats frame in thread-safe queue
            {
                std::lock_guard<std::mutex> lock(stalkCamCtx.camMutex);

                if (stalkCamCtx.imageQueue.size() >= stalkCamCtx.MAX_QUEUE_SIZE) {
                    stalkCamCtx.imageQueue.pop();
                    loggerCtx.pushMsg("Dataprocessing behind on aquisition. Image data lost.", LogLevel::Warning);
                }
                stalkCamCtx.imageQueue.push(src.clone());
            }

            stalkCamCtx.camCV.notify_one();

            loggerCtx.pushMsg("Afbeelding genomen", LogLevel::Debug);
        }
        catch (const std::exception& e) {
            std::string msg = std::string("Camera thread exception - ") + e.what();
            loggerCtx.pushMsg(msg, LogLevel::Error);

            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        catch (...) {
            std::string msg = std::string("Camera thread exception... Reason unknown");
            loggerCtx.pushMsg(msg, LogLevel::Error);

            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}

void ThreadManager::CameraTriggerLoop() {
    while (running) {
        if (!loggerCtx.camIsHealthy) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }
        try {
            if (!paramCtx.SendTrigger.load()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                continue;          
            }

            cv::Mat src = CaptureImage(stalkCamCtx, loggerCtx);

            // Validate image
            if (src.empty()) {
                loggerCtx.pushMsg("Failed to capture/load stalk image");
                paramCtx.SendTrigger.store(false);
                continue;
            }

            {
                std::lock_guard<std::mutex> lock(stalkCamCtx.camMutex);

                if (stalkCamCtx.imageQueue.size() >= stalkCamCtx.MAX_QUEUE_SIZE) {
                    loggerCtx.pushMsg("Data processing thread loopt achter op image aquisition", LogLevel::Warning);
                }
                stalkCamCtx.imageQueue.push(src.clone());
            }

            stalkCamCtx.camCV.notify_one();

            loggerCtx.pushMsg("Afbeelding genomen", LogLevel::Debug);

            // Reset trigger
            paramCtx.SendTrigger.store(false);

            std::this_thread::sleep_for(std::chrono::milliseconds(30));            
        }
        catch (const std::exception& e) {
            std::string msg = std::string("Camera thread exception - ") + e.what();
            loggerCtx.pushMsg(msg, LogLevel::Error);

            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        catch (...) {
            std::string msg = std::string("Camera thread exception... Reason unknown");
            loggerCtx.pushMsg(msg, LogLevel::Error);

            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}

void ThreadManager::cameraAcquisitionLoop()
{
    while (running) {
        // Controleer of camera gezond is
        if (!loggerCtx.camIsHealthy || !paramCtx.UseCamera.load()) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }

        try {
            CImageDataPointer objImagePtr = stalkCamCtx.pStream->DQBuf(5000); // timeout 5 sec
            if (!objImagePtr.IsNull() && objImagePtr->GetStatus() == GX_FRAME_STATUS_SUCCESS) {
                // capture
                int width = objImagePtr->GetWidth();
                int height = objImagePtr->GetHeight();
                uint8_t* buffer = (uint8_t*)objImagePtr->GetBuffer();

                cv::Mat img(height, width, CV_8UC1, buffer);

                // Plaats frame in thread-safe queue
                {
                    std::lock_guard<std::mutex> lock(stalkCamCtx.camMutex);

                    if (stalkCamCtx.imageQueue.size() >= stalkCamCtx.MAX_QUEUE_SIZE) {
                        stalkCamCtx.imageQueue.pop();
                        loggerCtx.pushMsg("Dataprocessing behind on aquisition. Image data lost.", LogLevel::Warning);
                    }
                    stalkCamCtx.imageQueue.push(img.clone());
                }

                stalkCamCtx.camCV.notify_one();

                loggerCtx.pushMsg("Afbeelding genomen", LogLevel::Debug);

                // Return buffer naar SDK)
                stalkCamCtx.pStream->QBuf(objImagePtr);
            }
            else {
                std::cerr << "Grab failed or timed out." << std::endl;
            }
        }
        catch (const CGalaxyException& e)
        {
            std::string msg = e.what();
            if (msg.find("-1011") != std::string::npos)
                continue;
            else
            {
                loggerCtx.pushMsg(std::string("Galaxy exception: ") + e.what(), LogLevel::Error);
                loggerCtx.camIsHealthy.store(false);
            }
        }
        catch (const std::exception& e)
        {
            loggerCtx.pushMsg(std::string("Camera exception: ") + e.what(), LogLevel::Error);
        }
    }
}

// Image processing loop

void ThreadManager::imageProcessingLoop() {
    while (running) {
        cv::Mat img;
        {
            std::unique_lock<std::mutex> lock(stalkCamCtx.camMutex);

            stalkCamCtx.camCV.wait(lock, [this] {
                return !stalkCamCtx.imageQueue.empty() || !running;
                });

            if (!running)
                return;

            // get img from pair
            img = stalkCamCtx.imageQueue.front();
            // remove from queue
            stalkCamCtx.imageQueue.pop();
        }

        // ----- outside lock ------

        loggerCtx.pushMsg("Analyseren van afbeelding...", LogLevel::Debug);

        // Haal PLC trigger data op (FR code + volgnummer van Siemens)
        std::string frCodePlc;
        int volgnummer = 1;
        {
            std::lock_guard<std::mutex> lock(triggerDataMutex);
            frCodePlc  = lastTriggerData.frCodePlc;
            volgnummer = lastTriggerData.sequenceNumber;
        }
        // PLC-vlaggen (bij UsePlc=false: waarden uit UI)
        const bool usePalletLabel   = paramCtx.UsePalletLabel.load();
        const bool usePalletCardbox = paramCtx.UsePalletCardbox.load();
        const bool saveHD           = paramCtx.SaveHD.load();

        // volgnummer == 1 → nieuwe sessie, anders retry binnen zelfde sessie.
        if (volgnummer <= 1)
            sessionManager.newCapture();
        else
            sessionManager.setTry(volgnummer);

        // Analyseer beeld
		AnalysedImage result;
        if (paramCtx.UseImageFlip.load()) {
            // rotate
            cv::Mat rotated;
            cv::rotate(img, rotated, cv::ROTATE_90_COUNTERCLOCKWISE);

            result = analysisAPI.analyseImage(rotated);
        }
        else
            result = analysisAPI.analyseImage(img);

        result.frCodePlc = frCodePlc;
        result.sessieId  = sessionManager.getSessionId();
        result.sequenceNr = sessionManager.getSequenceNr();
        result.lineNr    = sessionManager.getLineNr();

        result.finalize(usePalletLabel, usePalletCardbox);

        // Sla op
        if (paramCtx.SaveAnalysedImages.load()) {
            result.filePath = fileManager.enqueueImage(SaveCategory::AnalysedImages, result.anotatedImg, ".jpg", true);
            if (saveHD)
                fileManager.enqueueHdImage(SaveCategory::AnalysedImages, result.anotatedImg, result.filePath);
        }

        // MySQL: elke poging wegschrijven (OK en NOK)
        if (paramCtx.UseDatabase.load()) {
            PostgresCommand pgCmd;
            pgCmd.analysedImage = result;
            pgCmd.CmdStatus = CommandStatus::SendBarcodeCmd;
            if (!mySQL.pushToQueue(pgCmd))
                loggerCtx.pushMsg("Failed to insert command to MySQL queue", LogLevel::Error);
        }

        // Resultaat terug naar PLC — PLC beslist of hij opnieuw triggert
        SndCommand cmd = cmdHandler.analysedImageToSndCommand(result, static_cast<uint16_t>(paramCtx.SendTriggerCmdCode.load()));
        cmdHandler.pushCommand(cmd);

        // Log stats
        loggerCtx.commandsCreated.fetch_add(1);
        if (!result.frCodeImageLabel.empty() || !result.frCodeImageCardboard.empty()) loggerCtx.frCodesProcessed.fetch_add(1);
        if (!result.barcodeLabel.empty()) loggerCtx.barcodesProcessed.fetch_add(1);
        if (!result.barcodeCardboard.empty()) loggerCtx.barcodesProcessed.fetch_add(1);

        loggerCtx.pushMsg("Analyse van afbeelding afgerond", LogLevel::Debug);
    }
}

// Plc related loops

void ThreadManager::handleRcCommandLoop() {
    while (running) {
        if (!loggerCtx.plcIsHealthy) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }
        try {
            RcCommand cmd;
            if (plcContext.read(receiveCommandVarName, cmd)) {
                if (cmd.iCmd != 0 && cmd.iAnswId != cmd.iCmdId)
                {
                    if (cmd.iCmd == static_cast<uint16_t>(paramCtx.RecieveTriggerCmdCode.load()))
                    {
                        // FR code + volgnummer opslaan voor imageProcessingLoop
                        {
                            std::lock_guard<std::mutex> lock(triggerDataMutex);
                            lastTriggerData.frCodePlc = std::string(cmd.asArg[0].data);
                            lastTriggerData.sequenceNumber = cmd.adArg[0];
                        }

                        // PLC adArg[1..4] command info
                        paramCtx.UsePalletCardbox.store(cmd.adArg[1] != 0);
                        paramCtx.UsePalletLabel.store(cmd.adArg[2] != 0);
                        paramCtx.SaveHD.store(cmd.adArg[3] != 0);
                        paramCtx.DisableCam.store(cmd.adArg[4] != 0);

                        if (paramCtx.DisableCam.load()) {
                            // Camera disabled: geen foto, direct CamDisabled naar PLC
                            cmdHandler.pushCamDisabledResult(std::string(cmd.asArg[0].data), cmd.adArg[0]);

                            loggerCtx.pushMsg("Trigger recieved - camera disabled", LogLevel::Debug);
                        }
                        else {
                            // Afbeelding triggeren
                            {
                                std::lock_guard<std::mutex> lock(stalkCamCtx.triggerMutex);
                                stalkCamCtx.triggerPending = true;
                            }
                            stalkCamCtx.triggerCV.notify_one();

                            loggerCtx.pushMsg("Trigger recieved", LogLevel::Debug);
                        }

                        // Command recieved
                        cmd.iAnswId = cmd.iCmdId;

                        // Send Command
                        if(plcContext.write(receiveCommandVarName, cmd))
                            loggerCtx.pushMsg("Trigger acked", LogLevel::Debug);
                    }
                }
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(3));
        }
        catch (const std::exception& e) {
            std::string msg = std::string("Fatal: Failed at reading PLC Command - ") + e.what();
            loggerCtx.pushMsg(msg, LogLevel::Error);
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        catch (...) {
            std::string msg = std::string("Fatal: Failed at reading PLC Command - ");
            loggerCtx.pushMsg(msg, LogLevel::Error);
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}

void ThreadManager::handleSndCommandLoop() {
    using clock = std::chrono::steady_clock;

    constexpr auto ACK_TIMEOUT = std::chrono::milliseconds(200);
    constexpr int MAX_RETRIES = 10;

    uint16_t writtenCmdId = 0;
    bool awaitingAck = false;
    int retryCount = 0;
    clock::time_point lastWrite{};

    while (running) {
        if (!loggerCtx.plcIsHealthy) {
            awaitingAck = false;
            retryCount = 0;
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }
        try {
            SndCommand cmd;
            if (cmdHandler.peekCommand(cmd)) {
                bool isNewCommand = !awaitingAck || cmd.iCmdId != writtenCmdId;
                bool ackTimedOut = !isNewCommand && (clock::now() - lastWrite >= ACK_TIMEOUT);

                if (isNewCommand)
                    retryCount = 0;

                if (ackTimedOut && retryCount >= MAX_RETRIES) {
                    // Ack-protocol zit vast of PLC reageert niet meer:
                    // reconnector activeren. Commando blijft in de queue.
                    loggerCtx.plcIsHealthy.store(false);
                    loggerCtx.pushMsg("No PLC ack after " + std::to_string(MAX_RETRIES) +
                        " retries for cmd " + std::to_string(writtenCmdId) + ". Marking PLC unhealthy.");
                    awaitingAck = false;
                    retryCount = 0;
                    continue;
                }

                if (isNewCommand || ackTimedOut) {
                    // Nieuw commando of geen ack binnen timeout: (her)schrijven.
                    if (ackTimedOut) {
                        ++retryCount;
                        if (retryCount == 1)
                            loggerCtx.pushMsg("No PLC ack for cmd " + std::to_string(writtenCmdId) + ". Rewriting command.", LogLevel::Warning);
                    }
                    if (plcContext.write(sendCommandVarName, cmd)) {
                        writtenCmdId = cmd.iCmdId;
                        awaitingAck = true;
                        lastWrite = clock::now();

                        loggerCtx.pushMsg("Barcodes send to PLC.", LogLevel::Debug);
                    }
                }
                else {
                    // Al geschreven: enkel de ack pollen (1 ADS-call i.p.v. write+read).
                    SndCommand read;
                    if (plcContext.read(sendCommandVarName, read) && read.iAnswId == writtenCmdId) {

                        // pop
                        cmdHandler.popCommand();

                        // clear
                        SndCommand clear;
                        clear.iCmd = 0;
                        clear.iCmdId = 0;
                        clear.iAnswId = 0;
                        if (plcContext.write(sendCommandVarName, clear))
                            loggerCtx.pushMsg(sendCommandVarName + ": cleared", LogLevel::Debug);

                        awaitingAck = false;
                        retryCount = 0;
                    }
                }
            }
            else {
                awaitingAck = false;
                retryCount = 0;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(5));
        }
        catch (const std::exception& e) {
            awaitingAck = false;
            retryCount = 0;
            std::string msg = std::string("Fatal: Failed at writing PLC Command - ") + e.what();
            loggerCtx.pushMsg(msg, LogLevel::Error);
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        catch (...) {
            awaitingAck = false;
            retryCount = 0;
            std::string msg = std::string("Fatal: Failed at writing PLC Command - ");
            loggerCtx.pushMsg(msg, LogLevel::Error);
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}

void ThreadManager::checkPlcHealthLoop() {
    int32_t counter = 0;
    while (running) {
        if (!loggerCtx.plcIsHealthy) {
            std::this_thread::sleep_for(std::chrono::minutes(3));
            continue;
        }
        try {
            if (loggerCtx.camIsHealthy.load())
                counter++;
            if (!plcContext.write(camHealthCommandVarName, counter)) {
                loggerCtx.plcIsHealthy.store(false);
                loggerCtx.pushMsg("Plc is disconnected!", LogLevel::Error);
            }
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        catch (const std::exception&) {
            loggerCtx.plcIsHealthy.store(false);
            loggerCtx.pushMsg("Something went wrong while checking PLC health", LogLevel::Error);
        }
    }
}

// Simulation loops

void ThreadManager::simulationHandleSndCommandLoop() {
    while (running) {
        try {
            SndCommand write;
            if (cmdHandler.peekCommand(write))
                cmdHandler.popCommand();

            std::this_thread::sleep_for(std::chrono::milliseconds(5));
        }
        catch (const std::exception& e) {
            std::string msg = std::string("Fatal: Failed at writing PLC Command - ") + e.what();
            loggerCtx.pushMsg(msg, LogLevel::Error);

            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        catch (...) {
            std::string msg = std::string("Fatal: Failed at writing PLC Command - ");
            loggerCtx.pushMsg(msg, LogLevel::Error);

            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}

void ThreadManager::simulationCameraTriggerLoop() {
    while (running) {
        if (!loggerCtx.camIsHealthy) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }
        try {
            if (!paramCtx.SendTrigger.load()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                continue;
            }

            cv::Mat src = loadRandomImage(rawImagePath);

            // Validate image
            if (src.empty()) {
                loggerCtx.pushMsg("Failed to capture/load stalk image");
                continue;
            }

            {
                std::lock_guard<std::mutex> lock(stalkCamCtx.camMutex);

                if (stalkCamCtx.imageQueue.size() >= stalkCamCtx.MAX_QUEUE_SIZE) {
                    loggerCtx.pushMsg("Data processing thread loopt achter op image aquisition", LogLevel::Warning);
                }
                stalkCamCtx.imageQueue.push(src.clone());
            }

            stalkCamCtx.camCV.notify_one();

            // Reset trigger: atomic is nu de bron van waarheid (geen DB-omweg).
            paramCtx.SendTrigger.store(false);

            std::this_thread::sleep_for(std::chrono::milliseconds(30));            
        }
        catch (const std::exception& e) {
            std::string msg = std::string("Camera thread exception - ") + e.what();
            loggerCtx.pushMsg(msg, LogLevel::Error);

            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        catch (...) {
            std::string msg = std::string("Camera thread exception... Reason unknown");
            loggerCtx.pushMsg(msg, LogLevel::Error);

            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}

// Database loops

void ThreadManager::sqlDatabaseLoop() {
    constexpr int MAX_RETRIES = 5;
    int failedAttempts = 0;

    while (initialized) {
        if (!loggerCtx.sqlDatabaseIsHealthy) {
            failedAttempts = 0;
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }

        {
            std::unique_lock<std::mutex> lock(mySQL.DbQueueMutex);
            mySQL.DbQueueCV.wait(lock, [this] {
                return !mySQL.DbQueue.empty() || !initialized;
            });
        }
        if (!initialized) break;

        try {
            while (loggerCtx.sqlDatabaseIsHealthy && !mySQL.isQueueEmpty()) {
                if (mySQL.processNextCommand()) {
                    failedAttempts = 0;
                    loggerCtx.pushMsg("Barcode data stored.", LogLevel::Debug);
                }
                else {
                    if (++failedAttempts >= MAX_RETRIES) {
                        loggerCtx.sqlDatabaseIsHealthy.store(false);
                        loggerCtx.pushMsg("Database marked unhealthy after "
                            + std::to_string(MAX_RETRIES) + " failed insert attempts");
                        break;
                    }
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                }
                if (!initialized) break;
            }
        }
        catch (const std::exception& e) {
            loggerCtx.pushMsg(std::string("DB Worker Exception: ") + e.what(), LogLevel::Error);
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        catch (...) {
            loggerCtx.pushMsg("DB Worker Unknown Exception", LogLevel::Error);
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}

void ThreadManager::databaseLoop() {
    constexpr int MAX_RETRIES = 5;
    int failedAttempts = 0;

    while (initialized) {
        if (!loggerCtx.databaseIsHealthy) {
            failedAttempts = 0;
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }

        {
            std::unique_lock<std::mutex> lock(dbConnection.DbQueueMutex);
            dbConnection.DbQueueCV.wait(lock, [this] {
                return !dbConnection.DbQueue.empty() || !initialized;
                });
        }
        if (!initialized) break;

        try {
            while (loggerCtx.databaseIsHealthy && !dbConnection.isQueueEmpty()) {
                if (dbConnection.processNextCommand()) {
                    failedAttempts = 0;
                    loggerCtx.pushMsg("Config written to history table", LogLevel::Debug);
                }
                else {
                    if (++failedAttempts >= MAX_RETRIES) {
                        loggerCtx.databaseIsHealthy.store(false);
                        loggerCtx.pushMsg("Database marked unhealthy after "
                            + std::to_string(MAX_RETRIES) + " failed insert attempts");
                        break;
                    }
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                }
                if (!initialized) break;
            }
        }
        catch (const std::exception& e) {
            loggerCtx.pushMsg(std::string("DB Worker Exception: ") + e.what(), LogLevel::Error);
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        catch (...) {
            loggerCtx.pushMsg("DB Worker Unknown Exception", LogLevel::Error);
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
}

// Filehandling

void ThreadManager::fileHandlingLoop() {
    while (running) {
        try {
			FileJob job;
            {
                std::unique_lock<std::mutex> lock(fileManager.fileManagerMutex);

                fileManager.fileManagerCV.wait(lock, [this] {
                    return !fileManager.fileQueue.empty() || !running;
                });

                if (!running)
                    return;

                // get img from pair
				job = fileManager.fileQueue.front();
                fileManager.fileQueue.pop();
            }

            // ouside lock
            if (job.isImage)
                fileManager.saveImage(job.image, job.fullPath, job.jpegQuality);

            loggerCtx.pushMsg("File saved", LogLevel::Debug);
        }
        catch (const std::exception& e) {
            loggerCtx.pushMsg(std::string("File handling exception: ") + e.what(), LogLevel::Error);
        }
        catch (...) {
            loggerCtx.pushMsg("File handling unknown exception", LogLevel::Error);
        }
    }
}   

cv::Mat loadRandomImage(const std::string& folderPath) {
    // Verzamel afbeeldingen in folderPath zelf EN in eventuele submappen (bv. "0"),
    static const char* kPatterns[] = {
        "*.bmp", "*.png", "*.jpg", "*.jpeg", "*.tif", "*.tiff"
    };

    std::vector<cv::String> files;
    for (const char* pat : kPatterns) {
        std::vector<cv::String> found;
        try {
            // recursive = true -> zoekt ook in submappen
            cv::glob(folderPath + "\\" + pat, found, true);
        }
        catch (const cv::Exception&) {
            continue;   // map bestaat niet / niet leesbaar -> volgende patroon
        }
        files.insert(files.end(), found.begin(), found.end());
    }

    if (files.empty())
        return cv::Mat();

    // Random generator (eenmalig geseed, per thread).
    static thread_local std::mt19937 gen(std::random_device{}());
    std::uniform_int_distribution<size_t> fileDist(0, files.size() - 1);

    return cv::imread(files[fileDist(gen)], cv::IMREAD_GRAYSCALE);
}

