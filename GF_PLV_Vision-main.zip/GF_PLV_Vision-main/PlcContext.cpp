#include "PlcContext.h"

#include <string>
#include <vector>
#include <sstream>
#include <thread>
#include <mutex>
#include <chrono>

#include "Logger.h"
#include "Parameters.h"
#include "PlcConfig.h"
#include "SndCommand.h"
#include "RcCommand.h"
#include "CommandStatus.h"

#include "TcAdsDef.h"
#include "TcAdsApi.h"

bool PlcContext::open() {
    std::scoped_lock lock(adsMutex, ParametersContext.paramMutex);

    if (adsPort > 0) {
        logger.plcIsHealthy = true;
        return true;
    }

    adsPort = AdsPortOpen();
    if (adsPort <= 0) {
        logger.pushMsg("FATAL: Failed to connect to PLC\n");
        logger.plcIsHealthy = false;
        return false;
    }

    long nErr = AdsGetLocalAddress(&localAddr);
    if (nErr) {
        AdsPortClose();
        adsPort = 0;

        logger.pushMsg("AdsGetLocalAddress failed: " + std::to_string(nErr));
        logger.plcIsHealthy = false;
        return false;
    }

    if (!parseAmsNetId(ParametersContext.AmsNetId, remoteAddr.netId.b)) {
        AdsPortClose();
        adsPort = 0;

        logger.pushMsg("Invalid AMS Net ID format: " + ParametersContext.AmsNetId);
        logger.plcIsHealthy = false;
        return false;
    }
    remoteAddr.port = ParametersContext.PortNr.load();

    logger.plcIsHealthy = true;
    return true;
}

bool PlcContext::sendAndRecievePlcAliveRequest() {
    if (!isConnected()) {
        logger.plcIsHealthy.store(false);
        return false;
    }

    std::scoped_lock lock(adsMutex);

    SndCommand alive(CommandStatus::SendIsAliveCmd);
    if (!write(ParametersContext.SendCommand, alive)) {
        logger.plcIsHealthy.store(false);
        return false;
    }

    // Let Plc process before read
    std::this_thread::sleep_for(std::chrono::milliseconds(10));

    RcCommand response;
    if (!read(ParametersContext.SendCommand, response)) {
        logger.plcIsHealthy.store(false);
        return false;
    }

    if (response.iAnswId != alive.iCmdId) {
        logger.plcIsHealthy.store(false);
        return false;
    }

    // clear
    SndCommand clear;
    clear.iCmd = 0;
    clear.iCmdId = 0;
    clear.iAnswId = 0;

    // send
    write(ParametersContext.SendCommand, clear);

    logger.plcIsHealthy.store(true);
    return true;
}

void PlcContext::close() {
    std::lock_guard<std::mutex> lock(adsMutex);

    for (auto& [name, handle] : handleCache) {
        AdsSyncWriteReq(&remoteAddr, ADSIGRP_SYM_RELEASEHND, 0, sizeof(handle), &handle);
    }

    handleCache.clear();

    if (adsPort > 0) {
        AdsPortClose();
        adsPort = 0;
    }
}

bool PlcContext::isConnected() const {
    std::lock_guard lock(adsMutex);
    return adsPort > 0; 
}

bool PlcContext::readString(const std::string& variable, std::string& value, size_t maxLen) {
    if (maxLen == 0) maxLen = config.maxStringLength;
    std::vector<char> buffer(maxLen, '\0');

    std::lock_guard<std::mutex> lock(adsMutex);
    if (!ensureConnected()) return false;

    long handle;
    if (!getHandle(variable, handle)) return false;

    long nErr = AdsSyncReadReq(&remoteAddr, ADSIGRP_SYM_VALBYHND, handle,
        static_cast<unsigned long>(maxLen), buffer.data());

    if (nErr) {
        logger.pushMsg("Read string error for " + variable + ": " + std::to_string(nErr));
        return false;
    }

    buffer[maxLen - 1] = '\0';
    value.assign(buffer.data());
    return true;
}

bool PlcContext::writeString(const std::string& variable, const std::string& value) {
    std::lock_guard<std::mutex> lock(adsMutex);
    if (!ensureConnected()) return false;

    long handle;
    if (!getHandle(variable, handle)) return false;

    std::vector<char> buffer(value.begin(), value.end());
    buffer.push_back('\0');

    long nErr = AdsSyncWriteReq(&remoteAddr, ADSIGRP_SYM_VALBYHND, handle,
        static_cast<unsigned long>(buffer.size()), buffer.data());

    if (nErr) {
        logger.pushMsg("Write string error for " + variable + ": " + std::to_string(nErr));
        return false;
    }
    return true;
}

bool PlcContext::ensureConnected() {
    if (adsPort > 0) return true;
    return openInternal();
}

bool PlcContext::openInternal() {
    std::lock_guard<std::mutex> lock(ParametersContext.paramMutex);

    if (adsPort > 0) return true;

    adsPort = AdsPortOpen();
    if (adsPort <= 0) {
        logger.pushMsg("Failed to open ADS port");
        return false;
    }

    long nErr = AdsGetLocalAddress(&localAddr);
    if (nErr) {
        logger.pushMsg("AdsGetLocalAddress failed: " + std::to_string(nErr));
        AdsPortClose();
        adsPort = 0;
        return false;
    }

    if (!parseAmsNetId(ParametersContext.AmsNetId, remoteAddr.netId.b)) {
        logger.pushMsg("Invalid AMS Net ID format: " + ParametersContext.AmsNetId);
        AdsPortClose();
        adsPort = 0;
        return false;
    }

    remoteAddr.port = ParametersContext.PortNr.load();
    return true;
}

bool PlcContext::getHandle(const std::string& variable, long& handle)
{
    auto it = handleCache.find(variable);
    if (it != handleCache.end()) {
        handle = it->second;
        return true;
    }

    long nErr = AdsSyncReadWriteReq(
        &remoteAddr,
        ADSIGRP_SYM_HNDBYNAME,
        0,
        sizeof(handle),
        &handle,
        static_cast<unsigned long>(variable.size() + 1),
        const_cast<char*>(variable.c_str())
    );

    if (nErr) {
        logger.pushMsg("Failed to get handle for " + variable + ": " + std::to_string(nErr));
        return false;
    }

    handleCache[variable] = handle;

    return true;
}

bool PlcContext::parseAmsNetId(const std::string& netId, uint8_t* bytes) {
    std::stringstream ss(netId);
    std::string segment;
    size_t i = 0;

    while (std::getline(ss, segment, '.') && i < 6) {
        try {
            int value = std::stoi(segment);
            if (value < 0 || value > 255) {
                logger.pushMsg("AMS Net ID segment out of range (0-255): " + std::to_string(value));
                return false;
            }
			bytes[i++] = static_cast<uint8_t>(value);
        }
        catch (const std::exception& e) {
            logger.pushMsg("Failed to parse AMS Net ID segment: " + segment + " (" + e.what() + ")");
            return false;
        }
    }

    if (i != 6) {
        logger.pushMsg("AMS Net ID must have exactly 6 segments, got: " + std::to_string(i));
        return false;
    }

    return true;
}