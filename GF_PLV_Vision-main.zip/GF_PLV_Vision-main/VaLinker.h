#pragma once

#include <vector>
#include <string>
#include <memory>

#include "MinimalWindows.h"

#include "GalaxyIncludes.h"
#include <opencv2/core.hpp>

// Forward declaration
class CameraContext;
class Parameters;
class Logger;

void SetCamParametersAndStartAcquisition(std::vector<CGXDevicePointer>& vectorDevPtr
    , std::vector<CGXFeatureControlPointer>& vectorRemoteControl
    , std::vector<CGXStreamPointer>& vectorStream);

cv::Mat ShowActionCommand(std::vector<CGXDevicePointer>& vectorDevPtr
    , std::vector<CGXStreamPointer>& vectorStream
	, GX_GIGE_ACTION_COMMAND_RESULT** pResultBuffer);

void StopAcquisitionAndCloseCam(std::vector<CGXDevicePointer>& vectorDevPtr
    , std::vector<CGXFeatureControlPointer>& vectorRemoteControl
    , std::vector<CGXStreamPointer>& vectorStream);

void CheckCamParameters(std::vector<CGXDevicePointer>& vectorDevPtr, 
    std::vector<CGXFeatureControlPointer>& vectorRemoteControl);

cv::Mat GenerateImageFromCamera();

bool OpenCamera(CameraContext& ctx, Parameters& paramCtx, Logger& logger);
cv::Mat CaptureImage(CameraContext& ctx, Logger& logger);
bool CaptureAndSaveImage(CameraContext& ctx, const std::string& path);
void CloseCamera(CameraContext& ctx);

// Eén camera per applicatie (vlakke config, geen lijst).
std::shared_ptr<CameraContext> createCameraContext(Parameters& paramCtx);
void UpdateCameraSettings(CameraContext& ctx);
