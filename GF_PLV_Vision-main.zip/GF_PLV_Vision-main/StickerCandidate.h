#pragma once

#include <vector>
#include <opencv2/core.hpp>

struct StickerCandidate {
    std::vector<cv::Point> contour;
    double quality = 0.0;   // rechthoekigheid * volheid (1.0 = perfecte rechthoek)
    double score = 0.0;
};
