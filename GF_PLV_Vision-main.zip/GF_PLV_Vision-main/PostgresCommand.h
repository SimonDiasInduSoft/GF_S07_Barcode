#pragma once

#include <vector>
#include <optional>

#include "CommandStatus.h"
#include "PlcCamData.h"
#include "Parameter.h"
#include "AnalysedImage.h"

struct PostgresCommand {
	std::vector<std::string> CamData;
	Parameter Param;
	CommandStatus CmdStatus;
	std::optional<AnalysedImage> analysedImage;
};