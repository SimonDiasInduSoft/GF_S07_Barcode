#pragma once

#include <string>
#include <mutex>
#include <atomic>

#include <opencv2/core.hpp>

struct CalibrationContext {
    // Lens distortion
    cv::Mat cameraMatrix; 
    cv::Mat distCoeffs;
    
    // Calibration params
    cv::Mat newCameraMatrix;
    cv::Mat map1;
    cv::Mat map2;

    double reprojectionError = 0.0;
    double calibrationDistanceMM = 0.0;

	// Pixel to mm ratio
    float mmPerPixelX = 0;
    float mmPerPixelY = 0;
    float averageMMperPixel = 0;

    float encoderPickValPerMM = 0;
    float encoderPlaceValPerMM = 0;

    // Omschalen naar co�rdinaten Robot
    cv::Point2f origin = cv::Point2f(0, 0);
    cv::Point2f xAxis = cv::Point2f(0, 0);
    cv::Point2f yAxis = cv::Point2f(0, 0);
    cv::Matx22f rotation = cv::Matx22f::zeros();

	// Calibration file path
    std::string calibFile = "camera_calibration.yml";

	// Flag to indicate if calibration is done
    bool isCalibrated = false;

    void updateAverageMMperPixel() {
		if (mmPerPixelX > 0 && mmPerPixelY > 0)
            averageMMperPixel = (mmPerPixelX + mmPerPixelY) / 2.0f;
	}
};