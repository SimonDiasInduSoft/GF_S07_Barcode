#include "FileManager.h"
#include "Parameters.h"
#include "SaveState.h"
#include "SaveCategory.h"
#include "Logger.h"

#include <string>
#include <mutex>
#include <filesystem>
#include <iostream>
#include <fstream>
#include <chrono>
#include <utility>
#include <optional>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>

namespace fs = std::filesystem;

void FileManager::snapshotPaths() {
    std::lock_guard<std::mutex> lock(ParamCtx.paramMutex);

    AnalysedImagesPath = ParamCtx.AnalysedImagesPath;
    RawImagePath = ParamCtx.RawImagePath;
}

void FileManager::initSaveStates() {
    addSaveState(SaveCategory::AnalysedImages, AnalysedImagesPath);
    addSaveState(SaveCategory::RawImages, RawImagePath);
}

void FileManager::addSaveState(SaveCategory cat, const std::string& path) {
    auto state = std::make_unique<SaveState>(cat, path);
    initSaveState(*state);
    saveStates[cat] = std::move(state);
}


void FileManager::initSaveState(SaveState& state) {
    auto counters = getCurrentFolderAndFileIndex(state.basePath);

    state.folderIndex = counters.first;
    state.imageIndex = counters.second;
}


std::pair<int, int> FileManager::getCurrentFolderAndFileIndex(const fs::path& baseFolder) {
    int folderIndex = 0;
    int imageIndex = 0;

    if (!fs::exists(baseFolder))
        fs::create_directories(baseFolder);

    // Tel bestaande folders met numerieke namen
    int maxFolder = -1;
    for (const auto& entry : fs::directory_iterator(baseFolder)) {
        if (entry.is_directory()) {
            try {
                int idx = std::stoi(entry.path().filename().string());
                if (idx > maxFolder) maxFolder = idx;
            }
            catch (...) {}
        }
    }

    folderIndex = std::max(0, maxFolder);

    // Tel images in laatste folder
    fs::path lastFolder = baseFolder / std::to_string(folderIndex);
    if (!fs::exists(lastFolder))
        fs::create_directory(lastFolder);

    for (const auto& entry : fs::directory_iterator(lastFolder)) {
        if (!entry.is_regular_file())
            continue;
        // HD-kopieen tellen niet mee als aparte index
        std::string stem = entry.path().stem().string();
        if (stem.size() >= 3 && stem.compare(stem.size() - 3, 3, "_HD") == 0)
            continue;
        ++imageIndex;
    }

    return { folderIndex, imageIndex };
}

bool FileManager::saveImage(const cv::Mat& image, const fs::path fullPath, int jpegQuality) {
    std::vector<int> params;

    try {
        if (fullPath.extension() == ".jpg") {
            params = { cv::IMWRITE_JPEG_QUALITY, jpegQuality, cv::IMWRITE_JPEG_OPTIMIZE, 1 };
        }

        if (!cv::imwrite(fullPath.string(), image, params)) {
            std::string msg = "Failed to write image: " + fullPath.string() + "\n";
            logger.pushMsg(msg);
            logger.storageIsHealthy.store(false);
            return false;
         }
    }
    catch (const std::exception& e) {
        std::string msg = std::string("Exception writing image: ") + e.what() + "\n";
        logger.pushMsg(msg);
        logger.storageIsHealthy.store(false);
        return false;
    }

    logger.storageIsHealthy.store(true);

    if (ParamCtx.DebugMode.load())
        std::cout << "Afbeelding opgeslagen: " + fullPath.string() << std::endl;

    return true;
}

// Get path and return as string
std::optional<std::pair<fs::path, std::string>> FileManager::getPaths(SaveCategory cat, const std::string& fileType) {
    auto it = saveStates.find(cat);
    if (it == saveStates.end()) 
        return std::nullopt;

    SaveState& state = *(it->second);

    // Get limits
    int folderLimit = 0;
    int imagesFolderLimit = 0;

    if (cat == SaveCategory::AnalysedImages) {
        folderLimit = ParamCtx.AnalysedFolderLimit.load();
        imagesFolderLimit = ParamCtx.AnalysedImagesLimit.load();
    }
    else {
        folderLimit = ParamCtx.FolderLimit.load();
        imagesFolderLimit = ParamCtx.ImageFolderLimit.load();
    }

    // Get next image index
    int imgIdx = state.imageIndex.fetch_add(1);
    int folder = state.folderIndex.load();

    // Check for rollover
    if (imgIdx >= imagesFolderLimit) {
        std::lock_guard<std::mutex> lock(state.folderMutex);

        // Double-check after acquiring lock
        if (state.imageIndex >= imagesFolderLimit) {
            // Advance folder
            int newFolder = (state.folderIndex.load() + 1) % folderLimit;
            state.folderIndex.store(newFolder);

            // Clear new folder
            fs::path rolloverFolder = state.basePath / std::to_string(newFolder);
            if (fs::exists(rolloverFolder)) {
                fs::remove_all(rolloverFolder);
            }
            fs::create_directories(rolloverFolder);

            // Reset image counter
            state.imageIndex.store(0);
        }

        // Recalculate after potential reset
        folder = state.folderIndex.load();
        imgIdx = state.imageIndex.fetch_add(1);
    }

    // Build path
    fs::path folderPath = state.basePath / std::to_string(folder);
    if (!fs::exists(folderPath)) {
        fs::create_directories(folderPath);
    }

    std::string filename = std::to_string(imgIdx) + fileType;
    fs::path filePath = folderPath / filename;

    fs::path normalized = filePath.lexically_normal();
    std::string pathString = normalized.make_preferred().string();

	return std::make_optional(std::make_pair(filePath, pathString));
}

// FileManager.cpp
std::string FileManager::enqueueImage(SaveCategory cat, const cv::Mat& image, const std::string& fileType, bool doResize) {
    auto paths = getPaths(cat, fileType);
    if (!paths.has_value()) return "";

    FileJob job;
    job.category = cat;
    job.isImage = true;
    job.type = fileType;
    job.fullPath = paths->first;
    job.pathString = paths->second;

    constexpr int maxWidth = 1600;
    if (doResize && !image.empty() && image.cols > maxWidth) {
        double s = static_cast<double>(maxWidth) / image.cols;
        cv::resize(image, job.image, cv::Size(), s, s, cv::INTER_AREA);
    }
    else job.image = image.clone();

    {
        std::lock_guard<std::mutex> lock(fileManagerMutex);
        fileQueue.push(std::move(job));
    }
    fileManagerCV.notify_one();

    return paths->second;
}

std::string FileManager::enqueueHdImage(SaveCategory cat, const cv::Mat& image, const std::string& basePath) {
    if (basePath.empty() || image.empty()) return "";

    fs::path base(basePath);
    fs::path hdPath = base.parent_path() / (base.stem().string() + "_HD" + base.extension().string());

    FileJob job;
    job.category = cat;
    job.isImage = true;
    job.type = base.extension().string();
    job.fullPath = hdPath;
    job.pathString = hdPath.string();
    job.jpegQuality = 100;
    job.image = image.clone();

    {
        std::lock_guard<std::mutex> lock(fileManagerMutex);
        fileQueue.push(std::move(job));
    }
    fileManagerCV.notify_one();

    return hdPath.string();
}
