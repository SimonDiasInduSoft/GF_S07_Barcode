#pragma once

#include <string>
#include <atomic>
#include <mutex>
#include <unordered_map>

// Forward declaration
struct Parameter;

class Parameters {
	public:
		Parameters() = default;

		// ----------- Generale parameters ------------
		// True = gebruik afbeelding van de camera, False = gebruik test afbeelding van schijf
		std::atomic<bool> UseCamera{ false };
		std::atomic<bool> UseDatabase{ true };
		std::atomic<bool> UseHistoryDatabase{ true };
		std::atomic<bool> UsePlc{ true };

		std::atomic<bool> UseHardwareTrigger{ false };

		std::atomic<bool> ShutDownAnalysis{ false };
		std::atomic<bool> StartAnalysis{ false };

		std::atomic<bool> ConfigurationMode{ false };
		std::string ClientAnswer = "";

		// Console logs aan/uit
		std::atomic<bool> DebugMode{ false };
		// Software trigger met enter
		std::atomic<bool> UseManualTrigger{ false };
		std::atomic<bool> SendTrigger{ false };
		// Afbeeldingen opslaan ja/nee
		std::atomic<bool> SaveImages{ true };
		// Genalyseerde afbeeldingen opslaan
		std::atomic<bool> SaveAnalysedImages{ true };

		// Need img flip
		std::atomic<bool> UseImageFlip{ false };

		// File handling
		std::atomic<bool> AutoDeleteOn{ true };
		std::atomic<int> ImageFolderLimit{ 10000 };
		std::atomic<int> FolderLimit{ 10 };
		std::atomic<int> AnalysedFolderLimit{ 1 };
		std::atomic<int> AnalysedImagesLimit{ 1000 };

		// ----------- AI Model parameters ------------
		// Gebruik van object detectie model
		std::atomic<bool> UseModelDetection{ false };
		std::atomic<bool> UseModelDetectionTraining{ false };

		// Path naar object detectie model
		std::string ObjectDetectionModelPath = "C:\\_InduSoftSource\\Va_Images\\Model_versions\\my_model_V1M\\my_model.onnx";
		// Zekerheid van detectie
		std::atomic<float> ObjectDetectionConfThreshold{ 0.7f };
		std::atomic<float> ObjectDetectionNMSThreshold{ 0.3f };

		// Google Vision API-key (OCR). Leeg = geen Vision-calls. Aanpasbaar via UI.
		std::string VisionApiKey = "";

		// ----------- Analyse parameters ------------
		std::atomic<bool> CompareCardbox{ true }; // niet meer gebruikt: vervangen door PLC-vlaggen hieronder

		// ----------- PLC-gestuurde vlaggen (bij elke trigger-cmd overschreven, niet in config) ------------
		// PLC adArg[2]: FR code op karton (doos print) vergelijken met FR code PLC
		std::atomic<bool> UsePalletCardbox{ true };
		// PLC adArg[3]: FR code op pallet label vergelijken met FR code PLC
		std::atomic<bool> UsePalletLabel{ true };
		// PLC adArg[4]: geanalyseerd beeld ook in HD opslaan (<naam>_HD.jpg)
		std::atomic<bool> SaveHD{ false };
		// PLC adArg[5]: camera uitschakelen
		std::atomic<bool> DisableCam{ false };

		// ----------- Camera parameters -------------
		// Eén camera per applicatie-instantie (vlakke configuratie, geen lijst meer).
		// CameraSerial selecteert het fysieke Galaxy-toestel.
		std::string CameraName          = "barcode";
		std::string CameraSerial        = "FBF25110676";
		std::string CameraUserSet       = "userSet0";
		std::string CameraTriggerMode   = "on";
		std::string CameraTriggerSource = "software";
		std::atomic<int>   CameraWidth{ 1392 };
		std::atomic<int>   CameraHeight{ 1690 };
		std::atomic<int>   CameraOffsetX{ 792 };
		std::atomic<int>   CameraOffsetY{ 20 };
		std::atomic<float> CameraGain{ 4.0f };
		std::atomic<float> CameraExposure{ 40000.0f };
		// ----------- Default image input parameters -------------
		std::atomic<int> DefaultWidth{ 1000 };
		std::atomic<int> DefaultHeight{ 1000 };

		// Nodig voor strings of andere complexe data types
		std::mutex paramMutex;

		// ---------- Database setup --------------
		std::string DbUserName = "postgres";
		std::string DbPassword = "admin";
		std::string DbHostIp = "localhost";
		std::string DbName = "GF_Lijn1";
		std::atomic<int> DbPort = 5432;

		std::string ParamListenerId = "param_change";
		// Wie wijzigingen maakt (verschijnt in de Postgres settings-history).
		std::string ChangedBy = "local-ui";

		// lijn
		std::atomic<int> LineNr{ 1 };

		// SQL
		std::string SQLUserName = "admin";
		std::string SQLPassword = "admin";
		std::string SQLHostIp = "localhost";
		std::string SQLDbName = "plv_results";
		std::atomic<int> SQLPort = 3306;

		// ------------- PLC setup ----------------
		std::string AmsNetId = "192.168.151.200.1.1";
		std::atomic<int> PortNr = 851;

		// Send/recieve commands
		std::string RecieveCommand = "d1_varPlc.isToVisionLeft";
		std::string SendCommand = "d1_varPlc.isFromVisionLeft";

		std::string CamHealthCommand = "d1_varPlc.iCam4080IsAlive";

		// Foutmeldingen PC -> PLC (BOOL, TRUE = fout). Leeg = niet versturen.
		std::string CamErrorCommand       = "d1_varPlc.isErr.eConVision_CNV1"; // Of CNV2
		std::string DbErrorCommand		  = "d1_varPlc.isErr.eConVision_Db";
		std::string StorageErrorCommand   = "d1_varPlc.isErr.eConVision_Storage";
		std::string GoogleErrorCommand    = "d1_varPlc.isErr.eConVision_Google";

		// Command-codes voor trigger-commando's (moeten overeenkomen met het PLC-programma).
		// Was hardcoded op CommandStatus::RecieveTriggerCmd (10) / CommandStatus::SendTriggerCmd (11).
		std::atomic<int> RecieveTriggerCmdCode{ 10 };
		std::atomic<int> SendTriggerCmdCode{ 11 };

		// Path naar training folder object detectie (YOLO)
		std::string RawImagePath = "C:\\_InduSoftSource\\Va_Images\\data_Yolo\\training";
		std::string AnalysedImagesPath = "C:\\_InduSoftSource\\Va_Images\\All_Images\\Analysed";

		// maps to members
		std::unordered_map<std::string, std::atomic<bool>*> boolMap;
		std::unordered_map<std::string, std::atomic<int>*> intMap;
		std::unordered_map<std::string, std::atomic<float>*> floatMap;
		std::unordered_map<std::string, std::string*> stringMap;

		void initMaps();
		void updateParam(Parameter& parameter);
};
