#pragma once

#include <filesystem>
#include <atomic>
#include <mutex>

namespace fs = std::filesystem;

//Forward declaration
enum class SaveCategory;

struct SaveState {
        SaveState(SaveCategory cat, const fs::path& p) : category(cat), basePath(p) { }

		SaveCategory category;
	    fs::path basePath;

        std::atomic<int> folderIndex = 0;
        std::atomic<int> imageIndex = 0;

		std::mutex folderMutex;
};
