#include "MySQL.h"
#include "CommandStatus.h"
#include "PostgresCommand.h"

#include <iostream>
#include <string>

#include <mysql/mysql.h>

bool MySQL::open() {
    std::lock_guard<std::mutex> connLock(ConnMutex);
    std::lock_guard<std::mutex> lock(ParametersCtx.paramMutex);
    try {
        Connection = mysql_init(nullptr);
        if (!Connection) {
            LoggerContext.pushMsg("FATAL: mysql_init failed");
            return false;
        }

        if (!mysql_real_connect(
            Connection,
            ParametersCtx.SQLHostIp.c_str(),
            ParametersCtx.SQLUserName.c_str(),
            ParametersCtx.SQLPassword.c_str(),
            ParametersCtx.SQLDbName.c_str(),
            ParametersCtx.SQLPort.load(),
            nullptr, 0))
        {
            LoggerContext.pushMsg(std::string("FATAL: MySQL connection failed: ") + mysql_error(Connection));
            mysql_close(Connection);
            Connection = nullptr;
            return false;
        }

        std::cout << "MySQL connected successfully on: " << ParametersCtx.SQLHostIp << std::endl;
        return true;
    }
    catch (const std::exception& e) {
        LoggerContext.pushMsg(std::string("FATAL: MySQL connection crashed: ") + e.what());
        return false;
    }
}

void MySQL::close() {
    std::lock_guard<std::mutex> connLock(ConnMutex);
    if (Connection) {
        mysql_close(Connection);
        Connection = nullptr;
    }
}

std::string MySQL::esc(const std::string& value) {
    if (!Connection || value.empty())
        return std::string();

    // Worst case wordt elk teken twee tekens; +1 voor de afsluitende NUL.
    std::string buffer(value.size() * 2 + 1, '\0');

    unsigned long length = mysql_real_escape_string(
        Connection, &buffer[0], value.c_str(), static_cast<unsigned long>(value.size()));

    buffer.resize(length);
    return buffer;
}

bool MySQL::addCommand(const PostgresCommand& pgCmd) {
    if (!pgCmd.analysedImage.has_value())
        return true;

    std::lock_guard<std::mutex> connLock(ConnMutex);
    if (!Connection) return false;   // niet verbonden -> requeue, geen crash

    const auto& img = pgCmd.analysedImage.value();

    std::string sql =
        "INSERT INTO plv_results "
        "(sessie_id, vervolgnr, lijn_nr, foto_path, "
        " fr_code_plc, fr_code_beeld_karton, fr_code_beeld_label, "
        " barcode_karton, barcode_label, resultaat, oma_naam, oma_reden) "
        "VALUES (" +
        std::to_string(img.sessieId) + ", " +
        std::to_string(img.sequenceNr) + ", " +
        std::to_string(img.lineNr) + ", '" +
        esc(img.filePath) + "', '" +
        esc(img.frCodePlc) + "', '" +
        esc(img.frCodeImageCardboard) + "', '" +
        esc(img.frCodeImageLabel) + "', '" +
        esc(img.barcodeCardboard) + "', '" +
        esc(img.barcodeLabel) + "', " +
        std::to_string(img.resultaat) + ", '" +
        esc(img.omaName) + "', '" +
        esc(img.omaReason) + "')";

    if (mysql_query(Connection, sql.c_str())) {
        LoggerContext.pushMsg(std::string("Error executing DB command: ") + mysql_error(Connection));
        return false;
    }

    return true;
}

int MySQL::getLastSessieId(uint8_t lineNr) {
    std::lock_guard<std::mutex> connLock(ConnMutex);
    if (!Connection) return 0;

    std::string sql = "SELECT MAX(sessie_id) FROM plv_results WHERE lijn_nr = " +
        std::to_string(lineNr);

    if (mysql_query(Connection, sql.c_str())) {
        LoggerContext.pushMsg(std::string("Error fetching last session id: ") + mysql_error(Connection));
        return 0;
    }

    MYSQL_RES* result = mysql_store_result(Connection);
    if (!result) return 0;

    MYSQL_ROW row = mysql_fetch_row(result);
    int lastId = 0;
    if (row && row[0])
        lastId = std::stoi(row[0]);

    mysql_free_result(result);
    return lastId;
}

bool MySQL::pushToQueue(PostgresCommand pgCmd) {
    std::lock_guard<std::mutex> lock(DbQueueMutex);

    if (DbQueue.size() >= MAX_LOG_MESSAGES)
        DbQueue.pop_front();

    DbQueue.push_back(pgCmd);
    DbQueueCV.notify_one();
    return true;
}

bool MySQL::processNextCommand() {
    PostgresCommand command;

    {
        std::lock_guard<std::mutex> lock(DbQueueMutex);
        if (DbQueue.empty()) return false;

        command = std::move(DbQueue.front());
        DbQueue.pop_front();
    }

    if (!addCommand(command)) {
        std::lock_guard<std::mutex> lock(DbQueueMutex);
        DbQueue.push_front(std::move(command));
        return false;
    }

    return true;
}

bool MySQL::isQueueEmpty() {
    std::lock_guard<std::mutex> lock(DbQueueMutex);
    return DbQueue.empty();
}