#pragma once
#include "PostgresCommand.h"
#include "Logger.h"
#include "Parameters.h"

#include <mutex>
#include <deque>
#include <condition_variable>
#include <memory>

#include <mysql/mysql.h>

class MySQL {
    public:
        MySQL(Parameters& parameters, Logger& logger)
            : ParametersCtx(parameters), LoggerContext(logger), Connection(nullptr) {
        }

        ~MySQL() { close(); }

        bool open();
        void close();

        bool pushToQueue(PostgresCommand pgCmd);
        bool processNextCommand();
        bool isQueueEmpty();
        int  getLastSessieId(uint8_t lineNr);

        MYSQL* Connection;

        // Beschermt de MYSQL*-connectie zelf: de worker-thread (addCommand /
        // getLastSessieId) en de reconnect (open/close) mogen ze nooit tegelijk
        // aanraken. MySQL's C-API is niet thread-safe per connectie.
        std::mutex ConnMutex;

        std::mutex DbQueueMutex;
        std::condition_variable DbQueueCV;
        std::deque<PostgresCommand> DbQueue;

        static constexpr size_t MAX_LOG_MESSAGES = 100;

    private:
        bool addCommand(const PostgresCommand& pgCmd);

        // Maakt een string veilig om tussen quotes in een SQL-statement te zetten.
        // Let op: de aanroeper moet ConnMutex al vasthouden.
        std::string esc(const std::string& value);

        Logger& LoggerContext;
        Parameters& ParametersCtx;
};